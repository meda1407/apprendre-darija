# Darija DZ — guide d'installation, d'utilisation et de sauvegarde

Darija DZ est une application **personnelle et 100 % hors ligne** pour apprendre la darija algérienne,
écrite comme les Algériens l'écrivent au quotidien : **en lettres latines avec des chiffres** (`3` = ع, `7` = ح, `9` = ق…).

- Aucun compte, aucune inscription, aucun serveur à administrer, aucun abonnement, aucune publicité, aucune télémétrie.
- Toutes les leçons, le dictionnaire, les exercices, les dialogues et vos progrès sont stockés **sur votre appareil**.
- Pendant l'utilisation, l'application ne fait **aucune requête réseau**.

---

## 1. Ce que contient le dossier

| Élément | Rôle |
|---|---|
| `darija-dz.html` | **Version autonome** : tout dans un seul fichier. Double-cliquez, ça marche hors ligne. |
| `index.html`, `css/`, `js/`, `data/`, `fonts/`, `icons/` | La même application en version installable (PWA). |
| `sw.js`, `manifest.webmanifest` | Fichiers qui permettent l'installation et le fonctionnement hors ligne. |
| `version-iphone/` | La même application en 7 fichiers à mettre en ligne pour l'installer sur iPhone ou Android. |
| `lancer-windows.bat`, `lancer-mac-linux.sh` | Lancent l'application en local sur un ordinateur pour pouvoir l'installer. |
| `data/LISEZMOI.md` | Comment corriger ou enrichir le contenu. |
| `outils/` | Outils facultatifs (vérifier le contenu, reconstruire la version autonome). |

---

## 2. Installation

Choisissez la méthode qui correspond à votre appareil.

### A. Sur ordinateur : la version autonome (le plus simple)

1. Dézippez l'archive dans un dossier qui ne bougera pas (par exemple `Documents/Darija DZ`).
2. Double-cliquez sur **`darija-dz.html`**. Il s'ouvre dans votre navigateur (Chrome, Edge ou Firefox recommandés).
3. C'est tout : l'application fonctionne sans Internet.

Conseil : ajoutez la page à vos favoris et **ouvrez toujours le même fichier, au même endroit, avec le même navigateur** :
vos progrès sont enregistrés par le navigateur pour ce fichier.

### B. Sur ordinateur : l'installer comme une vraie application

Nécessite Python 3 (déjà présent sur macOS et la plupart des Linux ; sur Windows, installable depuis python.org).

1. Windows : double-cliquez sur `lancer-windows.bat`. macOS / Linux : lancez `lancer-mac-linux.sh`
   (dans un terminal : `sh lancer-mac-linux.sh`).
2. Le navigateur s'ouvre sur `http://localhost:8080/index.html`.
3. Dans Chrome ou Edge, cliquez sur l'icône **« Installer »** dans la barre d'adresse.
4. L'application installée fonctionne ensuite **même sans relancer le script et sans Internet**.

Utilisez toujours la même adresse (`http://localhost:8080`) : une autre adresse ou un autre port correspond à un autre espace de stockage.

### C. Sur iPhone / iPad (étape par étape)

Safari n'installe une application web hors ligne que depuis une adresse **https://**. Il faut donc mettre l'application
en ligne **une seule fois** sur un hébergement gratuit (ici GitHub Pages), puis l'ajouter à l'écran d'accueil.
Ensuite, plus aucune connexion n'est nécessaire.

Utilisez le dossier **`version-iphone`** (ou l'archive `darija-dz-iphone.zip`) : 7 petits fichiers, tous au même niveau,
qui contiennent **l'intégralité** de l'application et du contenu (cours, dictionnaire, grammaire, dialogues, exercices).

1. **Préparer les fichiers.** Décompressez `darija-dz-iphone.zip` (sur iPhone : app Fichiers, touchez l'archive).
2. **Créer un compte GitHub gratuit** sur github.com (il sert seulement à héberger les fichiers).
3. **Créer un dépôt** : bouton « + » → *New repository* → nom `darija-dz` → **Public** → cochez *Add a README file* → *Create repository*.
4. **Envoyer les fichiers** : *Add file* → *Upload files* → sélectionnez tous les fichiers du dossier → *Commit changes*.
   Sur iPhone, si ce bouton n'apparaît pas, affichez la version ordinateur du site (menu « aA » ou « ••• » de Safari →
   *Demander le site pour ordinateur*) — à vérifier selon votre version d'iOS. C'est plus simple depuis un ordinateur.
5. **Activer GitHub Pages** : *Settings* → *Pages* → *Build and deployment* → *Source* : **Deploy from a branch** →
   branche `main`, dossier `/ (root)` → *Save*. Après quelques minutes, l'adresse s'affiche :
   `https://VOTRE-NOM.github.io/darija-dz/`.
6. **Ouvrir l'adresse dans Safari** sur l'iPhone, avec Internet. Attendez que l'accueil s'affiche (quelques secondes).
7. **Ajouter à l'écran d'accueil** :
   - iOS 26 et suivants : bouton **•••** à côté de la barre d'adresse → **Partager** → **Sur l'écran d'accueil** →
     laissez **« Ouvrir en tant qu'app web »** activé → **Ajouter**.
   - Versions plus anciennes : bouton **Partager** (carré avec une flèche) → **Sur l'écran d'accueil** → **Ajouter**.
8. **Tester hors ligne** : ouvrez Darija DZ depuis l'icône, puis passez en mode avion, fermez et rouvrez : tout doit fonctionner.

Avec l'offre gratuite de GitHub, le dépôt doit être **public** : n'importe qui peut voir le code et le contenu pédagogique
de l'application, mais **vos progrès, notes et enregistrements ne sont jamais envoyés** : ils restent dans l'iPhone.

Utilisez toujours Darija DZ depuis l'icône de l'écran d'accueil (pas dans un onglet Safari) : l'application installée
garde ses propres données. Exportez quand même régulièrement une sauvegarde (section 4).

**Mettre à jour plus tard** (après une modification du contenu) : reconstruisez la version iPhone
(`node outils/construire-version-iphone.js`), renvoyez les fichiers sur GitHub, puis rouvrez l'application avec Internet.

### D. Sur Android

Même principe que pour l'iPhone (étapes 1 à 6), puis dans Chrome : menu ⋮ → **« Installer l'application »**
(ou « Ajouter à l'écran d'accueil »). Testez ensuite en mode avion.

---

## 3. Utilisation

### Organisation

- **Accueil** : salutation du jour, série de jours, objectif quotidien, révision du jour, leçon suivante, expression du jour.
- **Cours** : 4 étapes (débutant absolu → avancé), 36 leçons, à suivre dans l'ordre.
  Commencez par le **guide d'écriture** (« Nekteb darija »).
- **Grammaire** : 15 fiches progressives (pronoms, négation, présent, passé, futur, impératif…).
- **Dialogues** : 25 conversations (amis, famille, marché, café, taxi, restaurant, téléphone…), avec questions de compréhension.
- **Dictionnaire** : ~750 mots et expressions classés par thème, recherche instantanée tolérante aux variantes
  (`3lach` / `3lech`, `kh` / `5`, `dj` / `j`, voyelles…), favoris, historique, mots difficiles, mots personnels.
- **Pratique** : révision espacée (5, 10 ou 15 min), exercices (QCM, traduction dans les deux sens, mots dans l'ordre,
  phrases à compléter, association, expressions, dialogues), révision des erreurs, entraînement libre.
- **Mode examen** : test mélangé, corrections à la fin, score enregistré.
- **Progression** : niveau, série, jours d'utilisation, mots appris et maîtrisés, taux de réussite, graphiques.
- **Mes notes** : carnet personnel ; chaque leçon a aussi son champ de notes.

### Routine conseillée (15 à 20 minutes par jour)

1. **Révision du jour** : 5 ou 10 minutes. Notez chaque carte honnêtement :
   « À revoir » (revient dans 10 min), « Difficile », « Bien », « Facile » (revient beaucoup plus tard).
2. **Une leçon** : lisez-la, écoutez/lisez les phrases modèles, puis « S'entraîner sur cette leçon ».
   À partir de 70 % de bonnes réponses, la leçon est terminée et ses mots entrent dans vos révisions.
3. **Un dialogue** : en mode « Au toucher », essayez de comprendre chaque réplique avant de révéler la traduction.

### Astuces

- **Masquer le français** : bouton « Français visible / masqué » ; touchez une traduction floutée pour la révéler.
- **Écriture arabe** : facultative, via le bouton « Arabe » ou dans Réglages. La darija latine reste toujours l'écriture principale.
- **Saisie** : dans les exercices écrits, des touches rapides insèrent `3`, `7`, `9`, `2`, `kh`, `gh`, `ch`, `ou`.
  Les variantes raisonnables sont acceptées (`kh`/`5`, `dj`/`j`, `q`/`9`, voyelles, lettres doublées),
  mais un chiffre-lettre oublié (`maalich` au lieu de `ma3lich`) est compté comme une erreur.
- **Mots personnels** : Dictionnaire → « Ajouter un mot ». Ils apparaissent partout (recherche, révisions, exercices).
- **Formes « à vérifier »** : un badge orange signale les mots ou expressions dont la forme ou le sens n'est pas certain,
  ou varie selon les régions. Vérifiez-les auprès d'un locuteur natif.

### Audio : ce qui est possible et ce qui ne l'est pas

- **Aucun enregistrement n'est fourni** avec l'application : nous ne disposons pas d'enregistrements de locuteurs natifs
  dont l'usage soit vérifié, et aucune voix de synthèse hors ligne courante ne parle la darija algérienne.
- Vous pouvez **enregistrer** la prononciation (idéalement un ami ou un proche algérien) avec le bouton micro,
  ou **importer** un fichier audio (mp3, m4a, ogg, wav…). Les enregistrements restent sur l'appareil et fonctionnent hors ligne.
- Un même texte partage son enregistrement partout où il apparaît (mot, exemple, réplique).
- Lecture, répétition d'une réplique (×3), lecture enchaînée d'un dialogue, vitesse réglable (0,5× à 1,25×).
- Un appui long (ou clic droit) sur un bouton « écouter » rouvre les options (réenregistrer, supprimer, vitesse).
- Option expérimentale (désactivée par défaut) : une voix de synthèse **arabe** si votre appareil en a une.
  Elle lit l'écriture arabe avec une prononciation d'arabe standard : **ce n'est pas de la darija** ; à utiliser avec prudence.
- L'enregistrement au micro nécessite une page ouverte en `https://` ou `http://localhost` (ou le fichier autonome dans Chrome/Edge).

L'apprentissage écrit reste complet sans aucun audio.

---

## 4. Sauvegarder et restaurer mes données

Vos données sont enregistrées **automatiquement** dans le navigateur de l'appareil (IndexedDB) et restent disponibles
après fermeture de l'application et redémarrage. Elles peuvent cependant être perdues si vous videz les données du navigateur,
désinstallez l'application ou changez d'appareil. D'où l'export régulier :

**Exporter :** menu Plus → **Sauvegarde** → « Exporter une sauvegarde ».
Un fichier `darija-dz-sauvegarde-AAAA-MM-JJ.json` est créé (dans « Téléchargements » sur téléphone).
Cochez « Inclure mes enregistrements audio » si vous voulez aussi sauvegarder vos enregistrements (fichier plus lourd).
Si le téléchargement ne démarre pas, utilisez « Copier le contenu » et collez-le dans un fichier `.json`.

**Restaurer :** Sauvegarde → « Choisir un fichier de sauvegarde » (ou coller le contenu) → confirmer.
Attention : la restauration **remplace** les données actuelles.

**Changer d'appareil :** exportez sur l'ancien, transférez le fichier, importez sur le nouveau.

**Protéger mes données :** Réglages → « Protéger mes données » demande au navigateur de ne pas effacer
automatiquement le stockage (accordé ou non selon le navigateur).

Le fichier de sauvegarde contient : leçons et fiches terminées, scores, révisions (répétition espacée), mots appris,
erreurs, favoris, mots difficiles, historique, mots personnels, notes, statistiques, réglages et examens passés.

**Réinitialiser :** Réglages → « Réinitialiser les progrès » (garde vos mots, notes, favoris et réglages)
ou « Tout effacer ». Il faut taper `EFFACER` pour confirmer.

---

## 5. Qualité linguistique et corrections

- Référence : une darija du **Centre** (Alger), comprise dans tout le pays. Les variantes régionales sont signalées
  (prononciation de `9` en « g », `nti` dans l'Est, `wah` et `nta3` dans l'Ouest…), avec prudence.
- La darija algérienne est distinguée du marocain (`daba`, `wakha`, `chno`), du tunisien (`taw`, `barcha`)
  et de l'arabe standard.
- 58 entrées sont marquées **« à vérifier »** : ce sont des formes dont je ne suis pas certain ou qui varient fortement.
  Les proverbes, l'argot et certaines expressions idiomatiques en font partie.
- Il n'existe pas d'orthographe officielle : l'écriture arabe proposée est une écriture possible parmi d'autres.

Pour corriger ou enrichir : voir `data/LISEZMOI.md`.

---

## 6. Dépannage

| Problème | Solution |
|---|---|
| Mes progrès ont disparu | Vérifiez que vous ouvrez la même adresse ou le même fichier, avec le même navigateur. Sinon, importez votre dernière sauvegarde. |
| Bandeau « Stockage limité » ou « Stockage indisponible » | Le navigateur bloque IndexedDB (navigation privée, réglages stricts). Ouvrez l'application normalement, ou exportez avant de fermer. |
| L'option « Installer » n'apparaît pas | L'application doit être ouverte en `https://` ou `http://localhost`, pas depuis `file://`. Sur iPhone, utilisez Safari. |
| Après une modification du contenu, l'app installée ne change pas | Augmentez la version dans `sw.js` (`darija-dz-v1.0.1`…), puis rouvrez l'application avec Internet une fois. |
| Le micro ne fonctionne pas | Autorisez le micro pour la page. Sinon, importez un fichier audio. |

---

Darija DZ 1.0.0 · Police Lora (Copyright The Lora Project Authors, SIL Open Font License 1.1, voir `fonts/LICENCE-Lora.txt`).
