#!/usr/bin/env node
/* Darija DZ — construit la version autonome « darija-dz.html » (un seul fichier, tout inclus).
   Usage (facultatif, nécessite Node.js) : node outils/construire-version-autonome.js
   À relancer après avoir modifié le contenu du dossier data/. */
'use strict';
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const OUT = process.argv[2] || path.join(ROOT, 'darija-dz.html');
const read = (p) => fs.readFileSync(path.join(ROOT, p), 'utf8');
const b64 = (p) => fs.readFileSync(path.join(ROOT, p)).toString('base64');

let html = read('index.html');

// 1. Styles + polices intégrées
let css = read('css/app.css')
  .replace("url('../fonts/lora-var.woff')", "url(data:font/woff;base64," + b64('fonts/lora-var.woff') + ")")
  .replace("url('../fonts/lora-italic-var.woff')", "url(data:font/woff;base64," + b64('fonts/lora-italic-var.woff') + ")");
html = html.replace('<link rel="stylesheet" href="css/app.css">', '<style>\n' + css + '\n</style>');

// 2. Scripts intégrés, dans l'ordre de index.html
const scripts = [...html.matchAll(/<script src="([^"]+)"><\/script>\n?/g)].map((m) => m[1]);
const bundle = 'window.DZ_STANDALONE = true;\n' + scripts.map((s) => '/* ---- ' + s + ' ---- */\n' + read(s).replace(/<\/script/gi, '<\\/script')).join('\n');
html = html.replace(/<script src="[^"]+"><\/script>\n?/g, '');
html = html.replace('</body>', '<script>\n' + bundle + '\n</script>\n</body>');

// 3. Pas de manifeste ni de service worker dans la version fichier ; icône intégrée
html = html.replace(/<link rel="manifest"[^>]*>\n?/, '');
html = html.replace(/<link rel="apple-touch-icon"[^>]*>\n?/, '');
html = html.replace(/href="icons\/favicon-32.png"/, 'href="data:image/png;base64,' + b64('icons/favicon-32.png') + '"');
html = html.replace(/<meta http-equiv="Content-Security-Policy"[^>]*>/,
  '<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; script-src \'unsafe-inline\'; style-src \'unsafe-inline\'; img-src data: blob:; media-src blob: data:; font-src data:">');

fs.writeFileSync(OUT, html);
console.log('Version autonome écrite :', OUT, '(' + Math.round(fs.statSync(OUT).size / 1024) + ' Ko)');
