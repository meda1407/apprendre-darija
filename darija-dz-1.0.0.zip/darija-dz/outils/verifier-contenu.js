#!/usr/bin/env node
/* Darija DZ — vérifie le contenu pédagogique après une modification du dossier data/.
   Usage (nécessite Node.js) : node outils/verifier-contenu.js
   Contrôles : champs obligatoires, doublons, mots de leçons introuvables, questions mal formées. */
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const ROOT = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
const files = [...html.matchAll(/<script src="((?:js\/registry|data\/)[^"]+)"><\/script>/g)].map((m) => m[1]);

const sandbox = { window: {}, console };
sandbox.window.window = sandbox.window;
vm.createContext(sandbox);
for (const f of files) {
  try { vm.runInContext('var DZ = window.DZ;\n' + fs.readFileSync(path.join(ROOT, f), 'utf8'), sandbox, { filename: f }); }
  catch (e) { console.error('ERREUR de syntaxe dans', f, ':', e.message); process.exit(1); }
}
const D = sandbox.window.DZ.data;
const problems = [], warnings = [];
const byDz = {};

D.dict.forEach((e) => {
  const where = e.cat + ' / ' + e.d;
  if (!e.d || !e.fr) problems.push('Entrée sans darija ou sans français : ' + where);
  if (!e.exd || !e.exf) warnings.push('Entrée sans exemple : ' + where);
  if (!e.ar) warnings.push('Entrée sans écriture arabe : ' + where);
  if (!D.cats.some((c) => c.id === e.cat)) problems.push('Catégorie inconnue : ' + where);
  const k = e.d.toLowerCase();
  if (byDz[k]) problems.push('Doublon : « ' + e.d + ' » (' + byDz[k] + ' et ' + e.cat + ')');
  byDz[k] = e.cat;
});

const ids = {};
D.stages.forEach((s) => s.lessons.forEach((l) => {
  if (ids[l.id]) problems.push('Identifiant de leçon en double : ' + l.id);
  ids[l.id] = 1;
  (l.words || []).forEach((w) => { if (!byDz[w.toLowerCase()]) problems.push('Leçon ' + l.id + ' : mot introuvable dans le dictionnaire « ' + w + ' »'); });
  (l.quiz || []).forEach((q, i) => checkQuiz(q, 'Leçon ' + l.id + ' question ' + (i + 1)));
}));
D.grammar.forEach((g) => (g.quiz || []).forEach((q, i) => checkQuiz(q, 'Grammaire ' + g.id + ' question ' + (i + 1))));
D.dialogues.forEach((d) => {
  d.lines.forEach((l, i) => { if (l.length !== 4) problems.push('Dialogue ' + d.id + ' réplique ' + (i + 1) + ' : il faut [personnage, darija, arabe, français]'); });
  d.q.forEach((q, i) => { if (!(q.a >= 0 && q.a < q.o.length)) problems.push('Dialogue ' + d.id + ' question ' + (i + 1) + ' : index de réponse invalide'); });
});

function checkQuiz(q, where) {
  if (q.t === 'qcm' && !(q.a >= 0 && q.a < q.o.length)) problems.push(where + ' : index de réponse invalide');
  if (q.t === 'type' && !(Array.isArray(q.a) && q.a.length)) problems.push(where + ' : « a » doit être une liste de réponses');
  if (q.t === 'order' && String(q.a).trim().split(/\s+/).length < 3) problems.push(where + ' : la phrase à remettre en ordre doit avoir au moins 3 mots');
}

console.log('Dictionnaire : ' + D.dict.length + ' entrées · Leçons : ' + Object.keys(ids).length + ' · Grammaire : ' + D.grammar.length + ' · Dialogues : ' + D.dialogues.length);
console.log('À vérifier (marqués u:1) : ' + D.dict.filter((e) => e.u).length);
if (warnings.length) console.log('\nAvertissements (' + warnings.length + ') :\n  ' + warnings.slice(0, 30).join('\n  '));
if (problems.length) { console.log('\nPROBLÈMES (' + problems.length + ') :\n  ' + problems.join('\n  ')); process.exit(1); }
console.log('\nContenu valide.');
