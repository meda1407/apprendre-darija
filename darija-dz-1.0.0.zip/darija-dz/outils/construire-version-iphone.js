#!/usr/bin/env node
/* Darija DZ — construit la « version iPhone » : une application installable (PWA) en 6 fichiers,
   tous au même niveau, faciles à envoyer sur un hébergement statique (GitHub Pages…) même depuis un téléphone.
   Usage (nécessite Node.js) : node outils/construire-version-iphone.js [dossier-de-sortie] */
'use strict';
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
const OUT = process.argv[2] || path.join(ROOT, 'version-iphone');
const read = (p) => fs.readFileSync(path.join(ROOT, p), 'utf8');
const b64 = (p) => fs.readFileSync(path.join(ROOT, p)).toString('base64');
fs.mkdirSync(OUT, { recursive: true });

let html = read('index.html');
const version = (read('sw.js').match(/darija-dz-v([\d.]+)/) || [])[1] || '1.0.0';

// Styles et polices intégrés
const css = read('css/app.css')
  .replace("url('../fonts/lora-var.woff')", 'url(data:font/woff;base64,' + b64('fonts/lora-var.woff') + ')')
  .replace("url('../fonts/lora-italic-var.woff')", 'url(data:font/woff;base64,' + b64('fonts/lora-italic-var.woff') + ')');
html = html.replace('<link rel="stylesheet" href="css/app.css">', '<style>\n' + css + '\n</style>');

// Scripts intégrés (le service worker reste actif : pas de DZ_STANDALONE)
const scripts = [...html.matchAll(/<script src="([^"]+)"><\/script>\n?/g)].map((m) => m[1]);
const bundle = scripts.map((s) => '/* ---- ' + s + ' ---- */\n' + read(s).replace(/<\/script/gi, '<\\/script')).join('\n');
html = html.replace(/<script src="[^"]+"><\/script>\n?/g, '');
html = html.replace('</body>', '<script>\n' + bundle + '\n</script>\n</body>');

// Icônes à la racine
html = html.replace('href="icons/favicon-32.png"', 'href="data:image/png;base64,' + b64('icons/favicon-32.png') + '"');
html = html.replace('href="icons/apple-touch-icon.png"', 'href="apple-touch-icon.png"');
html = html.replace(/<meta http-equiv="Content-Security-Policy"[^>]*>/,
  '<meta http-equiv="Content-Security-Policy" content="default-src \'self\'; script-src \'self\' \'unsafe-inline\'; style-src \'self\' \'unsafe-inline\'; img-src \'self\' data: blob:; media-src \'self\' blob: data:; font-src \'self\' data:; connect-src \'self\'; manifest-src \'self\'; worker-src \'self\'">');
fs.writeFileSync(path.join(OUT, 'index.html'), html);

const manifest = JSON.parse(read('manifest.webmanifest'));
manifest.icons = manifest.icons.map((i) => Object.assign({}, i, { src: path.basename(i.src) }));
fs.writeFileSync(path.join(OUT, 'manifest.webmanifest'), JSON.stringify(manifest, null, 2) + '\n');

['icon-192.png', 'icon-512.png', 'icon-maskable-512.png', 'apple-touch-icon.png'].forEach((f) => {
  fs.copyFileSync(path.join(ROOT, 'icons', f), path.join(OUT, f));
});

const sw = `/* Darija DZ (version iPhone) — met toute l'application en cache pour un fonctionnement 100 % hors ligne. */
'use strict';
var CACHE = 'darija-dz-iphone-v${version}';
var ASSETS = ['./', './index.html', './manifest.webmanifest', './icon-192.png', './icon-512.png', './icon-maskable-512.png', './apple-touch-icon.png'];
self.addEventListener('install', function (e) {
  e.waitUntil(caches.open(CACHE).then(function (c) {
    return c.addAll(ASSETS.map(function (u) { return new Request(u, { cache: 'reload' }); }));
  }).then(function () { return self.skipWaiting(); }));
});
self.addEventListener('activate', function (e) {
  e.waitUntil(caches.keys().then(function (keys) {
    return Promise.all(keys.filter(function (k) { return k.indexOf('darija-dz-') === 0 && k !== CACHE; }).map(function (k) { return caches.delete(k); }));
  }).then(function () { return self.clients.claim(); }));
});
self.addEventListener('fetch', function (e) {
  var req = e.request;
  if (req.method !== 'GET' || new URL(req.url).origin !== self.location.origin) return;
  e.respondWith(caches.match(req, { ignoreSearch: true }).then(function (hit) {
    if (hit) return hit;
    if (req.mode === 'navigate') return caches.match('./index.html');
    return fetch(req).catch(function () { return caches.match('./index.html'); });
  }));
});
`;
fs.writeFileSync(path.join(OUT, 'sw.js'), sw);

fs.writeFileSync(path.join(OUT, 'LISEZMOI.txt'),
  'Darija DZ — version iPhone (' + version + ')\n\n' +
  'Envoyez ces fichiers (sauf ce LISEZMOI si vous voulez) à la racine d\'un hébergement statique en https,\n' +
  'par exemple GitHub Pages, puis ouvrez l\'adresse dans Safari et ajoutez-la à l\'écran d\'accueil.\n' +
  'Voir GUIDE.md, section « Installer sur iPhone ».\n');

console.log('Version iPhone écrite dans', OUT);
fs.readdirSync(OUT).forEach((f) => console.log('  ' + f + ' (' + Math.round(fs.statSync(path.join(OUT, f)).size / 1024) + ' Ko)'));
