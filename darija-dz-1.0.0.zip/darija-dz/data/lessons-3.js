/* Cours — Étape 3 : niveau intermédiaire. */

DZ.addDict('bases', [
  ["li", "اللي", "qui, que (pronom relatif)", "Rajel li cheftou lbare7.", "L'homme que j'ai vu hier.", { v: "elli|lli" }],
  ["n7ki", "نحكي", "je raconte", "N7kilek wach sra.", "Je te raconte ce qui s'est passé.", { v: "nhki|na7ki", n: "Passé : 7kit. « 7kaya » = histoire." }],
  ["ra7", "راح", "(marque du futur) ; il est parti", "Ra7 nji ghedwa.", "Je viendrai demain.", { n: "Ra7 + verbe au présent = futur : ra7 nakoul = je vais manger. Seul, « ra7 » veut aussi dire « il est parti »." }],
  ["kount", "كنت", "j'étais", "Kount f ddar.", "J'étais à la maison.", { v: "kont|kunt", n: "Kount (j'étais / tu étais), kounti (tu étais, f.), kan (il était), kanet (elle était), kouna (nous étions), kountou (vous étiez), kanou (ils étaient)." }],
  ["rayeh", "رايح", "qui va, en route vers", "Rani rayeh l lkhedma.", "Je vais au travail.", { v: "rayah|raye7", n: "Féminin : rayha ; pluriel : ray7in." }],
  ["kan ya ma kan", "كان يا ما كان", "il était une fois", "Kan ya ma kan, wa7ed sultan…", "Il était une fois un sultan…", { v: "kan ya makan" }],
  ["f lekhar", "في الاخر", "à la fin, finalement", "F lekhar, wselna.", "Finalement, nous sommes arrivés.", { v: "fel lekhar|f lakher|fel 5er" }],
  ["wa7ed nhar", "واحد نهار", "un jour (dans un récit)", "Wa7ed nhar, kount f tobis…", "Un jour, j'étais dans le bus…", { v: "wahed nhar" }],
  ["chab", "شاب", "jeune homme", "Wa7ed chab nod.", "Un jeune s'est levé.", { n: "Féminin : chaba (qui veut aussi dire « belle »)." }],
  ["khlas", "خلاص", "c'est fini ; ça suffit ; bon, d'accord", "Khlas, nrou7ou.", "Bon, on y va.", { v: "5las|khlass|khelas" }],
  ["chouf", "شوف", "regarde ; écoute (pour introduire une idée)", "Chouf, ana ma n7ebch hakda.", "Écoute, moi je n'aime pas ça.", { v: "chof" }],
  ["men wa9tach", "من وقتاش", "depuis quand ?", "Men wa9tach rak hna?", "Depuis quand es-tu ici ?", { v: "mel wa9tach|men wa9tech" }],
  ["m3a chkoun", "مع شكون", "avec qui ?", "M3a chkoun rak?", "Tu es avec qui ?", { v: "ma3a chkoun" }],
  ["3la wach", "على واش", "à propos de quoi ? sur quoi ?", "3la wach rakoum tahadrou?", "De quoi vous parlez ?", { v: "3la wech" }]
]);
DZ.addDict('expressions', [
  ["c'est bon", "سي بون", "c'est bon, ça va", "C'est bon, makach mouchkil.", "C'est bon, pas de problème.", { v: "cbon|c bon" }],
  ["ah bon", "آه بون", "ah bon ? (surprise)", "Ah bon? Bsa7?!", "Ah bon ? Vraiment ?!", { v: "a bon" }]
]);

DZ.addStage({
  id: 's3', n: 3,
  title: "Niveau intermédiaire",
  dz: "Nzidou chwiya",
  desc: "Phrases longues, passé et futur, émotions, récits et vraies conversations.",
  lessons: [
    {
      id: 's3-l1', dz: "W, bsa7, 3la khater…", t: "Construire des phrases plus longues", min: 14,
      goal: "Relier des idées avec les connecteurs les plus utiles.",
      blocks: [
        { k: 'table', h: ["Darija", "Français", "Exemple"], r: [
          ["`w`", "et", "`klit w rou7t` (j'ai mangé et je suis parti)"],
          ["`bsa7`", "mais", "`n7eb, bsa7 ma n9derch`"],
          ["`3la khater`", "parce que", "`ma jitch 3la khater kount mrid`"],
          ["`bach`", "pour, afin de", "`jit bach nchoufek`"],
          ["`ki`", "quand", "`ki nousel, n3ayetlek`"],
          ["`ida`", "si", "`ida t7eb, arwa7`"],
          ["`mba3d`", "ensuite", "`klit, w mba3d khrejt`"],
          ["`wela`", "ou bien", "`9ahwa wela tay?`"],
          ["`li`", "qui, que", "`rajel li cheftou` (l'homme que j'ai vu)"],
          ["`bli`", "que (après savoir, dire…)", "`3labali bli rak 3ayan`"]
        ] },
        { k: 'p', x: "`Li` (qui, que) est très pratique et ne change jamais : `lktab li 3tani` (le livre qu'il m'a donné), `lmra li tekhdem m3aya` (la femme qui travaille avec moi)." },
        { k: 'tip', x: "Commencez par des phrases de deux morceaux, puis ajoutez un troisième : `N7eb nji, bsa7 ma 3andich tomobil, 3la khater rahi f la panne.`" }
      ],
      words: ["w", "bsa7", "3la khater", "bach", "ki", "ida", "mba3d", "wela", "li", "bli", "7atta", "n7ki"],
      phrases: [
        ["N7eb nji, bsa7 ma 3andich tomobil.", "Je veux venir, mais je n'ai pas de voiture.", "Opposer"],
        ["Ma rou7tch 3la khater kount mrid.", "Je n'y suis pas allé parce que j'étais malade.", "Expliquer"],
        ["Ki nkemmel lkhedma, nfout 3lik.", "Quand je finis le travail, je passe chez toi.", "Situer dans le temps"],
        ["Hada lktab li 7kitlek 3lih.", "Voici le livre dont je t'ai parlé.", "Relative"],
        ["Ida ma tjich, n3ayetlek.", "Si tu ne viens pas, je t'appelle.", "Condition"]
      ],
      quiz: [
        { t: 'qcm', q: "`3la khater` =", o: ["parce que", "pour que", "quand"], a: 0 },
        { t: 'qcm', q: "Dans `rajel li cheftou`, `li` veut dire :", o: ["que", "pour", "si"], a: 0 },
        { t: 'order', fr: "Je veux venir, mais je n'ai pas de voiture.", a: "N7eb nji bsa7 ma 3andich tomobil" },
        { t: 'type', q: "Traduis : « Si tu veux, viens »", a: ["ida t7eb arwa7", "ila t7eb arwa7", "ida t7eb aji"] }
      ]
    },
    {
      id: 's3-l2', dz: "Lbare7 w ghedwa", t: "Parler du passé et du futur", min: 15,
      goal: "Conjuguer au passé et exprimer le futur.",
      blocks: [
        { k: 'p', x: "Le passé se forme en ajoutant des terminaisons au verbe : `-t` (je / tu), `-ti` (tu, femme), rien (il), `-et` (elle), `-na` (nous), `-tou` (vous), `-ou` (ils)." },
        { k: 'table', h: ["Personne", "khdem (travailler)", "kla (manger)", "ra7 (aller)"], r: [
          ["ana", "`khdemt`", "`klit`", "`rou7t`"], ["nta", "`khdemt`", "`klit`", "`rou7t`"], ["nti", "`khdemti`", "`kliti`", "`rou7ti`"],
          ["houwa", "`khdem`", "`kla`", "`ra7`"], ["hiya", "`khedmet`", "`klat`", "`ra7et`"], ["7na", "`khdemna`", "`klina`", "`rou7na`"],
          ["ntouma", "`khdemtou`", "`klitou`", "`rou7tou`"], ["houma", "`khedmou`", "`klaw`", "`ra7ou`"]
        ] },
        { k: 'p', x: "Le futur proche se forme avec `ra7` + présent : `ra7 nrou7` (je vais aller), `ra7 tchouf` (tu vas voir). On entend aussi `rani rayeh nrou7` (je suis sur le point d'y aller)." },
        { k: 'p', x: "« J'étais » : `kount`. « Il y avait » : `kan` (`kan zhou` = il y avait de l'ambiance). « Je n'ai pas encore… » : `mazal ma…` (`mazal ma klit`)." },
        { k: 'warn', x: "Dans l'Ouest, on entend aussi `ghadi` pour le futur (`ghadi nrou7`), forme partagée avec le marocain. À vérifier selon la ville." }
      ],
      words: ["ra7", "kount", "rayeh", "lbare7", "ghedwa", "ba3d ghedwa", "simana", "3omri", "mazal", "deja", "nsit"],
      phrases: [
        ["Lbare7 rou7t l souk w chrit khodra.", "Hier je suis allé au marché et j'ai acheté des légumes.", "Passé"],
        ["Ghedwa ra7 nzour jeddi.", "Demain je vais rendre visite à mon grand-père.", "Futur"],
        ["Kount sghir ki jina l Dzayer.", "J'étais petit quand nous sommes venus à Alger.", "Imparfait"],
        ["Mazal ma klit, ra7 nakoul dorka.", "Je n'ai pas encore mangé, je vais manger maintenant.", "Pas encore"]
      ],
      quiz: [
        { t: 'type', q: "Conjugue au passé : « j'ai mangé »", a: ["klit"] },
        { t: 'qcm', q: "« Elle est partie » :", o: ["ra7et", "ra7", "rou7t"], a: 0 },
        { t: 'qcm', q: "`Ra7 nji` =", o: ["je viendrai", "je suis venu", "il est parti"], a: 0 },
        { t: 'order', fr: "Je n'ai pas encore mangé.", a: "Mazal ma klit" },
        { t: 'type', q: "Traduis : « J'étais à la maison »", a: ["kount f ddar", "kont f ddar", "kount fi ddar"] }
      ]
    },
    {
      id: 's3-l3', dz: "Wach bik?", t: "Exprimer ses émotions", min: 12,
      goal: "Dire ce qu'on ressent et réagir aux émotions des autres.",
      blocks: [
        { k: 'p', x: "On utilise souvent `rani` + adjectif, accordé au genre : `rani far7an` (je suis content), `rani far7ana` (je suis contente)." },
        { k: 'table', h: ["Émotion", "Darija"], r: [
          ["content(e)", "`far7an` / `far7ana`"], ["triste", "`7zin` / `7zina`"], ["fâché(e)", "`za3fan` / `za3fana`"],
          ["agacé(e)", "`m9elle9`"], ["énervé(e)", "`mnervi`"], ["inquiet, qui a peur", "`khayef`"],
          ["fatigué(e)", "`3ayan`"], ["détendu(e)", "`mrta7`"], ["gêné(e)", "`7chemt` (j'ai eu honte)"]
        ] },
        { k: 'table', h: ["Pour réconforter", "Sens"], r: [
          ["`ma tkhammemch`", "ne t'en fais pas"], ["`ma tkhafch`", "n'aie pas peur"], ["`kolch ra7 ykoun mli7`", "tout ira bien"],
          ["`sber`", "patience"], ["`allah ychafik`", "bon rétablissement"], ["`khalliha 3la allah`", "on n'y peut rien"]
        ] },
        { k: 'note', x: "« Dégoûté » est passé dans la darija avec un sens large : découragé, qui en a marre. On parle même de `dégoûtage`." }
      ],
      words: ["far7an", "7zin", "za3fan", "m9elle9", "mnervi", "khayef", "3ayan", "mrta7", "7chemt", "dégoûté", "tw7achtek", "fre7t", "ghadni l7al", "ma tkhafch", "ma tkhammemch", "wach bik"],
      phrases: [
        ["Rani far7an bezzaf, nje7t fel examen!", "Je suis très content, j'ai réussi l'examen !", "Joie"],
        ["Wach biki? Raki 7zina?", "Qu'est-ce que tu as ? Tu es triste ?", "S'inquiéter pour quelqu'un"],
        ["Ma tkhammemch, kolch ra7 ykoun mli7.", "Ne t'en fais pas, tout ira bien.", "Réconforter"],
        ["Rani dégoûté, ma lgitch khedma.", "J'en ai marre, je n'ai pas trouvé de travail.", "Découragement"]
      ],
      quiz: [
        { t: 'qcm', q: "« Je suis contente » :", o: ["rani far7ana", "rani far7an", "rani 7zina"], a: 0 },
        { t: 'qcm', q: "`Ma tkhammemch` =", o: ["ne t'en fais pas", "ne mange pas", "ne pars pas"], a: 0 },
        { t: 'type', q: "Traduis : « Je suis fatigué »", a: ["rani 3ayan", "ana 3ayan", "rani 3ayyan"] },
        { t: 'order', fr: "Ne t'en fais pas, tout ira bien.", a: "Ma tkhammemch kolch ra7 ykoun mli7" }
      ]
    },
    {
      id: 's3-l4', dz: "N7kilek wach sra", t: "Raconter une histoire", min: 15,
      goal: "Structurer un petit récit au passé.",
      blocks: [
        { k: 'table', h: ["Darija", "Rôle"], r: [
          ["`kan ya ma kan`", "il était une fois (conte)"], ["`wa7ed nhar`", "un jour…"], ["`kan` / `kanet`", "il y avait, il était / elle était"],
          ["`mba3d`", "ensuite"], ["`ki`", "quand"], ["`f lekhar`", "à la fin"], ["`lmouhim`", "bref"]
        ] },
        { k: 'p', x: "Lisez cette petite histoire. Touchez une phrase pour voir la traduction." },
        { k: 'story', x: [
          ["Wa7ed nhar, kount rayeh l lkhedma b tobis.", "Un jour, j'allais au travail en bus."],
          ["Tobis kan 3amer, w ma lgitch plaça.", "Le bus était plein, et je n'ai pas trouvé de place."],
          ["Wa7ed chibani kan wa9ef 7daya, 3ayan bezzaf.", "Un vieil homme était debout à côté de moi, très fatigué."],
          ["Wa7ed chab nod w 9allou : « Tfaddal, 9a3ed ya 3ammi. »", "Un jeune s'est levé et lui a dit : « Je vous en prie, asseyez-vous, monsieur. »"],
          ["Chibani tbessem w 9al : « Allah yr7am waldik, ya wlidi. »", "Le vieil homme a souri et a dit : « Merci infiniment, mon fils. »"],
          ["F lekhar, ga3 nnas li f tobis tbessmou.", "À la fin, tout le monde dans le bus a souri."]
        ] },
        { k: 'tip', x: "Pour raconter, gardez des phrases courtes reliées par `w` et `mba3d`. C'est exactement comme ça que parlent les Algériens." }
      ],
      words: ["kan ya ma kan", "wa7ed nhar", "f lekhar", "lmouhim", "mba3d", "ki", "n7ki", "chab", "chibani", "tbessem"],
      phrases: [
        ["Wa7ed nhar, rou7t l b7ar m3a s7abi.", "Un jour, je suis allé à la mer avec mes amis.", "Commencer un récit"],
        ["Kan ljaw chbab, w kan zhou.", "Il faisait beau, et il y avait de l'ambiance.", "Décrire"],
        ["Mba3d, tomobil ta3na 7bset f tri9.", "Ensuite, notre voiture est tombée en panne en route.", "Rebondissement"],
        ["F lekhar, wselna f lil.", "Finalement, nous sommes arrivés la nuit.", "Conclure"]
      ],
      quiz: [
        { t: 'qcm', q: "Dans l'histoire, pourquoi le narrateur n'a-t-il pas de place ?", o: ["le bus était plein", "il était en retard", "il était debout"], a: 0, e: "`Tobis kan 3amer` : le bus était plein." },
        { t: 'qcm', q: "Que dit le vieil homme pour remercier ?", o: ["Allah yr7am waldik", "Bslama", "Ma3lich"], a: 0 },
        { t: 'qcm', q: "`F lekhar` =", o: ["à la fin", "au début", "derrière"], a: 0 },
        { t: 'order', fr: "Un jour, j'allais au travail en bus.", a: "Wa7ed nhar kount rayeh l lkhedma b tobis" }
      ]
    },
    {
      id: 's3-l5', dz: "Ya3ni, wallah, chouf…", t: "Comprendre les conversations naturelles", min: 12,
      goal: "Reconnaître les petits mots qui remplissent la conversation et le mélange avec le français.",
      blocks: [
        { k: 'p', x: "Dans une vraie conversation, beaucoup de mots ne servent qu'à rythmer : `ya3ni` (bref, genre), `wallah` (je te jure, franchement), `chouf` (écoute), `khlas` (bon, c'est fini), `lmouhim` (bref), `ya kho` (mec)." },
        { k: 'p', x: "Le mélange avec le français est permanent, surtout en ville : `normalement nji`, `c'est bon`, `en tout cas`, `déjà`, `carrément`… Ce n'est pas une faute : c'est la darija réelle." },
        { k: 'table', h: ["Forme complète", "Forme rapide à l'oral"], r: [
          ["`f el ddar`", "`f ddar` / `fe ddar`"], ["`men el souk`", "`mel souk`"], ["`3la el tabla`", "`3al tabla`"],
          ["`l el khedma`", "`lel khedma`"], ["`ki rak`", "`kirak`"]
        ] },
        { k: 'tip', x: "Ne cherchez pas à tout comprendre mot à mot. Repérez les mots-clés (verbes, lieux, temps) et laissez passer les mots de remplissage." }
      ],
      words: ["ya3ni", "wallah", "chouf", "khlas", "lmouhim", "ya kho", "normal", "sa7", "c'est bon", "ah bon", "deja", "3labalek"],
      phrases: [
        ["Ya3ni, wallah ma 3labalich, ya kho.", "Franchement, je te jure que je ne sais pas, mec.", "Hésiter"],
        ["Chouf, normalement nji, bsa7 balak nt3attel chwiya.", "Écoute, normalement je viens, mais je serai peut-être un peu en retard.", "Mélange français"],
        ["Khlas, c'est bon, nchoufou ghedwa.", "Bon, c'est bon, on verra demain.", "Clore"],
        ["Ah bon? Bsa7?!", "Ah bon ? Vraiment ?!", "Surprise"]
      ],
      quiz: [
        { t: 'qcm', q: "`Khlas` peut vouloir dire :", o: ["bon, c'est fini", "bienvenue", "pas encore"], a: 0 },
        { t: 'qcm', q: "`Mel souk` est la forme rapide de :", o: ["men el souk", "m3a el souk", "mor el souk"], a: 0 },
        { t: 'order', fr: "Écoute, normalement je viens.", a: "Chouf normalement nji" }
      ]
    },
    {
      id: 's3-l6', dz: "3la rassi!", t: "Les expressions courantes", min: 12,
      goal: "Utiliser les expressions qui reviennent tous les jours.",
      blocks: [
        { k: 'table', h: ["Expression", "Sens", "Quand l'utiliser"], r: [
          ["`3la rassi`", "avec plaisir", "accepter un service"],
          ["`rod balek`", "fais attention", "prévenir"],
          ["`ma3labalich`", "je ne sais pas", "répondre"],
          ["`3andek l7a9`", "tu as raison", "approuver"],
          ["`kif kif`", "c'est pareil", "comparer"],
          ["`allah ghaleb`", "on n'y peut rien", "s'excuser d'un empêchement"],
          ["`tbarkallah 3lik`", "bravo (et que Dieu te protège)", "complimenter"],
          ["`allah yr7am waldik`", "merci infiniment", "remercier chaleureusement"],
          ["`bsa7tek`", "profite bien", "quand quelqu'un a quelque chose de neuf"],
          ["`3ich tchouf`", "on aura tout vu", "s'étonner"]
        ] },
        { k: 'note', x: "Quand on complimente (un enfant, une maison, une réussite), on ajoute souvent `tbarkallah` ou `ma cha2a allah` : ces formules accompagnent le compliment pour écarter le « mauvais œil » (`l3in`)." }
      ],
      words: ["3la rassi", "rod balek", "dir 3a9lek", "ma3labalich", "3labalek", "khalliha 3la allah", "ya latif", "3andek l7a9", "bel3ani", "kif kif", "allah ghaleb", "tbarkallah 3lik", "allah yr7am waldik", "bsa7tek", "3ich tchouf"],
      phrases: [
        ["— T3awenni? — 3la rassi!", "— Tu m'aides ? — Avec plaisir !", "Rendre service"],
        ["Rod balek mel tomobilat.", "Fais attention aux voitures.", "Prévenir"],
        ["Tbarkallah 3lik, darek chbaba!", "Bravo, ta maison est très belle !", "Complimenter"],
        ["Ma 9dertch nji, allah ghaleb.", "Je n'ai pas pu venir, je n'y pouvais rien.", "S'excuser"]
      ],
      quiz: [
        { t: 'qcm', q: "Quelqu'un te demande un service, tu acceptes avec plaisir :", o: ["3la rassi", "ma3labalich", "allah ghaleb"], a: 0 },
        { t: 'qcm', q: "Ton ami porte des chaussures neuves, tu dis :", o: ["bsa7tek", "ma3lich", "3ich tchouf"], a: 0 },
        { t: 'type', q: "Traduis : « Tu as raison »", a: ["3andek l7a9", "3andek l7aq", "3andek lhaq"] },
        { t: 'order', fr: "Fais attention aux voitures.", a: "Rod balek mel tomobilat" }
      ]
    },
    {
      id: 's3-l7', dz: "Ya kho, ghaya!", t: "Comprendre les formulations familières", min: 12,
      goal: "Distinguer le registre familier du registre poli.",
      blocks: [
        { k: 'p', x: "Ce qui se dit entre amis ne se dit pas toujours à un aîné ou à un inconnu. Comparez :" },
        { k: 'table', h: ["Familier (amis)", "Poli (aînés, inconnus)", "Sens"], r: [
          ["`sa7a`", "`salam 3likoum`", "bonjour"],
          ["`wach ya kho?`", "`kirak 3ammi?` / `kiraki khalti?`", "comment ça va ?"],
          ["`sa7it`", "`ya3tik sa7a` / `barak allahou fik`", "merci"],
          ["`yallah, nchoufek`", "`bslama, thella f rou7ek`", "au revoir"],
          ["`ghaya!`", "`tbarkallah`", "génial / bravo"],
          ["`rak mahboul?`", "`3lach?`", "t'es fou ? / pourquoi ?"]
        ] },
        { k: 'tip', x: "En cas de doute, choisissez la forme polie : personne ne vous reprochera d'être trop respectueux." }
      ],
      words: ["ya kho", "kho", "khawa", "mahboul", "ghaya", "chbab", "zhou", "zhit", "dégoûtage", "9afez", "khlas", "sa7it", "barak allahou fik", "thella f rou7ek"],
      phrases: [
        ["Wach ya kho, win rak ghaber?", "Alors mec, t'étais passé où ?", "Entre amis"],
        ["Lbare7 kan zhou, zhit bezzaf!", "Hier il y avait une super ambiance, je me suis bien amusé !", "Raconter une soirée"],
        ["Rak mahboul? Ghali bezzaf!", "T'es fou ? C'est beaucoup trop cher !", "S'exclamer"],
        ["Kirak 3ammi? Labes 3lik?", "Comment allez-vous, monsieur ? Tout va bien ?", "Registre poli"]
      ],
      quiz: [
        { t: 'qcm', q: "Forme polie pour dire « merci » à un aîné :", o: ["barak allahou fik", "sa7it ya kho", "ghaya"], a: 0 },
        { t: 'qcm', q: "`Zhit` =", o: ["je me suis bien amusé", "je suis fatigué", "j'ai oublié"], a: 0 },
        { t: 'qcm', q: "`Ghaya!` =", o: ["Génial !", "Attention !", "Au revoir !"], a: 0 }
      ]
    },
    {
      id: 's3-l8', dz: "Men wa9tach? M3a chkoun?", t: "Poser des questions complexes", min: 14,
      goal: "Combiner mots interrogatifs et prépositions, poser des questions indirectes.",
      blocks: [
        { k: 'table', h: ["Darija", "Français"], r: [
          ["`m3a chkoun?`", "avec qui ?"], ["`l chkoun?`", "pour qui ?"], ["`3la wach?`", "à propos de quoi ?"],
          ["`men wa9tach?`", "depuis quand ?"], ["`ch7al men…?`", "combien de… ?"], ["`kifach 3reft bli…?`", "comment as-tu su que… ?"],
          ["`3lach ma…ch?`", "pourquoi ne… pas ?"]
        ] },
        { k: 'p', x: "Question indirecte : on garde le mot interrogatif, sans intonation. `Ma3labalich win rah` (je ne sais pas où il est), `9oli wach t7eb` (dis-moi ce que tu veux)." },
        { k: 'p', x: "Question négative : `3lach ma jitch?` (pourquoi n'es-tu pas venu ?), `3lach ma 9oltlich?` (pourquoi tu ne m'as pas dit ?)." }
      ],
      words: ["men wa9tach", "m3a chkoun", "3la wach", "ch7al", "kifach", "3lach", "win", "wach", "chkoun", "khetra"],
      phrases: [
        ["Men wa9tach rak tet3allem darija?", "Depuis quand apprends-tu la darija ?", "Durée"],
        ["Kifach 3reft bli rani hna?", "Comment as-tu su que j'étais ici ?", "Comment as-tu su"],
        ["3lach ma 9oltlich?", "Pourquoi tu ne me l'as pas dit ?", "Reproche"],
        ["Ch7al men khetra rou7t l Wahran?", "Combien de fois es-tu allé à Oran ?", "Combien de fois"],
        ["9oli wach t7eb, w ana njiblek.", "Dis-moi ce que tu veux, et je te l'apporte.", "Question indirecte"]
      ],
      quiz: [
        { t: 'qcm', q: "`Men wa9tach?` =", o: ["depuis quand ?", "à quelle heure ?", "jusqu'à quand ?"], a: 0 },
        { t: 'type', q: "Traduis : « Avec qui ? »", a: ["m3a chkoun", "ma3a chkoun"] },
        { t: 'order', fr: "Je ne sais pas où il est.", a: "Ma3labalich win rah" },
        { t: 'qcm', q: "« Pourquoi tu n'es pas venu ? » :", o: ["3lach ma jitch?", "3lach jit?", "win jit?"], a: 0 }
      ]
    }
  ]
});
