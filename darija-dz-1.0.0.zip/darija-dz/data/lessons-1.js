/* Cours — Étape 1 : débutant absolu.
   Dans les textes, la darija est entourée d'accents graves : `rani labes`.
   Blocs : p (paragraphe), tip (astuce), note (culture), warn (variante / à vérifier),
           table (h = en-têtes, r = lignes), story (lignes [darija, français]).
   words : mots du dictionnaire étudiés dans la leçon (forme darija exacte).
   phrases : [darija, français, contexte].
   quiz : qcm (o = options, a = index), type (a = réponses acceptées), order (a = phrase à reconstituer). */

DZ.addDict('bases', [
  ["wach smitek", "واش سميتك", "comment tu t'appelles ?", "Salam, wach smitek?", "Salut, comment tu t'appelles ?", { v: "wach esmek|wech smitek|wach ismek" }],
  ["smiti", "سميتي", "mon nom ; je m'appelle", "Smiti Yasmine.", "Je m'appelle Yasmine.", { v: "esmi|ismi", n: "Ton nom : smitek ; son nom : smitou (lui), smitha (elle)." }],
  ["ch7al f 3omrek", "شحال في عمرك", "quel âge as-tu ?", "Ch7al f 3omrek, wlidi?", "Quel âge as-tu, mon petit ?", { v: "chhal f3omrek|ch7al f3omrek" }],
  ["fransawi", "فرانساوي", "français (nationalité)", "Sa7bi fransawi.", "Mon ami est français.", { v: "fransaoui|francaoui", n: "Féminin : fransawiya." }],
  ["wach tekhdem", "واش تخدم", "qu'est-ce que tu fais comme travail ?", "Wach tekhdem f 7yatek?", "Que fais-tu dans la vie ?", { v: "wech tekhdem|wach tkhdem" }],
  ["rak", "راك", "tu es (en ce moment, à un homme)", "Win rak?", "Où es-tu ?", { n: "À une femme : raki." }],
  ["raki", "راكي", "tu es (en ce moment, à une femme)", "Win raki?", "Où es-tu ?"],
  ["rah", "راه", "il est (en ce moment)", "Rah f ddar.", "Il est à la maison.", { v: "rahou|raho" }],
  ["raha", "راها", "elle est (en ce moment)", "Raha f lkhedma.", "Elle est au travail.", { v: "rahi" }],
  ["rana", "رانا", "nous sommes (en ce moment)", "Rana jayin.", "Nous arrivons.", { v: "rena" }],
  ["rakoum", "راكم", "vous êtes (en ce moment)", "Wach rakoum?", "Comment allez-vous ?", { v: "rakom" }],
  ["rahoum", "راهم", "ils, elles sont (en ce moment)", "Rahoum bara.", "Ils sont dehors.", { v: "rahom" }],
  ["jay", "جاي", "qui arrive, en route ; prochain", "Rani jay!", "J'arrive !", { v: "jaye|djay", n: "Féminin : jaya ; pluriel : jayin. « Simana jaya » = la semaine prochaine." }],
  ["ch7al rahi sa3a", "شحال راهي الساعة", "quelle heure est-il ?", "Smahli, ch7al rahi sa3a?", "Pardon, quelle heure est-il ?", { v: "chhal rahi sa3a|ch7al sa3a|ch7al rahi essa3a" }],
  ["rahi", "راهي", "il est (pour l'heure) ; elle est", "Rahi tlata w nos.", "Il est trois heures et demie.", { v: "rahy" }],
  ["3awed", "عاود", "répète ; recommence", "3awed, allah ykhallik.", "Répète, s'il te plaît.", { v: "3awd|3aoud", n: "À une femme : 3awdi." }],
  ["bel fransiya", "بالفرانسية", "en français", "Ta3ref tahder bel fransiya?", "Tu sais parler français ?", { v: "bel fransi|bel francais|bel fransawiya" }],
  ["darija", "دارجة", "la darija (l'arabe parlé)", "N7eb net3allem darija.", "Je veux apprendre la darija.", { v: "derja|dardja|darja|ddarja", n: "En Algérie on dit aussi « dzayriya » ou « derja »." }],
  ["win kayen", "وين كاين", "où se trouve… ? (masculin)", "Smahli, win kayen sbitar?", "Pardon, où se trouve l'hôpital ?", { v: "win kain", n: "Féminin : win kayna ?" }],
  ["sallemli 3la", "سلملي على", "passe le bonjour à", "Sallemli 3la yemmak.", "Passe le bonjour à ta mère.", { v: "salemli 3la|sallamli 3la" }]
]);

DZ.setGuide({
  id: 'guide',
  title: "Lire et écrire la darija en lettres latines"
});

DZ.addStage({
  id: 's1', n: 1,
  title: "Débutant absolu",
  dz: "Nebdaw men zéro",
  desc: "Les bases pour saluer, se présenter, compter et poser ses premières questions.",
  lessons: [
    {
      id: 's1-l0', dz: "Nekteb darija", t: "Lire et écrire la darija en lettres latines", min: 12,
      goal: "Comprendre comment les Algériens écrivent la darija avec des lettres et des chiffres.",
      blocks: [
        { k: 'p', x: "Sur WhatsApp, Messenger ou les réseaux sociaux, la plupart des Algériens écrivent la darija avec l'alphabet latin, en ajoutant des chiffres pour les sons qui n'existent pas en français. C'est cette écriture que vous allez apprendre ici, dans toute l'application." },
        { k: 'table', h: ["Écriture", "Lettre arabe", "Comment le prononcer", "Exemple"], r: [
          ["`3`", "ع", "Son sonore serré au fond de la gorge, comme un « a » étranglé.", "`3andi` (j'ai), `ma3lich`"],
          ["`7`", "ح", "« h » soufflé fort, gorge serrée, comme pour embuer une vitre.", "`7out` (poisson), `n7eb`"],
          ["`9`", "ق", "« k » prononcé tout au fond de la gorge. Dans beaucoup de régions, il devient « g ».", "`9ahwa` (café), `9oli`"],
          ["`kh` (ou `5`)", "خ", "Comme la jota espagnole ou le « ch » allemand de « Bach ».", "`khobz` (pain), `khouya`"],
          ["`gh`", "غ", "Comme un « r » parisien bien grasseyé.", "`ghedwa` (demain), `ghali`"],
          ["`ch`", "ش", "« ch » français.", "`chwiya` (un peu)"],
          ["`j` (ou `dj`)", "ج", "« j » français ; on garde souvent « dj » dans les noms.", "`jari` (mon voisin), Djelfa"],
          ["`ou`", "و (voyelle)", "« ou » français.", "`khouya`, `yakoul`"],
          ["`w`", "و (consonne)", "« w » de « whisky ».", "`wa7ed` (un)"],
          ["`y`", "ي (consonne)", "« y » de « yoga ».", "`yemma` (maman)"],
          ["`2`", "ء", "Petit arrêt de la voix, assez rare en darija.", "`ra2y` (avis)"],
          ["`h`", "ه", "« h » léger, juste expiré.", "`hna` (ici)"],
          ["`r`", "ر", "« r » roulé, comme en espagnol.", "`rani`"],
          ["`e`", "voyelle brève", "Voyelle courte, presque avalée.", "`nekhdem`"]
        ] },
        { k: 'p', x: "Dans un mot, le chiffre est une lettre : `ma3lich` se lit « ma-ʕ-lich ». Il ne faut jamais le remplacer par une lettre ordinaire : `n7eb` (je veux) et `nheb` ne se prononcent pas pareil. En revanche, un nombre isolé reste un nombre : dans `3andi 25 sna`, le « 25 » veut dire vingt-cinq." },
        { k: 'tip', x: "Convention de l'application : `kh` pour خ, `j` pour ج, `ch` pour ش, `ou` pour le son « ou ». Les variantes courantes sont acceptées partout (recherche et exercices) : `5` ou `kh`, `dj` ou `j`, `ou`, `o` ou `u`, lettres doublées ou non, voyelles a/e." },
        { k: 'p', x: "Les voyelles varient beaucoup d'une personne à l'autre : `labes`, `labas` et `labess` désignent le même mot. Ne vous bloquez pas sur l'orthographe des voyelles ; concentrez-vous sur les consonnes et les chiffres, qui portent le sens." },
        { k: 'warn', x: "Il n'existe pas d'orthographe officielle de la darija, ni en lettres latines ni en lettres arabes. L'écriture arabe proposée dans l'application (bouton « Arabe ») est une écriture possible parmi d'autres." },
        { k: 'note', x: "Les sons « emphatiques » ص ط ض ظ s'écrivent simplement `s`, `t`, `d` : on ne les distingue pas dans l'écriture courante. Vous les apprendrez à l'oreille." },
        { k: 'warn', x: "Le `9` (ق) se prononce « q » dans plusieurs villes (Alger notamment), « g » dans beaucoup d'autres régions (`9al` → « gal »), et à Tlemcen il est souvent remplacé par un petit arrêt de voix. Ces répartitions sont simplifiées : écoutez les gens autour de vous." }
      ],
      words: ["3andi", "ma3lich", "n7eb", "9ahwa", "khobz", "ghedwa", "chwiya", "wa7ed", "yemma", "ra2y"],
      phrases: [
        ["N7eb net3allem darija.", "Je veux apprendre la darija.", "Parler de son apprentissage"],
        ["Ma3lich, 3awed b chwiya.", "Ce n'est pas grave, répète lentement.", "Demander de répéter"],
        ["3andi khobz w 9ahwa.", "J'ai du pain et du café.", "Lire les sons 3, kh et 9"]
      ],
      quiz: [
        { t: 'qcm', q: "Quel chiffre représente la lettre ع ?", o: ["3", "7", "9"], a: 0, e: "`3` ressemble à ع retourné : c'est le son guttural sonore, comme dans `3andi`." },
        { t: 'qcm', q: "Dans `n7eb`, le 7 se prononce :", o: ["comme un h soufflé du fond de la gorge", "comme le chiffre sept", "comme un k"], a: 0, e: "Le `7` représente ح, un « h » soufflé et serré." },
        { t: 'qcm', q: "Quelle écriture est acceptée pour خ ?", o: ["kh ou 5", "gh ou 8", "ch ou 6"], a: 0, e: "`khobz` et `5obz` désignent le même mot. L'application utilise `kh` comme forme principale." },
        { t: 'qcm', q: "Dans la phrase « 3andi 25 sna », que représente « 25 » ?", o: ["le nombre vingt-cinq", "deux lettres arabes", "une abréviation"], a: 0, e: "Un nombre isolé reste un nombre. Le chiffre ne devient une lettre qu'à l'intérieur d'un mot." },
        { t: 'type', q: "Écris en darija : « café »", a: ["9ahwa", "qahwa", "gahwa"], e: "`9ahwa` : le 9 représente ق." }
      ]
    },
    {
      id: 's1-l1', dz: "Salam w sa7a", t: "Les salutations", min: 10,
      goal: "Saluer quelqu'un, demander comment il va, répondre et prendre congé.",
      blocks: [
        { k: 'p', x: "En Algérie, on salue presque toujours en demandant des nouvelles. Une salutation complète enchaîne souvent plusieurs questions : `labes?`, `wach rak?`, `kirak?`, `l3ayla labes?`… On peut en poser trois ou quatre à la suite, et répondre `l7amdoullah` à chacune." },
        { k: 'table', h: ["Situation", "Darija", "Réponse"], r: [
          ["Salut (familier)", "`salam` / `sa7a`", "`salam` / `sa7a`"],
          ["Bonjour (respectueux)", "`salam 3likoum`", "`3likoum salam`"],
          ["Le matin", "`sba7 el khir`", "`sba7 ennour`"],
          ["Le soir", "`msa el khir`", "`msa ennour` ou `msa el khir`"],
          ["Ça va ?", "`labes?`", "`labes, l7amdoullah`"],
          ["Au revoir", "`bslama`", "`bslama`, `nchoufek`"],
          ["Bonne nuit", "`tsba7 3la khir`", "`w nta men ahlou`"]
        ] },
        { k: 'tip', x: "Le genre compte : on demande `wach rak?` à un homme, `wach raki?` à une femme et `wach rakoum?` à plusieurs personnes. Même logique pour `kirak?` / `kiraki?` / `kirakoum?`." },
        { k: 'note', x: "`Sa7a` est un mot à tout faire : salut, merci, bravo… Le ton fait le sens. Entre amis, on entend aussi beaucoup de français (« salut », « ça va ») mêlé à la darija : c'est parfaitement naturel." },
        { k: 'note', x: "Avec une personne âgée, préférez `salam 3likoum` et appelez-la `khalti` (madame) ou `3ammi` (monsieur), même si elle ne fait pas partie de votre famille." }
      ],
      words: ["salam", "salam 3likoum", "3likoum salam", "sa7a", "labes", "rani labes", "wach rak", "wach raki", "kirak", "kiraki", "l7amdoullah", "sba7 el khir", "sba7 ennour", "msa el khir", "bslama", "nchoufek", "tsba7 3la khir", "ya3tik sa7a"],
      phrases: [
        ["Salam, wach rak? Labes?", "Salut, comment tu vas ? Ça va ?", "Saluer un ami"],
        ["Labes, l7amdoullah. W nta?", "Ça va, Dieu merci. Et toi ?", "Répondre et retourner la question"],
        ["Sba7 el khir khalti, kiraki?", "Bonjour madame, comment allez-vous ?", "Saluer une dame âgée le matin"],
        ["Yallah, bslama, nchoufek ghedwa.", "Allez, au revoir, à demain.", "Prendre congé"]
      ],
      quiz: [
        { t: 'qcm', q: "Comment demander « comment vas-tu ? » à une femme ?", o: ["wach raki?", "wach rak?", "wach rakoum?"], a: 0, e: "On ajoute -i pour une femme : `rak` → `raki`." },
        { t: 'qcm', q: "Quelle est la réponse à `salam 3likoum` ?", o: ["3likoum salam", "sba7 ennour", "bslama"], a: 0, e: "On retourne la formule : `3likoum salam` (et sur vous la paix)." },
        { t: 'type', q: "Traduis en darija : « Je vais bien »", a: ["rani labes", "labes", "rani mli7", "ana labes"], e: "`Rani labes` est la réponse la plus courante." },
        { t: 'order', fr: "Salut, comment tu vas ?", a: "Salam wach rak" },
        { t: 'qcm', q: "Le soir, en arrivant, on dit :", o: ["msa el khir", "sba7 el khir", "tsba7 3la khir"], a: 0, e: "`tsba7 3la khir` (bonne nuit) se dit au moment de se quitter pour dormir." }
      ]
    },
    {
      id: 's1-l2', dz: "Ana smiti…", t: "Se présenter", min: 10,
      goal: "Dire son nom, son origine, son âge et son métier.",
      blocks: [
        { k: 'p', x: "Au présent, la darija n'a pas besoin du verbe « être » : `ana Karim` = je suis Karim ; `ana dzayri` = je suis algérien." },
        { k: 'table', h: ["Question", "Réponse possible"], r: [
          ["`Wach smitek?` — Comment tu t'appelles ?", "`Smiti Karim.` / `Ana Karim.`"],
          ["`Mnin nta?` — D'où es-tu ?", "`Ana men Dzayer.` / `Ana men Fransa.`"],
          ["`Ch7al f 3omrek?` — Quel âge as-tu ?", "`3andi tlatin sna.`"],
          ["`Wach tekhdem?` — Que fais-tu comme travail ?", "`Nekhdem f charika.` / `Ana étudiant.`"],
          ["`Win taskoun?` — Où habites-tu ?", "`Naskoun f Wahran.`"]
        ] },
        { k: 'tip', x: "« Ton nom » se dit `smitek`, « son nom » `smitou` (lui) ou `smitha` (elle). À une femme, on demande `mnin nti?` (d'où es-tu ?)." },
        { k: 'p', x: "Nationalités : algérien `dzayri` (féminin `dzayriya`), français `fransawi` (féminin `fransawiya`). Pour dire « marié », `mzawej` ; « célibataire », `3azri` pour un homme." },
        { k: 'note', x: "Pour répondre à une présentation, on dit `mtcharfin` ou `tcharafna` (enchanté). Il est courant de demander tout de suite des nouvelles de la famille." }
      ],
      words: ["ana", "smiti", "wach smitek", "mnin", "dzayri", "fransawi", "ch7al f 3omrek", "sna", "wach tekhdem", "nekhdem", "naskoun", "mtcharfin", "mzawej", "3azri"],
      phrases: [
        ["Salam, ana Sofiane, men Wahran.", "Salut, je suis Sofiane, d'Oran.", "Se présenter rapidement"],
        ["3andi khamsa w 3achrin sna, w nekhdem f charika.", "J'ai vingt-cinq ans et je travaille dans une entreprise.", "Âge et travail"],
        ["Ana fransawi, bsa7 baba dzayri.", "Je suis français, mais mon père est algérien.", "Parler de ses origines"],
        ["Mtcharfin, ana Lina.", "Enchantée, moi c'est Lina.", "Répondre à une présentation"]
      ],
      quiz: [
        { t: 'qcm', q: "`Wach smitek?` veut dire :", o: ["Comment tu t'appelles ?", "Où habites-tu ?", "Quel âge as-tu ?"], a: 0 },
        { t: 'type', q: "Traduis : « Je suis d'Alger »", a: ["ana men dzayer", "ana mel dzayer", "ana men dzair"], e: "`Dzayer` désigne Alger (et aussi l'Algérie)." },
        { t: 'qcm', q: "Pour dire « enchanté », on dit :", o: ["mtcharfin", "mabrouk", "ma3lich"], a: 0 },
        { t: 'order', fr: "J'habite à Oran.", a: "Naskoun f Wahran" },
        { t: 'type', q: "Traduis : « Je m'appelle Karim »", a: ["smiti karim", "ana karim", "esmi karim"] }
      ]
    },
    {
      id: 's1-l3', dz: "Ana, nta, houwa…", t: "Les pronoms personnels", min: 10,
      goal: "Connaître les pronoms et utiliser `rani`, `rak`, `rah`…",
      blocks: [
        { k: 'table', h: ["Darija", "Français"], r: [
          ["`ana`", "je, moi"], ["`nta`", "tu, toi (homme)"], ["`nti`", "tu, toi (femme)"], ["`houwa`", "il, lui"],
          ["`hiya`", "elle"], ["`7na`", "nous"], ["`ntouma`", "vous"], ["`houma`", "ils, elles"]
        ] },
        { k: 'p', x: "On peut simplement juxtaposer le pronom et l'adjectif : `ana 3ayan` (je suis fatigué). Mais très souvent, on utilise une forme typique de l'Algérie : `rani`, `rak`, `rah`… qui signifie « je suis (là, en ce moment) »." },
        { k: 'table', h: ["Forme", "Sens", "Exemple"], r: [
          ["`rani`", "je suis", "`rani hna` (je suis ici)"],
          ["`rak` / `raki`", "tu es (homme / femme)", "`win rak?` (où es-tu ?)"],
          ["`rah` / `raha`", "il est / elle est", "`rah f ddar` (il est à la maison)"],
          ["`rana`", "nous sommes", "`rana jayin` (on arrive)"],
          ["`rakoum`", "vous êtes", "`wach rakoum?` (comment allez-vous ?)"],
          ["`rahoum`", "ils, elles sont", "`rahoum bara` (ils sont dehors)"]
        ] },
        { k: 'tip', x: "`Rani` + verbe au présent exprime une action en cours : `rani nakoul` = je suis en train de manger." },
        { k: 'warn', x: "Dans l'Est (Constantine, Annaba…), `nti` sert souvent pour « tu » au masculin comme au féminin. L'application utilise `nta` / `nti` comme référence." }
      ],
      words: ["ana", "nta", "nti", "houwa", "hiya", "7na", "ntouma", "houma", "rani", "rak", "raki", "rah", "raha", "rana", "rakoum", "rahoum", "jay"],
      phrases: [
        ["Ana w nta, rana s7ab.", "Toi et moi, on est amis.", "Pronoms + rana"],
        ["Rah f lkhedma, w hiya raha f ddar.", "Il est au travail, et elle est à la maison.", "Il / elle"],
        ["Rani nakoul, n3ayetlek ba3d.", "Je suis en train de manger, je te rappelle plus tard.", "Action en cours"],
        ["Win rakoum? Rana jayin!", "Où êtes-vous ? On arrive !", "Au téléphone"]
      ],
      quiz: [
        { t: 'qcm', q: "Comment dit-on « nous » ?", o: ["7na", "ntouma", "houma"], a: 0 },
        { t: 'qcm', q: "`Raki` s'adresse à :", o: ["une femme", "un homme", "plusieurs personnes"], a: 0 },
        { t: 'type', q: "Traduis : « Je suis fatigué »", a: ["rani 3ayan", "ana 3ayan", "rani 3ayyan"] },
        { t: 'order', fr: "Il est à la maison.", a: "Rah f ddar" },
        { t: 'qcm', q: "`Rana jayin` veut dire :", o: ["On arrive", "Ils sont partis", "Vous êtes là"], a: 0 }
      ]
    },
    {
      id: 's1-l4', dz: "Ih wela la?", t: "Oui et non", min: 8,
      goal: "Dire oui, non, et nuancer sa réponse poliment.",
      blocks: [
        { k: 'p', x: "Oui se dit `ih` (le plus courant) ou `wah` (fréquent dans l'Ouest). Non se dit `la`. Pour insister : `ih ih`, `la la`." },
        { k: 'p', x: "`Machi` nie un mot ou une idée : `machi ana` (ce n'est pas moi), `machi ghali` (pas cher). Pour nier un verbe, on utilise `ma … ch` : `ma n7ebch` (je ne veux pas). Voir la fiche de grammaire sur la négation." },
        { k: 'table', h: ["Darija", "Sens"], r: [
          ["`akid`", "c'est sûr"], ["`balak`", "peut-être"], ["`yemken`", "c'est possible"], ["`nchoufou`", "on verra"],
          ["`inchallah`", "si Dieu le veut / peut-être"], ["`sa7`", "c'est vrai"], ["`machi sa7`", "ce n'est pas vrai"], ["`normal`", "pas de souci"]
        ] },
        { k: 'note', x: "Refuser directement peut paraître sec. On adoucit souvent : `la, ya3tik sa7a` (non, merci), `nchoufou` (on verra), `inchallah`. Quand on vous offre à manger, l'hôte insistera souvent : refuser deux fois avant d'accepter est un jeu de politesse courant." },
        { k: 'warn', x: "`Wakha` (d'accord) est marocain. En Algérie, on dit plutôt `d'accord`, `ok`, `sa7a` ou `mli7`." }
      ],
      words: ["ih", "wah", "la", "machi", "akid", "balak", "yemken", "nchoufou", "inchallah", "sa7", "normal", "mouwafe9", "wallah"],
      phrases: [
        ["Ih, akid nji.", "Oui, je viens, c'est sûr.", "Accepter"],
        ["La, ya3tik sa7a, chba3t.", "Non merci, je n'ai plus faim.", "Refuser poliment de la nourriture"],
        ["Balak nji, nchoufou.", "Je viendrai peut-être, on verra.", "Rester vague"],
        ["Machi ana, wallah!", "Ce n'est pas moi, je te jure !", "Nier"]
      ],
      quiz: [
        { t: 'qcm', q: "`Balak` (seul) veut dire :", o: ["peut-être", "attention", "jamais"], a: 0, e: "Attention : `rod balek` = fais attention ; `balak` seul = peut-être." },
        { t: 'qcm', q: "Quel mot est marocain et à éviter pour « d'accord » en Algérie ?", o: ["wakha", "mli7", "normal"], a: 0 },
        { t: 'type', q: "Traduis : « Ce n'est pas moi »", a: ["machi ana"] },
        { t: 'order', fr: "Non merci, je n'ai plus faim.", a: "La ya3tik sa7a chba3t" },
        { t: 'qcm', q: "Pour répondre « on verra » sans s'engager :", o: ["nchoufou", "akid", "sa7"], a: 0 }
      ]
    },
    {
      id: 's1-l5', dz: "Wa7ed, zouj, tlata", t: "Les chiffres", min: 12,
      goal: "Compter jusqu'à mille et comprendre un prix.",
      blocks: [
        { k: 'table', h: ["Chiffre", "Darija", "Chiffre", "Darija"], r: [
          ["1", "`wa7ed`", "6", "`setta`"], ["2", "`zouj`", "7", "`seb3a`"], ["3", "`tlata`", "8", "`tmenya`"],
          ["4", "`rab3a`", "9", "`tes3a`"], ["5", "`khamsa`", "10", "`3achra`"]
        ] },
        { k: 'p', x: "De 11 à 19, les nombres se terminent par `-tach` : `7dach` (11), `tnach` (12), `tlatach` (13), `rba3tach` (14), `khamstach` (15)… Les dizaines se terminent par `-in` : `3achrin` (20), `tlatin` (30), `rab3in` (40), `khamsin` (50)." },
        { k: 'p', x: "Pour 21, 32, etc., on dit l'unité d'abord : `wa7ed w 3achrin` (21), `zouj w tlatin` (32). Cent : `mya` ; deux cents : `mitin` ; cinq cents : `khamsmya` ; mille : `alf`." },
        { k: 'p', x: "Avec un nom : `zouj` + pluriel (`zouj khobzat`, deux pains). De 3 à 10, le nom est au pluriel ; à partir de 11, il revient souvent au singulier : `3achrin sna` (vingt ans)." },
        { k: 'warn', x: "Les prix : beaucoup d'Algériens comptent en centimes. « `Mitin alf` » peut alors signifier 200 000 centimes, soit 2 000 DA. Cet usage varie selon les personnes ; en cas de doute, demandez : `b dinar wela b centime?`" },
        { k: 'tip', x: "Un nombre écrit seul reste un nombre (`25`), mais dans un mot, `3`, `7` et `9` sont des lettres." }
      ],
      words: ["wa7ed", "zouj", "tlata", "rab3a", "khamsa", "setta", "seb3a", "tmenya", "tes3a", "3achra", "7dach", "tnach", "3achrin", "wa7ed w 3achrin", "tlatin", "khamsin", "mya", "mitin", "khamsmya", "alf", "nos", "rob3"],
      phrases: [
        ["Ch7al hada? — Mya w khamsin dinar.", "C'est combien ? — Cent cinquante dinars.", "Au marché"],
        ["3andi zouj khawti.", "J'ai deux frères et sœurs.", "Parler de sa famille"],
        ["A3tini nos kilo batata.", "Donne-moi un demi-kilo de pommes de terre.", "Faire les courses"],
        ["Rana tlata.", "Nous sommes trois.", "Au restaurant"]
      ],
      quiz: [
        { t: 'qcm', q: "Comment dit-on 2 ?", o: ["zouj", "tnach", "tlata"], a: 0 },
        { t: 'qcm', q: "`7dach` =", o: ["11", "7", "17"], a: 0 },
        { t: 'type', q: "Écris 20 en darija.", a: ["3achrin"] },
        { t: 'type', q: "Écris 21 en darija.", a: ["wa7ed w 3achrin", "wa7ed ou 3achrin"], e: "L'unité d'abord : `wa7ed w 3achrin`." },
        { t: 'qcm', q: "`Nos kilo` =", o: ["un demi-kilo", "neuf kilos", "un quart de kilo"], a: 0 }
      ]
    },
    {
      id: 's1-l6', dz: "Lyoum, ghedwa, ch7al rahi sa3a?", t: "Jours et heures", min: 12,
      goal: "Dire les jours, demander et donner l'heure, se situer dans le temps.",
      blocks: [
        { k: 'table', h: ["Darija", "Français"], r: [
          ["`nhar l7ad`", "dimanche"], ["`nhar letnin`", "lundi"], ["`nhar tlata`", "mardi"], ["`nhar larb3a`", "mercredi"],
          ["`nhar lkhmis`", "jeudi"], ["`nhar ljem3a`", "vendredi"], ["`nhar sebt`", "samedi"]
        ] },
        { k: 'note', x: "En Algérie, le week-end est le vendredi et le samedi : la semaine de travail commence le dimanche." },
        { k: 'p', x: "Pour demander l'heure : `ch7al rahi sa3a?` Réponse : `rahi` + nombre : `rahi tlata` (il est trois heures), `rahi l wa7da` (il est une heure)." },
        { k: 'table', h: ["Darija", "Sens", "Exemple"], r: [
          ["`w rob3`", "et quart", "`tlata w rob3` (3 h 15)"],
          ["`w nos`", "et demie", "`tlata w nos` (3 h 30)"],
          ["`ghir rob3`", "moins le quart", "`rab3a ghir rob3` (3 h 45)"],
          ["`w 3achra`", "et dix", "`setta w 3achra` (6 h 10)"],
          ["`ghir 3achra`", "moins dix", "`seb3a ghir 3achra` (6 h 50)"]
        ] },
        { k: 'table', h: ["Darija", "Français"], r: [
          ["`lyoum`", "aujourd'hui"], ["`ghedwa`", "demain"], ["`lbare7`", "hier"], ["`ba3d ghedwa`", "après-demain"],
          ["`dorka`", "maintenant"], ["`sba7`", "le matin"], ["`l3achiya`", "l'après-midi"], ["`lil`", "la nuit"]
        ] },
        { k: 'tip', x: "Les mois se disent le plus souvent en français (janvier, février…), ou par leur numéro : `chhar zouj` = le mois deux, février." }
      ],
      words: ["nhar l7ad", "nhar letnin", "nhar tlata", "nhar larb3a", "nhar lkhmis", "nhar ljem3a", "nhar sebt", "lyoum", "ghedwa", "lbare7", "ba3d ghedwa", "dorka", "ch7al rahi sa3a", "rahi", "sa3a", "d9i9a", "sba7", "l3achiya", "lil", "simana", "chhar"],
      phrases: [
        ["Ch7al rahi sa3a? — Rahi tlata w rob3.", "Quelle heure est-il ? — Il est trois heures et quart.", "Demander l'heure"],
        ["Nchoufek nhar lkhmis f l3achiya.", "On se voit jeudi après-midi.", "Fixer un rendez-vous"],
        ["Lbare7 kount f ddar, w ghedwa nrou7 l lkhedma.", "Hier j'étais à la maison, et demain je vais au travail.", "Hier et demain"],
        ["Stenna 3achra d9aye9.", "Attends dix minutes.", "Faire patienter"]
      ],
      quiz: [
        { t: 'qcm', q: "`Ghedwa` =", o: ["demain", "hier", "aujourd'hui"], a: 0 },
        { t: 'qcm', q: "En Algérie, la semaine de travail commence :", o: ["nhar l7ad (dimanche)", "nhar letnin (lundi)", "nhar sebt (samedi)"], a: 0 },
        { t: 'type', q: "Traduis : « Il est trois heures et demie »", a: ["rahi tlata w nos", "tlata w nos", "rahi tlata ou nos"] },
        { t: 'order', fr: "Quelle heure est-il ?", a: "Ch7al rahi sa3a" },
        { t: 'qcm', q: "`Khamsa ghir rob3` =", o: ["5 h moins le quart", "5 h et quart", "4 h 15"], a: 0 }
      ]
    },
    {
      id: 's1-l7', dz: "Yemma, baba w khawti", t: "La famille", min: 10,
      goal: "Parler de sa famille et s'adresser poliment aux aînés.",
      blocks: [
        { k: 'p', x: "Les mots de parenté distinguent le côté du père et celui de la mère : `3ammi` (oncle paternel) / `khali` (oncle maternel), `3amti` / `khalti` (tantes)." },
        { k: 'table', h: ["Mon / ma", "Ton / ta", "Son / sa (lui)"], r: [
          ["`yemma` (ma mère)", "`yemmak`", "`yemmah`"],
          ["`baba` (mon père)", "`babak`", "`babah`"],
          ["`khouya` (mon frère)", "`khouk`", "`khouh`"],
          ["`khti` (ma sœur)", "`khtek`", "`khtou`"]
        ] },
        { k: 'note', x: "`Khalti` et `3ammi` servent aussi à s'adresser poliment à une personne plus âgée qu'on ne connaît pas, comme « madame » ou « monsieur ». `Khouya` (mon frère) et `khti` (ma sœur) s'emploient avec n'importe qui de son âge." },
        { k: 'tip', x: "« Les enfants » : `wlad` ou `dhrari`. Un garçon : `weld` ; une fille : `bent`." }
      ],
      words: ["yemma", "baba", "khouya", "khti", "khawti", "jeddi", "jedda", "3ammi", "khali", "3amti", "khalti", "wlidi", "benti", "wlad", "dhrari", "l3ayla", "mrati", "rajli", "mzawej", "sallemli 3la"],
      phrases: [
        ["3andi zouj khawti: khouya w khti.", "J'ai deux frères et sœurs : mon frère et ma sœur.", "Présenter sa fratrie"],
        ["Khali yaskoun f Wahran m3a wladou.", "Mon oncle habite à Oran avec ses enfants.", "Parler de ses oncles"],
        ["Sallemli 3la yemmak.", "Passe le bonjour à ta mère.", "Formule de politesse"],
        ["Nta mzawej? — La, mazal 3azri.", "Tu es marié ? — Non, je suis encore célibataire.", "Situation familiale"]
      ],
      quiz: [
        { t: 'qcm', q: "`Khali` est :", o: ["l'oncle du côté de la mère", "l'oncle du côté du père", "le grand-père"], a: 0 },
        { t: 'qcm', q: "« Ta mère » se dit :", o: ["yemmak", "yemma", "yemmah"], a: 0 },
        { t: 'type', q: "Traduis : « mon frère »", a: ["khouya", "khoya"] },
        { t: 'order', fr: "Passe le bonjour à ta mère.", a: "Sallemli 3la yemmak" },
        { t: 'qcm', q: "Pour s'adresser poliment à une dame âgée inconnue :", o: ["khalti", "khti", "benti"], a: 0 }
      ]
    },
    {
      id: 's1-l8', dz: "Tilifoun ta3i", t: "Les objets du quotidien", min: 10,
      goal: "Nommer les objets courants et dire à qui ils appartiennent.",
      blocks: [
        { k: 'p', x: "La darija emprunte beaucoup au français pour les objets modernes : `portable`, `chargeur`, `frijidar` (frigidaire), `tomobil` (automobile)… On les prononce à l'algérienne et on y ajoute l'article arabe `l` : `lportable`, `lchargeur`." },
        { k: 'p', x: "Le mot `ta3` exprime l'appartenance : `tilifoun ta3i` (mon téléphone), `lmefta7 ta3 ddar` (la clé de la maison)." },
        { k: 'table', h: ["Darija", "Français"], r: [
          ["`ta3i`", "à moi, mon/ma"], ["`ta3ek`", "à toi"], ["`ta3ou`", "à lui"], ["`ta3ha`", "à elle"],
          ["`ta3na`", "à nous"], ["`ta3koum`", "à vous"], ["`ta3houm`", "à eux"]
        ] },
        { k: 'warn', x: "Dans l'Ouest, on entend aussi `nta3` à la place de `ta3`." }
      ],
      words: ["tilifoun", "portable", "chargeur", "mefta7", "sac", "drahem", "l7wayej", "sebbat", "kas", "9ar3a", "tabla", "kersi", "bab", "ta9a", "dow", "tilifizion", "stylo", "ta3"],
      phrases: [
        ["Win rah lmefta7 ta3i?", "Où est ma clé ?", "Chercher un objet"],
        ["3andek chargeur? Tilifoun ta3i tfa.", "Tu as un chargeur ? Mon téléphone s'est éteint.", "Demander un objet"],
        ["Nsit sac ta3i f taxi!", "J'ai oublié mon sac dans le taxi !", "Un oubli"],
        ["Hada machi ta3i, ta3 khouya.", "Ce n'est pas à moi, c'est à mon frère.", "Appartenance"]
      ],
      quiz: [
        { t: 'qcm', q: "`Mefta7` =", o: ["clé", "téléphone", "porte"], a: 0 },
        { t: 'type', q: "Traduis : « mon téléphone »", a: ["tilifoun ta3i", "portable ta3i", "telephone ta3i", "tilifouni"] },
        { t: 'qcm', q: "`Ta3ha` veut dire :", o: ["à elle", "à lui", "à nous"], a: 0 },
        { t: 'order', fr: "Ce n'est pas à moi.", a: "Hada machi ta3i" }
      ]
    },
    {
      id: 's1-l9', dz: "Wach? Win? 3lach?", t: "Les questions simples", min: 10,
      goal: "Poser les questions essentielles avec les mots interrogatifs.",
      blocks: [
        { k: 'table', h: ["Darija", "Français", "Exemple"], r: [
          ["`wach`", "quoi ? / est-ce que", "`wach t7eb?` (que veux-tu ?)"],
          ["`chkoun`", "qui ?", "`chkoun hada?` (qui est-ce ?)"],
          ["`win`", "où ?", "`win rak?` (où es-tu ?)"],
          ["`mnin`", "d'où ?", "`mnin nta?` (d'où es-tu ?)"],
          ["`wa9tach`", "quand ?", "`wa9tach tji?` (quand viens-tu ?)"],
          ["`kifach`", "comment ?", "`kifach ndir?` (comment je fais ?)"],
          ["`3lach`", "pourquoi ?", "`3lach rak za3fan?`"],
          ["`ch7al`", "combien ?", "`ch7al hada?`"]
        ] },
        { k: 'p', x: "Souvent, une simple intonation montante suffit : `rak mli7?` (tu vas bien ?). On peut aussi commencer par `wach` comme « est-ce que » : `wach nta dzayri?` (est-ce que tu es algérien ?)." },
        { k: 'warn', x: "Ne confondez pas avec les pays voisins : au Maroc `chno` (quoi), `fin` (où), `imta` (quand) ; en Tunisie `chnowa` (quoi). En Algérie : `wach`, `win`, `wa9tach`." }
      ],
      words: ["wach", "chkoun", "win", "mnin", "wa9tach", "kifach", "3lach", "ch7al", "wachmen", "wach bik", "wach sra", "wach jdid"],
      phrases: [
        ["Win rak? — Rani f ddar.", "Où es-tu ? — Je suis à la maison.", "Localiser quelqu'un"],
        ["3lach ma jitch lbare7?", "Pourquoi tu n'es pas venu hier ?", "Demander une raison"],
        ["Kifach nrou7 l lbosta?", "Comment je vais à la poste ?", "Demander un chemin"],
        ["Chkoun hadak? — Hada khouya.", "Qui est celui-là ? — C'est mon frère.", "Identifier quelqu'un"]
      ],
      quiz: [
        { t: 'qcm', q: "`Wa9tach` =", o: ["quand ?", "où ?", "combien ?"], a: 0 },
        { t: 'qcm', q: "Le mot algérien pour « où ? » est :", o: ["win", "fin", "imta"], a: 0, e: "`fin` est surtout marocain ; `imta` (quand) aussi." },
        { t: 'type', q: "Traduis : « Pourquoi ? »", a: ["3lach", "3lech"] },
        { t: 'order', fr: "Comment je vais à la poste ?", a: "Kifach nrou7 l lbosta" },
        { t: 'qcm', q: "`Wach bik?` veut dire :", o: ["Qu'est-ce que tu as ?", "Où vas-tu ?", "Avec qui es-tu ?"], a: 0 }
      ]
    },
    {
      id: 's1-l10', dz: "Ma fhemtch, 3awed!", t: "Les phrases essentielles", min: 10,
      goal: "Se débrouiller quand on ne comprend pas et demander de l'aide.",
      blocks: [
        { k: 'p', x: "Ces phrases vous sauveront dans n'importe quelle conversation. Apprenez-les par cœur !" },
        { k: 'table', h: ["Darija", "Français"], r: [
          ["`ma fhemtch`", "je n'ai pas compris"], ["`3awed, allah ykhallik`", "répète, s'il te plaît"],
          ["`hder b chwiya`", "parle lentement"], ["`ma3labalich`", "je ne sais pas"],
          ["`wach ya3ni…?`", "que veut dire… ?"], ["`rani net3allem darija`", "j'apprends la darija"],
          ["`ta3ref tahder bel fransiya?`", "tu sais parler français ?"], ["`win kayen bit lma?`", "où sont les toilettes ?"]
        ] },
        { k: 'tip', x: "Si vous dites `rani net3allem darija`, la plupart des gens ralentiront volontiers et vous aideront." },
        { k: 'note', x: "Le français est largement compris en Algérie, surtout en ville. Mais tenter la darija fait toujours plaisir." }
      ],
      words: ["ma fhemtch", "3awed", "b chwiya", "ma3labalich", "na3ref", "nahder", "net3allem", "darija", "bel fransiya", "makach mouchkil", "ma3lich", "allah ykhallik", "ya3tik sa7a", "bla mziya", "win kayen", "bit lma"],
      phrases: [
        ["Smahli, ma fhemtch. 3awed b chwiya.", "Pardon, je n'ai pas compris. Répète lentement.", "Ne pas comprendre"],
        ["Rani net3allem darija, nahder chwiya bark.", "J'apprends la darija, je ne parle qu'un peu.", "Expliquer son niveau"],
        ["Ta3ref tahder bel fransiya?", "Tu sais parler français ?", "Changer de langue"],
        ["Wach ya3ni « ghaya »?", "Que veut dire « ghaya » ?", "Demander le sens d'un mot"],
        ["Win kayen bit lma, allah ykhallik?", "Où sont les toilettes, s'il te plaît ?", "Demander les toilettes"]
      ],
      quiz: [
        { t: 'qcm', q: "`Ma fhemtch` =", o: ["je n'ai pas compris", "je ne sais pas", "je ne peux pas"], a: 0 },
        { t: 'type', q: "Traduis : « Répète, s'il te plaît »", a: ["3awed allah ykhallik", "3awed brabbi", "3awed svp", "3awed s'il te plait"] },
        { t: 'order', fr: "Parle lentement.", a: "Hder b chwiya" },
        { t: 'qcm', q: "`Ma3labalich` =", o: ["je ne sais pas", "ce n'est pas grave", "je n'ai pas faim"], a: 0 },
        { t: 'type', q: "Traduis : « J'apprends la darija »", a: ["rani net3allem darija", "net3allem darija", "rani nt3alem darija"] }
      ]
    }
  ]
});
