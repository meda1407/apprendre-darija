/* Grammaire — 15 fiches progressives. Explications en français, exemples en darija (lettres latines + chiffres). */

DZ.addGrammar([
  {
    id: 'g-pronoms', n: 1, dz: "Ana, nta, nti…", t: "Les pronoms", lvl: 1,
    blocks: [
      { k: 'p', x: "Les pronoms sujets s'utilisent seuls ou devant un adjectif, un nom ou un verbe. Ils sont souvent omis devant un verbe conjugué, car la conjugaison indique déjà la personne." },
      { k: 'table', h: ["Pronom", "Sens"], r: [["`ana`", "je, moi"], ["`nta`", "tu (homme)"], ["`nti`", "tu (femme)"], ["`houwa`", "il"], ["`hiya`", "elle"], ["`7na`", "nous"], ["`ntouma`", "vous"], ["`houma`", "ils, elles"]] },
      { k: 'p', x: "Les pronoms compléments se collent à la fin du verbe. Complément direct (me, te, le…) :" },
      { k: 'table', h: ["Suffixe", "Sens", "Exemple"], r: [
        ["`-ni`", "me", "`chafni` (il m'a vu)"], ["`-ek`", "te", "`nchoufek` (je te vois)"], ["`-ou`", "le", "`cheftou` (je l'ai vu)"],
        ["`-ha`", "la", "`n7ebha` (je l'aime, elle)"], ["`-na`", "nous", "`3ayetlna` (appelle-nous)"], ["`-koum`", "vous", "`nchoufkoum` (je vous vois)"], ["`-houm`", "les", "`chefthoum` (je les ai vus)"]
      ] },
      { k: 'p', x: "Complément indirect (à moi, à toi…) avec `l` : `9olli` (dis-moi), `n9oullek` (je te dis), `9ollou` (dis-lui), `9olha` (dis-lui, à elle), `jibli` (apporte-moi)." },
      { k: 'tip', x: "Pour insister, on répète le pronom : `ana, ma n7ebch` = moi, je ne veux pas." }
    ],
    ex: [["Chafni w ma sallemch 3liya.", "Il m'a vu et il ne m'a pas salué."], ["9olli wach t7eb.", "Dis-moi ce que tu veux."], ["Nchoufek ghedwa.", "Je te vois demain."]],
    quiz: [
      { t: 'qcm', q: "`Nchoufek` =", o: ["je te vois", "tu me vois", "je le vois"], a: 0 },
      { t: 'qcm', q: "« Dis-moi » se dit :", o: ["9olli", "9ollou", "n9oullek"], a: 0 },
      { t: 'type', q: "Traduis : « je l'ai vu (lui) »", a: ["cheftou", "chefto"] }
    ]
  },
  {
    id: 'g-genre', n: 2, dz: "Kbir, kbira, kbar", t: "Le genre et le nombre", lvl: 1,
    blocks: [
      { k: 'p', x: "Le féminin se forme le plus souvent en ajoutant `-a` : `kbir` → `kbira`, `mli7` → `mli7a`, `far7an` → `far7ana`. Beaucoup de noms féminins se terminent aussi par `-a` : `tomobil` est une exception (féminin sans -a)." },
      { k: 'p', x: "Le pluriel « régulier » : `-in` pour les hommes ou les groupes (`khaddam` → `khaddamin`), `-at` pour les femmes et beaucoup d'objets (`khobza` → `khobzat`, `tomobil` → `tomobilat`)." },
      { k: 'p', x: "Beaucoup de pluriels sont « internes » : la forme du mot change. Il faut les apprendre au fur et à mesure." },
      { k: 'table', h: ["Singulier", "Pluriel", "Sens"], r: [
        ["`weld`", "`wlad`", "garçon(s)"], ["`bent`", "`bnat`", "fille(s)"], ["`rajel`", "`rjal`", "homme(s)"], ["`mra`", "`nsa`", "femme(s)"],
        ["`dar`", "`dyar`", "maison(s)"], ["`ktab`", "`ktouba`", "livre(s)"], ["`sa7bi`", "`s7abi`", "mon ami / mes amis"], ["`kbir`", "`kbar`", "grand(s)"]
      ] },
      { k: 'p', x: "Le duel (deux) existe pour le temps et quelques mesures : `youmin` (deux jours), `3amin` (deux ans), `chahrin` (deux mois). Sinon, on dit `zouj` + pluriel : `zouj wlad`." },
      { k: 'tip', x: "L'article `l` (le, la, les) ne change pas au féminin ni au pluriel. Devant certaines lettres (t, d, s, ch, n, r, z…), il se fond dans la consonne suivante : `ddar` (la maison), `nnas` (les gens), `chchems` ou `echems` (le soleil)." }
    ],
    ex: [["Dar kbira w zouj tomobilat.", "Une grande maison et deux voitures."], ["Wlad 3ammi ga3 khaddamin.", "Mes cousins travaillent tous."], ["Rani hna men youmin.", "Je suis ici depuis deux jours."]],
    quiz: [
      { t: 'qcm', q: "Féminin de `far7an` :", o: ["far7ana", "far7anin", "far7anat"], a: 0 },
      { t: 'qcm', q: "Pluriel de `bent` :", o: ["bnat", "bentin", "bentat"], a: 0 },
      { t: 'qcm', q: "`Youmin` =", o: ["deux jours", "aujourd'hui", "chaque jour"], a: 0 }
    ]
  },
  {
    id: 'g-possessifs', n: 3, dz: "Dari, darek, ta3i", t: "Les possessifs", lvl: 1,
    blocks: [
      { k: 'p', x: "Deux façons d'exprimer la possession : un suffixe collé au nom, ou le mot `ta3` + suffixe." },
      { k: 'table', h: ["Suffixe", "Exemple", "Avec ta3"], r: [
        ["`-i` (mon)", "`dari` (ma maison)", "`ta3i`"], ["`-ek` (ton)", "`darek`", "`ta3ek`"], ["`-ou` (son, à lui)", "`darou`", "`ta3ou`"],
        ["`-ha` (son, à elle)", "`darha`", "`ta3ha`"], ["`-na` (notre)", "`darna`", "`ta3na`"], ["`-koum` (votre)", "`darkoum`", "`ta3koum`"], ["`-houm` (leur)", "`darhoum`", "`ta3houm`"]
      ] },
      { k: 'p', x: "Après une voyelle, les suffixes changent un peu : `khou` (frère) → `khouya` (mon frère), `khouk` (ton frère), `khouh` (son frère)." },
      { k: 'p', x: "Les suffixes s'emploient surtout pour la famille et le corps : `yemmak`, `rassi`, `yeddi`. `Ta3` est préféré pour les objets, surtout les mots empruntés : `tomobil ta3i`, `portable ta3ek`." },
      { k: 'warn', x: "Dans l'Ouest, on entend `nta3` (`hadi nta3i`). Au Maroc, on dit `dyal` : à ne pas confondre." }
    ],
    ex: [["Hadi tomobil ta3 baba.", "C'est la voiture de mon père."], ["Win rah portable ta3ek?", "Où est ton portable ?"], ["Darna 9riba mel b7ar.", "Notre maison est près de la mer."]],
    quiz: [
      { t: 'qcm', q: "`Darna` =", o: ["notre maison", "leur maison", "ta maison"], a: 0 },
      { t: 'type', q: "Traduis : « ma voiture » (avec ta3)", a: ["tomobil ta3i", "loto ta3i", "tonobil ta3i"] },
      { t: 'qcm', q: "« Son frère (à lui) » :", o: ["khouh", "khouya", "khouk"], a: 0 }
    ]
  },
  {
    id: 'g-adjectifs', n: 4, dz: "Dar kbira", t: "Les adjectifs", lvl: 1,
    blocks: [
      { k: 'p', x: "L'adjectif se place après le nom et s'accorde en genre et en nombre : `rajel kbir` (un homme âgé), `mra kbira`, `nas kbar`." },
      { k: 'p', x: "Avec l'article, l'adjectif prend aussi l'article : `ddar lkbira` (la grande maison), `tomobil ljdida` (la nouvelle voiture)." },
      { k: 'p', x: "Sans article sur l'adjectif, on obtient une phrase : `ddar kbira` = la maison est grande." },
      { k: 'table', h: ["Darija", "Sens"], r: [["`khir men`", "mieux que"], ["`ktar men`", "plus que"], ["`kbir 3la`", "plus âgé que (à vérifier selon les régions)"], ["`bezzaf`", "très, trop (après l'adjectif)"]] },
      { k: 'tip', x: "« Très » se dit `bezzaf` placé après l'adjectif : `ghali bezzaf` (très cher)." }
    ],
    ex: [["Tomobil ljdida chbaba bezzaf.", "La nouvelle voiture est très belle."], ["Hada khir men hadak.", "Celui-ci est mieux que celui-là."], ["Khouya kbir 3liya b zouj snin.", "Mon frère a deux ans de plus que moi."]],
    quiz: [
      { t: 'qcm', q: "« La grande maison » :", o: ["ddar lkbira", "ddar kbira", "kbira ddar"], a: 0, e: "`ddar kbira` veut dire « la maison est grande »." },
      { t: 'qcm', q: "`Ghali bezzaf` =", o: ["très cher", "pas cher", "un peu cher"], a: 0 },
      { t: 'type', q: "Traduis : « mieux que »", a: ["khir men"] }
    ]
  },
  {
    id: 'g-questions', n: 5, dz: "Wach, win, wa9tach…", t: "Les questions (mots interrogatifs)", lvl: 1,
    blocks: [
      { k: 'table', h: ["Mot", "Sens", "Exemple"], r: [
        ["`wach`", "quoi / est-ce que", "`wach dert?` (qu'as-tu fait ?)"], ["`chkoun`", "qui", "`chkoun ja?` (qui est venu ?)"],
        ["`win`", "où", "`win rayeh?` (où vas-tu ?)"], ["`mnin`", "d'où", "`mnin jit?` (d'où viens-tu ?)"],
        ["`wa9tach`", "quand", "`wa9tach wselt?`"], ["`kifach`", "comment", "`kifach jit?` (comment es-tu venu ?)"],
        ["`3lach`", "pourquoi", "`3lach rak hna?`"], ["`ch7al`", "combien", "`ch7al 3andek?`"], ["`wachmen`", "lequel", "`wachmen wa7ed?`"]
      ] },
      { k: 'p', x: "Le mot interrogatif se met en début de phrase. Le verbe ne change pas de place." },
      { k: 'p', x: "Avec une préposition : `m3a chkoun?` (avec qui ?), `l win?` (vers où ?), `men wa9tach?` (depuis quand ?), `3la wach?` (sur quoi ?)." }
    ],
    ex: [["Win rayeh, khouya?", "Où vas-tu, mon frère ?"], ["Ch7al 3andek men wlad?", "Combien d'enfants as-tu ?"], ["Kifach jit, b taxi?", "Comment es-tu venu, en taxi ?"]],
    quiz: [
      { t: 'qcm', q: "`Mnin` =", o: ["d'où", "où", "quand"], a: 0 },
      { t: 'type', q: "Traduis : « qui ? »", a: ["chkoun", "chkon"] },
      { t: 'qcm', q: "`Wachmen wa7ed?` =", o: ["Lequel ?", "Qui est-ce ?", "Combien ?"], a: 0 }
    ]
  },
  {
    id: 'g-negation', n: 6, dz: "Ma… ch", t: "La négation", lvl: 1,
    blocks: [
      { k: 'p', x: "Pour nier un verbe, on l'encadre avec `ma` devant et `-ch` derrière : `n7eb` → `ma n7ebch` (je ne veux pas), `fhemt` → `ma fhemtch` (je n'ai pas compris)." },
      { k: 'p', x: "La même règle marche avec `3andi` (j'ai) → `ma 3andich` (je n'ai pas), et avec `kayen` → `makach` / `makanch` (il n'y a pas)." },
      { k: 'p', x: "Pour nier un nom, un adjectif ou une phrase sans verbe, on utilise `machi` : `machi ana` (pas moi), `machi ghali` (pas cher), `machi lyoum` (pas aujourd'hui)." },
      { k: 'table', h: ["« Je suis »", "Négatif", "Sens"], r: [
        ["`rani`", "`manich`", "je ne suis pas"], ["`rak`", "`makch`", "tu n'es pas"], ["`raki`", "`makich`", "tu n'es pas (f.)"],
        ["`rah`", "`mahouch`", "il n'est pas"], ["`raha`", "`mahich`", "elle n'est pas"], ["`rana`", "`manach`", "nous ne sommes pas"]
      ] },
      { k: 'p', x: "Avec `walou` (rien), `7atta wa7ed` (personne) ou `3omri` (jamais), le `-ch` disparaît généralement : `ma chefna walou` (nous n'avons rien vu), `3omri ma rou7t` (je n'y suis jamais allé)." },
      { k: 'p', x: "« Pas encore » : `mazal ma` + verbe : `mazal ma klit`." }
    ],
    ex: [["Ma n7ebch l7out.", "Je n'aime pas le poisson."], ["Manich fahem, 3awed.", "Je ne comprends pas, répète."], ["Machi mouchkil.", "Ce n'est pas un problème."], ["3omri ma klit karantika.", "Je n'ai jamais mangé de karantika."]],
    quiz: [
      { t: 'type', q: "Mets à la forme négative : « n7eb » (je veux)", a: ["ma n7ebch", "man7ebch"] },
      { t: 'qcm', q: "« Je n'ai pas d'argent » :", o: ["ma 3andich drahem", "machi 3andi drahem", "ma 3andi drahemch"], a: 0 },
      { t: 'qcm', q: "Pour nier un adjectif (« pas cher ») :", o: ["machi ghali", "ma ghalich", "ghali ch"], a: 0 },
      { t: 'qcm', q: "« Je ne suis pas » :", o: ["manich", "machi rani", "ma raniich"], a: 0 }
    ]
  },
  {
    id: 'g-prepositions', n: 7, dz: "F, l, men, 3la, m3a", t: "Les prépositions", lvl: 2,
    blocks: [
      { k: 'table', h: ["Préposition", "Sens", "Exemple"], r: [
        ["`f`", "dans, à, en", "`f ddar` (à la maison)"], ["`l`", "à, vers, pour", "`nrou7 l Wahran`"], ["`men`", "de, depuis", "`men Dzayer`"],
        ["`3la`", "sur, à propos de", "`3la tabla` (sur la table)"], ["`m3a`", "avec", "`m3a s7abi`"], ["`b`", "avec (moyen), en", "`b tomobil` (en voiture)"],
        ["`3and`", "chez", "`3and tbib` (chez le médecin)"], ["`bla`", "sans", "`bla sokkar`"], ["`7atta`", "jusqu'à", "`7atta ghedwa`"],
        ["`9bel` / `ba3d`", "avant / après", "`ba3d lmakla`"], ["`fou9` / `ta7t`", "sur / sous", "`ta7t lkersi`"], ["`7da`", "à côté de", "`7da lbosta`"]
      ] },
      { k: 'p', x: "Les prépositions prennent les mêmes suffixes que les noms : `m3aya` (avec moi), `m3ak` (avec toi), `m3ah` (avec lui), `m3aha` (avec elle) ; `3liya` (sur moi), `3lik`, `3lih`, `3liha` ; `fiya`, `fik`, `fih` ; `3andi`, `3andek`, `3andou`." },
      { k: 'tip', x: "`F` + `l` (le) donne souvent `fel` à l'oral : `fel lil` (dans la nuit). De même `men` + `l` → `mel`, `3la` + `l` → `3al`." }
    ],
    ex: [["Arwa7 m3aya l souk.", "Viens avec moi au marché."], ["Lmefta7 ta7t tabla.", "La clé est sous la table."], ["Nkhammem fik.", "Je pense à toi."]],
    quiz: [
      { t: 'qcm', q: "`M3aya` =", o: ["avec moi", "avec toi", "sans moi"], a: 0 },
      { t: 'type', q: "Traduis : « en voiture »", a: ["b tomobil", "bel tomobil", "b loto"] },
      { t: 'qcm', q: "`3and tbib` =", o: ["chez le médecin", "avec le médecin", "sans médecin"], a: 0 }
    ]
  },
  {
    id: 'g-verbes', n: 8, dz: "Nakoul, nrou7, ndir", t: "Les verbes fréquents", lvl: 2,
    blocks: [
      { k: 'p', x: "Une vingtaine de verbes suffit pour la plupart des conversations. Apprenez-les sous trois formes : présent (je…), passé (j'ai…), impératif." },
      { k: 'table', h: ["Sens", "Je (présent)", "J'ai (passé)", "Impératif"], r: [
        ["manger", "`nakoul`", "`klit`", "`kol`"], ["boire", "`nechrob`", "`chrabt`", "`chrob`"], ["aller", "`nrou7`", "`rou7t`", "`rou7`"],
        ["venir", "`nji`", "`jit`", "`arwa7` / `aji`"], ["faire", "`ndir`", "`dert`", "`dir`"], ["dire", "`n9oul`", "`9olt`", "`9oul`"],
        ["voir", "`nchouf`", "`cheft`", "`chouf`"], ["prendre", "`neddi`", "`ddit`", "`eddi`"], ["donner", "`na3ti`", "`3tit`", "`a3ti`"],
        ["savoir", "`na3ref`", "`3reft`", "—"], ["vouloir, aimer", "`n7eb`", "`7ebit`", "—"], ["pouvoir", "`n9der`", "`9dert`", "—"],
        ["travailler", "`nekhdem`", "`khdemt`", "`khdem`"], ["dormir", "`nr9ed`", "`r9adt`", "`r9ed`"], ["se lever", "`nnoud`", "`nodt`", "`noud`"],
        ["parler", "`nahder`", "`hdert`", "`hder`"], ["comprendre", "`nefham`", "`fhemt`", "`fham`"], ["acheter", "`nechri`", "`chrit`", "`chri`"]
      ] },
      { k: 'warn', x: "Les voyelles de ces formes varient selon les personnes (`nakoul` / `nakol`, `chrabt` / `chrebt`). Les consonnes, elles, restent stables. Le verbe « dormir » se prononce avec g dans beaucoup de régions (`nergod`, à vérifier)." }
    ],
    ex: [["Ddit lmefta7 w nsit lportable.", "J'ai pris la clé et j'ai oublié le portable."], ["9olli wach dert.", "Dis-moi ce que tu as fait."], ["Kol w chrob, rak f darek.", "Mange et bois, tu es chez toi."]],
    quiz: [
      { t: 'qcm', q: "« J'ai vu » :", o: ["cheft", "nchouf", "chouf"], a: 0 },
      { t: 'type', q: "Impératif de « manger » (à un homme) :", a: ["kol", "koul"] },
      { t: 'qcm', q: "`9dert` =", o: ["j'ai pu", "j'ai dit", "j'ai décidé"], a: 0 }
    ]
  },
  {
    id: 'g-present', n: 9, dz: "Nekhdem, tekhdem, yekhdem", t: "Le présent", lvl: 2,
    blocks: [
      { k: 'p', x: "Au présent, on ajoute un préfixe (et parfois un suffixe) au verbe. Exemple avec `khdem` (travailler) :" },
      { k: 'table', h: ["Personne", "Forme", "Marque"], r: [
        ["ana", "`nekhdem`", "n-"], ["nta", "`tekhdem`", "t-"], ["nti", "`tekhedmi`", "t- … -i"], ["houwa", "`yekhdem`", "y-"],
        ["hiya", "`tekhdem`", "t-"], ["7na", "`nekhedmou`", "n- … -ou"], ["ntouma", "`tekhedmou`", "t- … -ou"], ["houma", "`yekhedmou`", "y- … -ou"]
      ] },
      { k: 'table', h: ["Personne", "rou7 (aller)", "kla (manger)"], r: [
        ["ana", "`nrou7`", "`nakoul`"], ["nta / hiya", "`trou7`", "`takoul`"], ["nti", "`trou7i`", "`takli`"], ["houwa", "`yrou7`", "`yakoul`"],
        ["7na", "`nrou7ou`", "`naklou`"], ["ntouma", "`trou7ou`", "`taklou`"], ["houma", "`yrou7ou`", "`yaklou`"]
      ] },
      { k: 'p', x: "Le présent exprime l'habitude (`nekhdem kol nhar` = je travaille tous les jours). Pour l'action en cours, on ajoute `rani`, `rak`… : `rani nekhdem` = je suis en train de travailler." },
      { k: 'tip', x: "« Je » et « nous » commencent par `n-` ; « tu » et « elle » par `t-` ; « il » et « ils » par `y-`. Le `-ou` final marque le pluriel." }
    ],
    ex: [["Nekhdem kol nhar men tmenya l khamsa.", "Je travaille tous les jours de huit heures à cinq heures."], ["Rani nakoul, stenna chwiya.", "Je suis en train de manger, attends un peu."], ["Win trou7i nhar sebt?", "Où vas-tu le samedi ? (à une femme)"]],
    quiz: [
      { t: 'qcm', q: "« Il travaille » :", o: ["yekhdem", "nekhdem", "tekhdem"], a: 0 },
      { t: 'qcm', q: "« Nous allons » :", o: ["nrou7ou", "nrou7", "trou7ou"], a: 0 },
      { t: 'type', q: "« Je suis en train de manger »", a: ["rani nakoul", "rani nakol"] }
    ]
  },
  {
    id: 'g-passe', n: 10, dz: "Klit, rou7t, cheft", t: "Le passé", lvl: 2,
    blocks: [
      { k: 'p', x: "Au passé, les terminaisons viennent après le verbe. Exemple avec `kteb` (écrire) :" },
      { k: 'table', h: ["Personne", "Forme", "Terminaison"], r: [
        ["ana / nta", "`ktebt`", "-t"], ["nti", "`ktebti`", "-ti"], ["houwa", "`kteb`", "—"], ["hiya", "`ketbet`", "-et"],
        ["7na", "`ktebna`", "-na"], ["ntouma", "`ktebtou`", "-tou"], ["houma", "`ketbou`", "-ou"]
      ] },
      { k: 'p', x: "Les verbes en « voyelle longue » changent un peu : `ra7` (il est allé) → `rou7t` (je suis allé) ; `chaf` (il a vu) → `cheft` ; `kla` (il a mangé) → `klit` ; `ja` (il est venu) → `jit`." },
      { k: 'p', x: "Pour l'état passé, « j'étais » : `kount`, « il était » : `kan`. Pour l'habitude passée : `kount` + présent : `kount nal3ab football` (je jouais au foot)." }
    ],
    ex: [["Lbare7 ktebtlek message.", "Hier je t'ai écrit un message."], ["Kount nskoun f Wahran.", "J'habitais à Oran."], ["Jat yemma w jabet l7elwa.", "Ma mère est venue et a apporté des gâteaux."]],
    quiz: [
      { t: 'qcm', q: "« Elle a écrit » :", o: ["ketbet", "ktebt", "kteb"], a: 0 },
      { t: 'type', q: "« Je suis venu »", a: ["jit", "djit"] },
      { t: 'qcm', q: "`Kount nal3ab` =", o: ["je jouais", "je vais jouer", "j'ai joué une fois"], a: 0 }
    ]
  },
  {
    id: 'g-futur', n: 11, dz: "Ra7 nrou7", t: "Le futur", lvl: 2,
    blocks: [
      { k: 'p', x: "Le futur se forme avec `ra7` + verbe au présent : `ra7 nrou7` (je vais aller / j'irai), `ra7 tfham` (tu vas comprendre)." },
      { k: 'p', x: "`Rani rayeh` + présent insiste sur l'intention ou l'imminence : `rani rayeh nakoul` (je vais manger, là)." },
      { k: 'p', x: "Le simple présent avec un mot de temps suffit souvent : `ghedwa nsafer` (demain je pars)." },
      { k: 'warn', x: "`Ghadi` (futur) s'entend dans certaines régions de l'Ouest et au Maroc. Si vous l'entendez, c'est le même sens que `ra7`." }
    ],
    ex: [["Ra7 nchoufek ghedwa.", "Je vais te voir demain."], ["Ghedwa nsafer l Qsentina.", "Demain je pars à Constantine."], ["Ra7 tchouf, ra7 t3jbek.", "Tu vas voir, ça va te plaire."]],
    quiz: [
      { t: 'qcm', q: "« J'irai » :", o: ["ra7 nrou7", "rou7t", "nrou7t"], a: 0 },
      { t: 'type', q: "Traduis : « Je vais manger »", a: ["ra7 nakoul", "rani rayeh nakoul", "ra7 nakol"] }
    ]
  },
  {
    id: 'g-imperatif', n: 12, dz: "Arwa7! Chouf! Stenna!", t: "L'impératif", lvl: 2,
    blocks: [
      { k: 'p', x: "L'impératif est la base du verbe, avec `-i` pour une femme et `-ou` pour plusieurs personnes." },
      { k: 'table', h: ["Homme", "Femme", "Pluriel", "Sens"], r: [
        ["`chouf`", "`choufi`", "`choufou`", "regarde"], ["`rou7`", "`rou7i`", "`rou7ou`", "va"], ["`arwa7`", "`arwa7i`", "`arwa7ou`", "viens"],
        ["`kol`", "`kli`", "`klou`", "mange"], ["`stenna`", "`stennay`", "`stennaw`", "attends"], ["`9oul`", "`9oli`", "`9oulou`", "dis"]
      ] },
      { k: 'p', x: "À la forme négative, on utilise le présent encadré par `ma … ch` : `ma trou7ch` (ne pars pas), `ma tkhafch` (n'aie pas peur), `ma tensanich` (ne m'oublie pas)." },
      { k: 'tip', x: "Avec un pronom : `a3tini` (donne-moi), `9olli` (dis-moi), `stennani` (attends-moi), `3ayetli` (appelle-moi)." }
    ],
    ex: [["Arwa7i, ya benti!", "Viens, ma fille !"], ["Ma trou7ch, stennani.", "Ne pars pas, attends-moi."], ["Klou, klou, rakoum f darkoum.", "Mangez, mangez, vous êtes chez vous."]],
    quiz: [
      { t: 'qcm', q: "« Regarde ! » (à une femme) :", o: ["choufi", "chouf", "choufou"], a: 0 },
      { t: 'type', q: "« N'aie pas peur » (à un homme)", a: ["ma tkhafch", "matkhafch"] },
      { t: 'qcm', q: "`Stennani` =", o: ["attends-moi", "écoute-moi", "appelle-moi"], a: 0 }
    ]
  },
  {
    id: 'g-interrogatives', n: 13, dz: "T7eb wela la?", t: "Les phrases interrogatives", lvl: 2,
    blocks: [
      { k: 'p', x: "1. Par l'intonation seule : `rak mli7?` (tu vas bien ?). C'est la façon la plus courante." },
      { k: 'p', x: "2. Avec `wach` en tête, comme « est-ce que » : `wach rak jay?` (est-ce que tu viens ?)." },
      { k: 'p', x: "3. Avec `wela la?` (ou pas ?) à la fin pour demander une réponse claire : `t7eb wela la?` (tu veux ou pas ?)." },
      { k: 'p', x: "4. Pour vérifier : `sa7?` ou `s7i7?` (c'est vrai ?), `machi hakda?` (ce n'est pas comme ça ?)." },
      { k: 'p', x: "Question à la forme négative pour proposer poliment : `ma t7ebch 9ahwa?` (tu ne veux pas un café ?)." }
    ],
    ex: [["Wach nta dzayri?", "Est-ce que tu es algérien ?"], ["Tji ghedwa wela la?", "Tu viens demain ou pas ?"], ["Ma t7ebch tay?", "Tu ne veux pas un thé ?"]],
    quiz: [
      { t: 'qcm', q: "`T7eb wela la?` =", o: ["Tu veux ou pas ?", "Tu ne veux pas ?", "Qu'est-ce que tu veux ?"], a: 0 },
      { t: 'order', fr: "Est-ce que tu es algérien ?", a: "Wach nta dzayri" }
    ]
  },
  {
    id: 'g-poli', n: 14, dz: "Allah ykhallik, ya3tik sa7a", t: "Les formulations polies", lvl: 2,
    blocks: [
      { k: 'table', h: ["Fonction", "Formules"], r: [
        ["s'il te plaît", "`allah ykhallik`, `svp`, `brabbi` (Est, à vérifier)"],
        ["merci", "`ya3tik sa7a`, `sa7it`, `barak allahou fik`, `merci`"],
        ["de rien", "`bla mziya`, `3la wajeb`"],
        ["pardon", "`smahli`, `sam7ini`"],
        ["je vous en prie / servez-vous", "`tfaddal`, `tfaddli`, `tfaddlou`"],
        ["merci infiniment", "`allah yr7am waldik`"]
      ] },
      { k: 'p', x: "Pour adoucir une demande, on peut utiliser une question négative (`ma t9derch t3awenni?` = tu ne pourrais pas m'aider ?) ou `ida ma kanch 3lik bezzaf` (si ce n'est pas trop te demander, à vérifier)." },
      { k: 'p', x: "Pour s'adresser poliment : `khalti` (madame), `3ammi` (monsieur), `l7aj` / `l7ajja` (aux personnes âgées respectées), `khouya` / `khti` (aux personnes de son âge)." },
      { k: 'note', x: "Dans certaines familles, on utilise le pluriel de politesse avec les aînés : `wach rakoum?` à une seule personne âgée. Cet usage varie." }
    ],
    ex: [["Smahli khalti, win kayna lbosta?", "Excusez-moi madame, où est la poste ?"], ["Tfaddlou, dkhlou!", "Je vous en prie, entrez !"], ["Ma t9derch t3awenni chwiya?", "Tu ne pourrais pas m'aider un peu ?"]],
    quiz: [
      { t: 'qcm', q: "« De rien » :", o: ["bla mziya", "smahli", "tfaddal"], a: 0 },
      { t: 'qcm', q: "Pour inviter plusieurs personnes à entrer :", o: ["tfaddlou", "tfaddal", "tfaddli"], a: 0 }
    ]
  },
  {
    id: 'g-constructions', n: 15, dz: "Kayen, 3andi, lazem, n9der", t: "Les constructions courantes", lvl: 2,
    blocks: [
      { k: 'table', h: ["Construction", "Sens", "Exemple"], r: [
        ["`kayen` / `makach`", "il y a / il n'y a pas", "`kayen l7lib?` / `makach`"],
        ["`3andi` / `ma 3andich`", "j'ai / je n'ai pas", "`3andi zouj wlad`"],
        ["`lazem` + verbe", "il faut", "`lazem nrou7`"],
        ["`n9der` + verbe", "je peux", "`n9der nji?`"],
        ["`n7eb` + verbe", "je veux", "`n7eb nakoul`"],
        ["`rani` + verbe", "je suis en train de", "`rani nekhdem`"],
        ["`3labali` / `ma3labalich`", "je sais / je ne sais pas", "`3labali bli…`"],
        ["`bach` + verbe", "pour", "`jit bach nchoufek`"],
        ["`9bel ma` + verbe", "avant de", "`9bel ma trou7`"],
        ["`ki` + verbe", "quand", "`ki tousel, 3ayetli`"]
      ] },
      { k: 'p', x: "Deux verbes se suivent sans « de » ni « à » : `n7eb nrou7` (je veux aller), `lazem nakoul` (il faut que je mange). Le second verbe est conjugué à la même personne : `t7eb trou7?` (tu veux aller ?)." }
    ],
    ex: [["Lazem nrou7 dorka, rani m3attel.", "Il faut que j'y aille maintenant, je suis en retard."], ["N9der n3ayet b tilifounek?", "Je peux appeler avec ton téléphone ?"], ["Kayen wa7ed bara, y7eb ychoufek.", "Il y a quelqu'un dehors qui veut te voir."]],
    quiz: [
      { t: 'qcm', q: "« Tu veux aller ? » :", o: ["t7eb trou7?", "t7eb nrou7?", "n7eb trou7?"], a: 0, e: "Le second verbe se conjugue à la même personne." },
      { t: 'type', q: "Traduis : « Il faut que j'y aille »", a: ["lazem nrou7"] },
      { t: 'order', fr: "Je suis venu pour te voir.", a: "Jit bach nchoufek" }
    ]
  }
]);
