# Modifier ou enrichir le contenu de Darija DZ

Tout le contenu pédagogique se trouve dans ce dossier, sous forme de fichiers texte (JavaScript simple).
Vous pouvez les ouvrir avec n'importe quel éditeur de texte (Bloc-notes, TextEdit, VS Code…).

| Fichier | Contenu |
|---|---|
| `dict-1.js` | catégories + mots essentiels, nombres, temps, salutations, famille, amour et amitié |
| `dict-2.js` | maison, objets, nourriture, ville, travail, école, transport, voyage, santé |
| `dict-3.js` | émotions, verbes, adjectifs, expressions, argot, proverbes, vocabulaire avancé |
| `lessons-1.js` à `lessons-4.js` | les 4 étapes de cours (et quelques mots ajoutés au dictionnaire en tête de fichier) |
| `grammar.js` | les 15 fiches de grammaire |
| `dialogues.js` | les dialogues |

## Règle d'écriture

La darija s'écrit **en lettres latines avec chiffres** : `3` = ع, `7` = ح, `9` = ق, `kh` = خ (ou `5`), `gh` = غ, `ch` = ش, `j` = ج, `ou` = son « ou ».
Dans les textes français des leçons, entourez la darija d'accents graves : `` `rani labes` ``.

## Ajouter un mot au dictionnaire

Chaque ligne suit ce modèle :

```js
["darija", "écriture arabe", "traduction française", "exemple en darija", "traduction de l'exemple", { options }],
```

Options possibles (toutes facultatives) :

- `v: "variante1|variante2"` : autres orthographes acceptées dans la recherche et les exercices ;
- `p: "..."` : aide à la prononciation ;
- `n: "..."` : note (genre, pluriel, conjugaison, usage) ;
- `u: 1` : forme ou sens **à vérifier** (affiche un badge d'avertissement) ;
- `r: "Ouest"` : région où le mot est surtout utilisé.

Exemple :

```js
["sa7a", "صحة", "salut ! ; merci ; bravo", "Sa7a khouya!", "Salut mon frère !", { v: "saha|sahha" }],
```

Corriger une entrée douteuse : modifiez-la, puis retirez `u: 1` une fois la forme confirmée par un locuteur natif.

## Après une modification

1. (Facultatif, avec Node.js) vérifiez le contenu : `node outils/verifier-contenu.js`
2. Si l'application est installée (PWA), ouvrez `sw.js` et changez le numéro de version de la ligne
   `var CACHE = 'darija-dz-v1.0.0';` (par exemple `v1.0.1`) pour que l'appareil télécharge la nouvelle version.
3. (Facultatif, avec Node.js) reconstruisez la version en un seul fichier : `node outils/construire-version-autonome.js`

Les identifiants internes des mots sont formés à partir de la catégorie et de la forme darija.
Si vous modifiez l'orthographe principale d'un mot, sa progression de révision repartira de zéro.
