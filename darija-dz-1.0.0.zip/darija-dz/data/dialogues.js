/* Dialogues — chaque réplique : [personnage, darija (latin + chiffres), arabe, français].
   q : questions de compréhension (o = options, a = index de la bonne réponse, e = explication). */

DZ.dialogueCats = {
  amis: "Entre amis", famille: "En famille", marche: "Au marché", cafe: "Au café", taxi: "En taxi",
  restaurant: "Au restaurant", telephone: "Au téléphone", rencontre: "Rencontres", visite: "Visite familiale", quotidien: "Vie quotidienne"
};

DZ.addDialogues([
  {
    id: 'd-amis-1', cat: 'amis', lvl: 1, t: "Retrouvailles au quartier", dz: "Win rak ghaber?",
    ctx: "Yacine croise son ami Amine qu'il n'a pas vu depuis longtemps.",
    lines: [
      ["Yacine", "Salam Amine! Win rak ghaber?", "سلام أمين! وين راك غابر؟", "Salut Amine ! T'étais passé où ?"],
      ["Amine", "Salam khouya! Rani hna, ghir lkhedma.", "سلام خويا! راني هنا، غير الخدمة.", "Salut mon frère ! Je suis là, c'est juste le travail."],
      ["Yacine", "Kirak? Labes?", "كيراك؟ لاباس؟", "Comment tu vas ? Ça va ?"],
      ["Amine", "Labes, l7amdoullah. W nta, wach rak dayer?", "لاباس الحمد لله. وانت، واش راك داير؟", "Ça va, Dieu merci. Et toi, tu deviens quoi ?"],
      ["Yacine", "Kolch labes. Tw7achtek ya kho!", "كلش لاباس. توحشتك يا خو!", "Tout va bien. Tu m'as manqué, mec !"],
      ["Amine", "Ana tani. Yallah nechorbou 9ahwa?", "أنا تاني. يالله نشربو قهوة؟", "Moi aussi. On va boire un café ?"],
      ["Yacine", "Yallah, ana nkhalles!", "يالله، أنا نخلص!", "Allez, c'est moi qui paie !"],
      ["Amine", "La la, lyoum 3liya.", "لا لا، اليوم عليا.", "Non non, aujourd'hui c'est pour moi."]
    ],
    q: [
      { q: "Pourquoi Amine était-il absent ?", o: ["À cause du travail", "Il était malade", "Il était en voyage"], a: 0, e: "« Ghir lkhedma » = juste le travail." },
      { q: "Que signifie « tw7achtek » ?", o: ["Tu m'as manqué", "Tu m'énerves", "Je te remercie"], a: 0 },
      { q: "Que veut dire Amine avec « lyoum 3liya » ?", o: ["C'est moi qui paie aujourd'hui", "Je suis fatigué aujourd'hui", "Aujourd'hui je travaille"], a: 0 }
    ]
  },
  {
    id: 'd-amis-2', cat: 'amis', lvl: 2, t: "Organiser une sortie", dz: "Nrou7ou l b7ar?",
    ctx: "Sara et Lina préparent une journée à la plage.",
    lines: [
      ["Sara", "Wach ndirou nhar ljem3a?", "واش نديرو نهار الجمعة؟", "Qu'est-ce qu'on fait vendredi ?"],
      ["Lina", "N7eb nrou7ou l b7ar, rahi skhana.", "نحب نروحو للبحر، راهي سخانة.", "J'aimerais qu'on aille à la mer, il fait chaud."],
      ["Sara", "Fikra mli7a. Ch7al rana?", "فكرة مليحة. شحال رانا؟", "Bonne idée. On est combien ?"],
      ["Lina", "Ana, nti w Meriem. Balak tji tani Nesrine.", "أنا، نتي ومريم. بالاك تجي تاني نسرين.", "Moi, toi et Meriem. Nesrine viendra peut-être aussi."],
      ["Sara", "Wa9tach nkhorjou?", "وقتاش نخرجو؟", "On part quand ?"],
      ["Lina", "F tes3a sba7, bach nalgaw plaça.", "في تسعة صباح، باش نلقاو بلاصة.", "À neuf heures du matin, pour trouver une place."],
      ["Sara", "Mli7, ana njib lmakla.", "مليح، أنا نجيب الماكلة.", "Bien, moi j'apporte à manger."],
      ["Lina", "W ana njib l9ar3at ta3 lma.", "وأنا نجيب القرعات تاع الما.", "Et moi j'apporte les bouteilles d'eau."]
    ],
    q: [
      { q: "Où veulent-elles aller ?", o: ["À la mer", "Au marché", "Chez Meriem"], a: 0 },
      { q: "À quelle heure partent-elles ?", o: ["9 h du matin", "7 h du matin", "9 h du soir"], a: 0 },
      { q: "Qu'apporte Sara ?", o: ["À manger", "L'eau", "Rien"], a: 0 }
    ]
  },
  {
    id: 'd-amis-3', cat: 'amis', lvl: 4, t: "Coup de déprime", dz: "Rani dégoûté",
    ctx: "Échange rapide et familier entre deux jeunes du même quartier.",
    lines: [
      ["Amine", "Wach ya kho, win rak?", "واش يا خو، وين راك؟", "Quoi de neuf mec, t'es où ?"],
      ["Yanis", "F l7ouma, rani dégoûté.", "في الحومة، راني ديڨوطي.", "Au quartier, j'en ai marre."],
      ["Amine", "Wach bik?", "واش بيك؟", "Qu'est-ce que t'as ?"],
      ["Yanis", "Walou, makach khedma, makach drahem… 7itist ga3!", "والو، ماكاش خدمة، ماكاش دراهم… حيطيست قاع!", "Rien, pas de boulot, pas d'argent… hittiste total !"],
      ["Amine", "Ma tkhammemch bezzaf. Kayen wa7ed sa7bi y7taj wa7ed f l7anout ta3ou.", "ما تخممش بزاف. كاين واحد صاحبي يحتاج واحد في الحانوت تاعو.", "Ne t'en fais pas trop. J'ai un pote qui a besoin de quelqu'un dans sa boutique."],
      ["Yanis", "Bsa7?! Wallah?", "بصح؟! والله؟", "C'est vrai ?! Je te jure ?"],
      ["Amine", "Wallah. Arwa7 ghedwa f l3achra, n3arfek bih.", "والله. أرواح غدوة في العشرة، نعرفك بيه.", "Je te jure. Viens demain à dix heures, je te le présente."],
      ["Yanis", "Ya kho, nta ghaya! Tbarkallah 3lik.", "يا خو، نتا غاية! تبارك الله عليك.", "Mec, t'es génial ! Que Dieu te protège."],
      ["Amine", "Normal, khawa.", "نورمال، خاوة.", "Normal, on est frères."]
    ],
    q: [
      { q: "Pourquoi Yanis en a-t-il marre ?", o: ["Pas de travail ni d'argent", "Il est malade", "Il a raté le bus"], a: 0 },
      { q: "Que propose Amine ?", o: ["Un travail dans une boutique", "De lui prêter de l'argent", "De partir à l'étranger"], a: 0 },
      { q: "« Khawa » veut dire ici :", o: ["on est comme des frères", "les vacances", "le café"], a: 0 }
    ]
  },
  {
    id: 'd-amis-4', cat: 'amis', lvl: 4, t: "Rester ou partir ?", dz: "F ra2yi…",
    ctx: "Riad hésite à partir étudier à l'étranger et en parle avec Lamia.",
    lines: [
      ["Riad", "Nkhammem nrou7 n9ra f Canada. Wach t9oul?", "نخمم نروح نقرا في كندا. واش تقول؟", "Je pense aller étudier au Canada. Qu'en dis-tu ?"],
      ["Lamia", "F ra2yi fikra mli7a, bsa7 lghorba machi sahla.", "في رأيي فكرة مليحة، بصح الغربة ماشي ساهلة.", "À mon avis c'est une bonne idée, mais vivre loin du pays n'est pas facile."],
      ["Riad", "3labali, bsa7 hna lforsa 9lila.", "على بالي، بصح هنا الفرصة قليلة.", "Je sais, mais ici les opportunités sont rares."],
      ["Lamia", "Machi sa7 ga3. Kayen li nej7ou hna. Ghir lazem sber.", "ماشي صح قاع. كاين اللي نجحو هنا. غير لازم صبر.", "Ce n'est pas tout à fait vrai. Il y en a qui ont réussi ici. Il faut juste de la patience."],
      ["Riad", "Sber mefta7 lfaraj, 3labali… bsa7 ana n7eb nchouf l3alem.", "الصبر مفتاح الفرج، على بالي… بصح أنا نحب نشوف العالم.", "La patience est la clé du soulagement, je sais… mais moi je veux voir le monde."],
      ["Lamia", "Ma3naha rak deja 9arrart!", "معناها راك ديجا قررت!", "Ça veut dire que tu as déjà décidé !"],
      ["Riad", "Balak… Lmouhim, nkemmel lmaster hna w mba3d nchoufou.", "بالاك… المهم، نكمل الماستر هنا ومبعد نشوفو.", "Peut-être… Bref, je finis mon master ici et après on verra."],
      ["Lamia", "Hadi hiya l7kma!", "هادي هي الحكمة!", "Ça, c'est la sagesse !"]
    ],
    q: [
      { q: "Où Riad veut-il aller ?", o: ["Au Canada", "En France", "À Oran"], a: 0 },
      { q: "Quel est l'avis de Lamia ?", o: ["Bonne idée, mais la vie à l'étranger est difficile", "Mauvaise idée", "Elle s'en moque"], a: 0 },
      { q: "Que décide finalement Riad ?", o: ["Finir son master puis voir", "Partir demain", "Ne jamais partir"], a: 0 }
    ]
  },
  {
    id: 'd-famille-1', cat: 'famille', lvl: 1, t: "Le réveil", dz: "Noud, rahi tmenya!",
    ctx: "Un matin d'école, une mère réveille son fils Rayan.",
    lines: [
      ["Yemma", "Sba7 el khir wlidi, noud! Rahi tmenya.", "صباح الخير وليدي، نوض! راهي ثمنية.", "Bonjour mon fils, lève-toi ! Il est huit heures."],
      ["Rayan", "Sba7 ennour yemma… mazal chwiya.", "صباح النور يما… مازال شوية.", "Bonjour maman… encore un peu."],
      ["Yemma", "La, noud! Lakoul f tes3a.", "لا، نوض! لاكول في تسعة.", "Non, lève-toi ! L'école est à neuf heures."],
      ["Rayan", "Ih, ih, rani nnoud.", "إيه، إيه، راني ننوض.", "Oui, oui, je me lève."],
      ["Yemma", "Wach t7eb? 7lib wela tay?", "واش تحب؟ حليب ولا تاي؟", "Qu'est-ce que tu veux ? Du lait ou du thé ?"],
      ["Rayan", "7lib b chocolat, w khobz b 3ssel.", "حليب بالشوكولا، وخبز بالعسل.", "Du lait au chocolat, et du pain au miel."],
      ["Yemma", "Kol mli7, w ma tensach kerrasek.", "كول مليح، وما تنساش كراسك.", "Mange bien, et n'oublie pas ton cahier."],
      ["Rayan", "Ih yemma. Bslama!", "إيه يما. بالسلامة!", "Oui maman. Au revoir !"]
    ],
    q: [
      { q: "À quelle heure commence l'école ?", o: ["9 h", "8 h", "10 h"], a: 0 },
      { q: "Que boit Rayan ?", o: ["Du lait au chocolat", "Du thé", "Du café"], a: 0 },
      { q: "Qu'est-ce que Rayan ne doit pas oublier ?", o: ["Son cahier", "Son téléphone", "Ses clés"], a: 0 }
    ]
  },
  {
    id: 'd-famille-2', cat: 'famille', lvl: 2, t: "Qui fait la vaisselle ?", dz: "Chkoun yghsel lmwa3en?",
    ctx: "Nadia et son frère Walid se disputent gentiment à la cuisine.",
    lines: [
      ["Nadia", "Chkoun ra7 yghsel lmwa3en lyoum?", "شكون راح يغسل الماعون اليوم؟", "Qui va faire la vaisselle aujourd'hui ?"],
      ["Walid", "Machi ana, ghselt lbare7.", "ماشي أنا، غسلت البارح.", "Pas moi, je l'ai faite hier."],
      ["Nadia", "Rak tkadeb! Lbare7 ana li ghselt.", "راك تكذب! البارح أنا اللي غسلت.", "Menteur ! Hier, c'est moi qui l'ai faite."],
      ["Walid", "Ok, ok… ndirha ana, bsa7 ghedwa nti.", "أوكي، أوكي… نديرها أنا، بصح غدوة نتي.", "D'accord, d'accord… je la fais, mais demain c'est toi."],
      ["Nadia", "D'accord. W rod balek, ma tkassarch tbassi!", "دكور. ورد بالك، ما تكسرش الطباسي!", "D'accord. Et fais attention, ne casse pas les assiettes !"],
      ["Yemma", "Wach bikoum? 3lach rakoum t3aytou?", "واش بيكم؟ علاش راكم تعيطو؟", "Qu'est-ce que vous avez ? Pourquoi vous criez ?"],
      ["Walid", "Walou yemma, kolch labes!", "والو يما، كلش لاباس!", "Rien maman, tout va bien !"]
    ],
    q: [
      { q: "Qui fait la vaisselle aujourd'hui ?", o: ["Walid", "Nadia", "La mère"], a: 0 },
      { q: "Que reproche Nadia à Walid ?", o: ["De mentir", "D'être en retard", "D'être fatigué"], a: 0 },
      { q: "Ici, « t3aytou » veut dire :", o: ["vous criez", "vous appelez au téléphone", "vous chantez"], a: 0, e: "`3ayet` = crier ou appeler ; ici, la mère entend des cris." }
    ]
  },
  {
    id: 'd-marche-1', cat: 'marche', lvl: 1, t: "Acheter des tomates", dz: "Ch7al lkilo?",
    ctx: "Au marché, un client achète des légumes et négocie le prix.",
    lines: [
      ["Client", "Salam 3likoum.", "السلام عليكم.", "Bonjour."],
      ["Vendeur", "3likoum salam, tfaddal khouya.", "عليكم السلام، تفضل خويا.", "Bonjour, je t'écoute, mon frère."],
      ["Client", "Ch7al lkilo ta3 tmatem?", "شحال الكيلو تاع الطماطم؟", "Combien le kilo de tomates ?"],
      ["Vendeur", "Mya w 3achrin dinar.", "مية وعشرين دينار.", "Cent vingt dinars."],
      ["Client", "Ghali chwiya… n9es chwiya.", "غالي شوية… نقص شوية.", "C'est un peu cher… baisse un peu."],
      ["Vendeur", "Yallah, mya bark.", "يالله، مية برك.", "Allez, cent seulement."],
      ["Client", "Mli7. A3tini zouj kilo, w nos kilo bsel.", "مليح. أعطيني زوج كيلو، ونص كيلو بصل.", "Bien. Donne-moi deux kilos, et un demi-kilo d'oignons."],
      ["Vendeur", "Hak. Mitin w tlatin dinar.", "هاك. ميتين وثلاثين دينار.", "Voilà. Deux cent trente dinars."],
      ["Client", "Hak khamsmya, ma 3andich sarf.", "هاك خمسمية، ما عنديش صرف.", "Tiens, cinq cents, je n'ai pas de monnaie."],
      ["Vendeur", "Normal. Hak mitin w sab3in.", "نورمال. هاك ميتين وسبعين.", "Pas de souci. Voici deux cent soixante-dix."]
    ],
    q: [
      { q: "Quel était le premier prix du kilo de tomates ?", o: ["120 DA", "100 DA", "230 DA"], a: 0 },
      { q: "Combien le client paie-t-il en tout ?", o: ["230 DA", "500 DA", "270 DA"], a: 0, e: "Il donne 500 et reçoit 270 de monnaie : il paie 230." },
      { q: "« N9es chwiya » veut dire :", o: ["baisse un peu le prix", "ajoute un peu", "attends un peu"], a: 0 }
    ]
  },
  {
    id: 'd-marche-2', cat: 'marche', lvl: 2, t: "Chez l'épicier", dz: "Lkhobz kmel",
    ctx: "Un client passe à l'épicerie du quartier.",
    lines: [
      ["Client", "Salam, 3andek lben?", "سلام، عندك لبن؟", "Bonjour, tu as du lben ?"],
      ["Épicier", "Ih, kayen. Ch7al t7eb?", "إيه، كاين. شحال تحب؟", "Oui, il y en a. Tu en veux combien ?"],
      ["Client", "Zouj. W khobza tani.", "زوج. وخبزة تاني.", "Deux. Et une baguette aussi."],
      ["Épicier", "Lkhobz kmel, smahli. Ra7 ykoun f l3achiya.", "الخبز كمل، سمحلي. راح يكون في العشية.", "Il n'y a plus de pain, désolé. Il y en aura l'après-midi."],
      ["Client", "Ma3lich. W 9ar3a ta3 lma, barda ida kayna.", "ماعليش. وقرعة تاع الما، باردة إذا كاينة.", "Pas grave. Et une bouteille d'eau, fraîche s'il y en a."],
      ["Épicier", "Hak.", "هاك.", "Tiens."],
      ["Client", "Ch7al nkhalsek?", "شحال نخلصك؟", "Combien je te dois ?"],
      ["Épicier", "Mitin w khamsin.", "ميتين وخمسين.", "Deux cent cinquante."],
      ["Client", "Hak. Ya3tik sa7a.", "هاك. يعطيك الصحة.", "Tiens. Merci."],
      ["Épicier", "Bslama khouya.", "بالسلامة خويا.", "Au revoir, mon frère."]
    ],
    q: [
      { q: "Pourquoi le client ne peut-il pas acheter de pain ?", o: ["Il n'y en a plus", "C'est trop cher", "L'épicerie ferme"], a: 0 },
      { q: "Combien paie le client ?", o: ["250 DA", "200 DA", "2 500 DA"], a: 0 },
      { q: "« Ch7al nkhalsek ? » veut dire :", o: ["Combien je te dois ?", "Tu me rends la monnaie ?", "Combien tu gagnes ?"], a: 0 }
    ]
  },
  {
    id: 'd-cafe-1', cat: 'cafe', lvl: 1, t: "Au café du coin", dz: "Wa7ed noss-noss",
    ctx: "Mehdi et Sofiane commandent au comptoir.",
    lines: [
      ["Serveur", "Wach t7ebbou?", "واش تحبو؟", "Qu'est-ce que vous voulez ?"],
      ["Mehdi", "Ana wa7ed noss-noss.", "أنا واحد نص نص.", "Pour moi, un noisette."],
      ["Sofiane", "W ana café noir, bla sokkar.", "وأنا كافي نوار، بلا سكر.", "Et moi un café noir, sans sucre."],
      ["Serveur", "Ghir hada?", "غير هادا؟", "C'est tout ?"],
      ["Mehdi", "Zid zouj croissants, sa7it.", "زيد زوج كرواسون، صحيت.", "Ajoute deux croissants, merci."],
      ["Sofiane", "Khouya, ch7al nkhalsouk?", "خويا، شحال نخلصوك؟", "Combien on te doit ?"],
      ["Serveur", "Mitin w 3achrin dinar.", "ميتين وعشرين دينار.", "Deux cent vingt dinars."],
      ["Mehdi", "Khalli, ana nkhalles.", "خلي، أنا نخلص.", "Laisse, c'est moi qui paie."],
      ["Sofiane", "La wallah, ma tkhallasch!", "لا والله، ما تخلصش!", "Non, je te jure, tu ne paies pas !"],
      ["Mehdi", "Ya kho, khalli… dorka ana, w khetra jaya nta.", "يا خو، خلي… دركا أنا، وخطرة جاية نتا.", "Laisse… cette fois c'est moi, et la prochaine fois c'est toi."]
    ],
    q: [
      { q: "Que commande Mehdi ?", o: ["Un noss-noss (noisette)", "Un café noir", "Un thé"], a: 0 },
      { q: "Combien de croissants commandent-ils ?", o: ["Deux", "Un", "Aucun"], a: 0 },
      { q: "Qui paie finalement ?", o: ["Mehdi", "Sofiane", "Personne, c'est offert"], a: 0, e: "Se disputer pour payer est un rituel de politesse très courant." }
    ]
  },
  {
    id: 'd-cafe-2', cat: 'cafe', lvl: 2, t: "Le match d'hier", dz: "Cheft lmatch?",
    ctx: "Rafik et Hichem commentent le match de l'équipe nationale.",
    lines: [
      ["Rafik", "Cheft lmatch lbare7?", "شفت الماتش البارح؟", "Tu as vu le match hier ?"],
      ["Hichem", "Ih! Lkhadra l3bet mli7 bezzaf.", "إيه! الخضرا لعبت مليح بزاف.", "Oui ! Les Verts ont très bien joué."],
      ["Rafik", "Wallah, lbut lekhar kan ghaya.", "والله، البيت الاخر كان غاية.", "Je te jure, le dernier but était génial."],
      ["Hichem", "Bsa7 l'arbitre… ma 3jebnich.", "بصح لاربيتر… ما عجبنيش.", "Mais l'arbitre… il ne m'a pas plu."],
      ["Rafik", "Normal, dima kima hakda. Lmouhim rbe7na!", "نورمال، ديما كيما هكذا. المهم ربحنا!", "Normal, c'est toujours comme ça. L'essentiel, c'est qu'on a gagné !"],
      ["Hichem", "Lmatch jay wa9tach?", "الماتش الجاي وقتاش؟", "Le prochain match, c'est quand ?"],
      ["Rafik", "Nhar sebt, f setta ta3 l3achiya. Nchoufouh hna?", "نهار السبت، في ستة تاع العشية. نشوفوه هنا؟", "Samedi, à six heures du soir. On le regarde ici ?"],
      ["Hichem", "Akid! Ana nkhalli tabla.", "أكيد! أنا نخلي طابلة.", "Bien sûr ! Je nous garde une table."]
    ],
    q: [
      { q: "Qui a gagné le match ?", o: ["L'équipe nationale (Lkhadra)", "L'équipe adverse", "Personne"], a: 0 },
      { q: "Quand est le prochain match ?", o: ["Samedi à 18 h", "Vendredi à 6 h", "Dimanche"], a: 0 },
      { q: "« Lkhadra » désigne :", o: ["l'équipe nationale", "les légumes", "le terrain"], a: 0 }
    ]
  },
  {
    id: 'd-taxi-1', cat: 'taxi', lvl: 1, t: "Direction la gare", dz: "Ddini l lagar",
    ctx: "Un voyageur pressé prend un taxi à Alger.",
    lines: [
      ["Client", "Salam, tddini l lagar?", "سلام، تديني للاڨار؟", "Bonjour, tu m'emmènes à la gare ?"],
      ["Chauffeur", "Wina lagar? Agha wela Kharrouba?", "وينا الاڨار؟ آڨا ولا خروبة؟", "Quelle gare ? Agha ou Kharrouba ?"],
      ["Client", "Lagar ta3 tren, Agha.", "الاڨار تاع التران، آڨا.", "La gare de train, Agha."],
      ["Chauffeur", "Rkeb.", "ركب.", "Monte."],
      ["Client", "Ch7al?", "شحال؟", "C'est combien ?"],
      ["Chauffeur", "Khamsmya.", "خمسمية.", "Cinq cents."],
      ["Client", "Mli7. Rani m3attel chwiya, n9edrou nrou7ou fissa?", "مليح. راني معطل شوية، نقدرو نروحو فيسع؟", "Bien. Je suis un peu en retard, on peut aller vite ?"],
      ["Chauffeur", "Kayen za7ma, bsa7 ndour men tri9 okhra.", "كاين زحمة، بصح ندور من طريق أخرى.", "Il y a des bouchons, mais je passe par une autre route."],
      ["Client", "7bes hna, sa7it. Hak.", "حبس هنا، صحيت. هاك.", "Arrête-toi ici, merci. Tiens."],
      ["Chauffeur", "Tri9 salama!", "طريق السلامة!", "Bon voyage !"]
    ],
    q: [
      { q: "Où va le client ?", o: ["À la gare de train de l'Agha", "À l'aéroport", "À la gare routière"], a: 0 },
      { q: "Quel est le prix ?", o: ["500 DA", "50 DA", "5 000 DA"], a: 0 },
      { q: "Pourquoi veut-il aller vite ?", o: ["Il est en retard", "Il est malade", "Il n'aime pas le taxi"], a: 0 }
    ]
  },
  {
    id: 'd-taxi-2', cat: 'taxi', lvl: 3, t: "Le clando", dz: "Bezzaf 3lik!",
    ctx: "Un étudiant négocie avec un chauffeur de taxi non officiel, puis ils discutent.",
    lines: [
      ["Client", "Salam, rak rayeh l Bab Ezzouar?", "سلام، راك رايح لباب الزوار؟", "Bonjour, tu vas vers Bab Ezzouar ?"],
      ["Chauffeur", "Ih, rkeb. Ch7al rakoum?", "إيه، ركب. شحال راكم؟", "Oui, monte. Vous êtes combien ?"],
      ["Client", "Ghir ana. Ch7al?", "غير أنا. شحال؟", "Juste moi. C'est combien ?"],
      ["Chauffeur", "Alf dinar.", "ألف دينار.", "Mille dinars."],
      ["Client", "Alf?! Bezzaf 3lik ya kho, nkhalles sab3mya.", "ألف؟! بزاف عليك يا خو، نخلص سبعمية.", "Mille ?! Tu exagères, mec, je paie sept cents."],
      ["Chauffeur", "Tmenmya, w ma nzidch nahder.", "ثمنمية، وما نزيدش نهدر.", "Huit cents, et je n'en discute plus."],
      ["Client", "Yallah, sa7a.", "يالله، صحة.", "Allez, d'accord."],
      ["Chauffeur", "Wach tekhdem f Bab Ezzouar?", "واش تخدم في باب الزوار؟", "Tu travailles à Bab Ezzouar ?"],
      ["Client", "La, n9ra f la fac. W nta, ghir clando?", "لا، نقرا في لافاك. وانت، غير كلوندو؟", "Non, j'étudie à la fac. Et toi, tu fais seulement le clando ?"],
      ["Chauffeur", "La, nekhdem f sbitar fe sba7, w f l3achiya ndir clando. Lchahriya ma tekfich.", "لا، نخدم في سبيطار في الصباح، وفي العشية ندير كلوندو. الشهرية ما تكفيش.", "Non, je travaille à l'hôpital le matin, et l'après-midi je fais le clando. Le salaire ne suffit pas."],
      ["Client", "Allah y3awnek.", "الله يعاونك.", "Bon courage."]
    ],
    q: [
      { q: "Quel est le prix final ?", o: ["800 DA", "1 000 DA", "700 DA"], a: 0 },
      { q: "Que fait le chauffeur le matin ?", o: ["Il travaille à l'hôpital", "Il étudie", "Il dort"], a: 0 },
      { q: "Pourquoi fait-il aussi le clando ?", o: ["Son salaire ne suffit pas", "Il aime conduire", "Il est au chômage"], a: 0 }
    ]
  },
  {
    id: 'd-resto-1', cat: 'restaurant', lvl: 2, t: "Commander un repas", dz: "Wach kayen lyoum?",
    ctx: "Leila et Samir déjeunent au restaurant.",
    lines: [
      ["Serveur", "Mar7ba bikoum. Ch7al rakoum?", "مرحبا بيكم. شحال راكم؟", "Bienvenue. Vous êtes combien ?"],
      ["Leila", "Zouj. Kayen tabla 7da ta9a?", "زوج. كاين طابلة حدا الطاقة؟", "Deux. Il y a une table près de la fenêtre ?"],
      ["Serveur", "Ih, tfaddlou. Hak lmenu.", "إيه، تفضلو. هاك المنيو.", "Oui, je vous en prie. Voici le menu."],
      ["Leila", "Wach kayen lyoum?", "واش كاين اليوم؟", "Qu'est-ce qu'il y a aujourd'hui ?"],
      ["Serveur", "Kayen chorba, rechta, w 7out mchwi.", "كاين شوربة، رشتة، وحوت مشوي.", "Il y a de la chorba, de la rechta et du poisson grillé."],
      ["Leila", "Ana neddi rechta. W nta, Samir?", "أنا نديّ رشتة. وانت، سمير؟", "Moi je prends la rechta. Et toi, Samir ?"],
      ["Samir", "7out mchwi b salade. W zouj 9ar3at ta3 lma.", "حوت مشوي بالسلاطة. وزوج قرعات تاع الما.", "Poisson grillé avec salade. Et deux bouteilles d'eau."],
      ["Samir", "Lmakla kanet bnina bezzaf.", "الماكلة كانت بنينة بزاف.", "Le repas était délicieux."],
      ["Serveur", "Sa7a! T7ebbou 9ahwa?", "صحة! تحبو قهوة؟", "Merci ! Vous voulez un café ?"],
      ["Leila", "La, sa7it. A3tina l'addition, allah ykhallik.", "لا، صحيت. أعطينا لاديسيون، الله يخليك.", "Non, merci. L'addition, s'il vous plaît."]
    ],
    q: [
      { q: "Que commande Leila ?", o: ["De la rechta", "De la chorba", "Du poisson"], a: 0 },
      { q: "Que boivent-ils ?", o: ["De l'eau", "Du café", "Du thé"], a: 0 },
      { q: "« Bnina » veut dire :", o: ["délicieuse", "chère", "froide"], a: 0 }
    ]
  },
  {
    id: 'd-resto-2', cat: 'restaurant', lvl: 3, t: "Erreur de commande", dz: "Hada machi wach tlebt",
    ctx: "Un client pressé reçoit le mauvais sandwich.",
    lines: [
      ["Client", "Smahli khouya, hada machi wach tlebt.", "سمحلي خويا، هادا ماشي واش طلبت.", "Excuse-moi, ce n'est pas ce que j'ai commandé."],
      ["Serveur", "Ah bon? Wach tlebt?", "آه بون؟ واش طلبت؟", "Ah bon ? Qu'est-ce que tu avais commandé ?"],
      ["Client", "Tlebt kaskrout b djaj, bla felfel. W hada fih tun w felfel 7ar.", "طلبت كاسكروط بالدجاج، بلا فلفل. وهادا فيه تون وفلفل حار.", "J'avais commandé un sandwich au poulet, sans piment. Et celui-ci est au thon avec du piment fort."],
      ["Serveur", "Smahli bezzaf, ghalta ta3 lkouzina. Nbeddlek dorka.", "سمحلي بزاف، غلطة تاع الكوزينة. نبدلك دركا.", "Toutes mes excuses, c'est une erreur de la cuisine. Je te le change tout de suite."],
      ["Client", "Ma3lich, bsa7 rani msta3jel chwiya.", "ماعليش، بصح راني مستعجل شوية.", "Ce n'est pas grave, mais je suis un peu pressé."],
      ["Serveur", "Khamsa d9aye9 w ykoun wajed. W lcoca 3liya.", "خمسة دقايق ويكون واجد. والكوكا عليا.", "Cinq minutes et ce sera prêt. Et le soda, c'est offert."],
      ["Client", "Ya3tik sa7a khouya.", "يعطيك الصحة خويا.", "Merci, mon frère."]
    ],
    q: [
      { q: "Qu'avait commandé le client ?", o: ["Un sandwich au poulet sans piment", "Un sandwich au thon", "Une chorba"], a: 0 },
      { q: "Pourquoi le soda est-il offert ?", o: ["Pour s'excuser de l'erreur", "C'est une promotion", "Le client a gagné un jeu"], a: 0 },
      { q: "« Msta3jel » veut dire :", o: ["pressé", "fâché", "affamé"], a: 0 }
    ]
  },
  {
    id: 'd-tel-1', cat: 'telephone', lvl: 2, t: "Un ami malade", dz: "Allah ychafik",
    ctx: "Karim appelle Sofiane, qui est malade.",
    lines: [
      ["Karim", "Allo, Sofiane? Wach rak, sma3t bli rak mrid?", "ألو، سفيان؟ واش راك، سمعت بلي راك مريض؟", "Allô, Sofiane ? Comment tu vas, j'ai entendu dire que tu étais malade ?"],
      ["Sofiane", "Ih, 3andi skhana men lbare7. Rani f lfrach.", "إيه، عندي سخانة من البارح. راني في الفراش.", "Oui, j'ai de la fièvre depuis hier. Je suis au lit."],
      ["Karim", "Allah ychafik. Rou7t l tbib?", "الله يشافيك. رحت للطبيب؟", "Bon rétablissement. Tu es allé chez le médecin ?"],
      ["Sofiane", "Ih, 3tani dwa, w 9alli rta7 youmin.", "إيه، عطاني دوا، وقالي رتاح يومين.", "Oui, il m'a donné un médicament et m'a dit de me reposer deux jours."],
      ["Karim", "T7taj 7aja? Njiblek 7aja men pharmacie?", "تحتاج حاجة؟ نجيبلك حاجة من الفرماسي؟", "Tu as besoin de quelque chose ? Je te rapporte quelque chose de la pharmacie ?"],
      ["Sofiane", "La, sa7it, yemma jabetli kolch.", "لا، صحيت، يما جابتلي كلش.", "Non, merci, ma mère m'a tout apporté."],
      ["Karim", "Mli7. Nfout 3lik ghedwa inchallah.", "مليح. نفوت عليك غدوة إن شاء الله.", "Bien. Je passe te voir demain, si Dieu le veut."],
      ["Sofiane", "Mar7ba bik. Ya3tik sa7a 3la l'appel.", "مرحبا بيك. يعطيك الصحة على لابيل.", "Tu es le bienvenu. Merci pour l'appel."]
    ],
    q: [
      { q: "Depuis quand Sofiane est-il malade ?", o: ["Depuis hier", "Depuis une semaine", "Depuis ce matin"], a: 0 },
      { q: "Que lui a dit le médecin ?", o: ["De se reposer deux jours", "D'aller à l'hôpital", "De manger davantage"], a: 0 },
      { q: "Que va faire Karim demain ?", o: ["Passer le voir", "L'appeler", "Aller à la pharmacie"], a: 0 }
    ]
  },
  {
    id: 'd-tel-2', cat: 'telephone', lvl: 2, t: "Fixer un rendez-vous", dz: "Raki libre ghedwa?",
    ctx: "Amel appelle son amie Nesrine pour aller acheter des chaussures.",
    lines: [
      ["Amel", "Allo Nesrine, raki mchaghla ghedwa?", "ألو نسرين، راكي مشغلة غدوة؟", "Allô Nesrine, tu es occupée demain ?"],
      ["Nesrine", "Fe sba7 ih, 3andi lkhedma. L3achiya rani libre.", "في الصباح إيه، عندي الخدمة. العشية راني ليبر.", "Le matin oui, j'ai le travail. L'après-midi je suis libre."],
      ["Amel", "Nrou7ou l souk? Lazemli sebbat l l3ers.", "نروحو للسوق؟ لازملي صباط للعرس.", "On va au marché ? Il me faut des chaussures pour le mariage."],
      ["Nesrine", "Mli7. Wa9tach?", "مليح. وقتاش؟", "Bien. Quand ?"],
      ["Amel", "F zouj w nos?", "في زوج ونص؟", "À deux heures et demie ?"],
      ["Nesrine", "Khalliha f tlata, n7taj nwelli men lkhedma 9bel.", "خليها في تلاتة، نحتاج نولي من الخدمة قبل.", "Disons trois heures, il faut d'abord que je rentre du travail."],
      ["Amel", "Sa7a, tlata. Nstennak 9dam lbosta.", "صحة، تلاتة. نستناك قدام البوسطة.", "D'accord, trois heures. Je t'attends devant la poste."],
      ["Nesrine", "Ok, nchoufek ghedwa. Bslama!", "أوكي، نشوفك غدوة. بالسلامة!", "Ok, à demain. Au revoir !"]
    ],
    q: [
      { q: "Pourquoi Amel veut-elle aller au marché ?", o: ["Acheter des chaussures pour un mariage", "Acheter des légumes", "Voir une amie"], a: 0 },
      { q: "À quelle heure est le rendez-vous ?", o: ["15 h", "14 h 30", "Le matin"], a: 0 },
      { q: "Où se retrouvent-elles ?", o: ["Devant la poste", "Devant la mosquée", "À la gare"], a: 0 }
    ]
  },
  {
    id: 'd-rencontre-1', cat: 'rencontre', lvl: 1, t: "Faire connaissance", dz: "Nta jdid hna?",
    ctx: "Karim rencontre Thomas, un Français installé depuis peu.",
    lines: [
      ["Karim", "Salam, ana Karim. Nta jdid hna?", "سلام، أنا كريم. نتا جديد هنا؟", "Salut, moi c'est Karim. Tu es nouveau ici ?"],
      ["Thomas", "Salam! Ih, ana Thomas, men Fransa.", "سلام! إيه، أنا توما، من فرانسا.", "Salut ! Oui, moi c'est Thomas, je viens de France."],
      ["Karim", "Mar7ba bik! Ta3ref tahder darija?", "مرحبا بيك! تعرف تهدر دارجة؟", "Bienvenue ! Tu sais parler darija ?"],
      ["Thomas", "Chwiya bark. Rani net3allem.", "شوية برك. راني نتعلم.", "Juste un peu. J'apprends."],
      ["Karim", "Ghaya! Wach tekhdem hna?", "غاية! واش تخدم هنا؟", "Génial ! Qu'est-ce que tu fais ici, comme travail ?"],
      ["Thomas", "Nekhdem f charika ta3 l'informatique.", "نخدم في شركة تاع لانفورماتيك.", "Je travaille dans une entreprise d'informatique."],
      ["Karim", "Mtcharfin. Ida t7taj 7aja, 9olli.", "متشرفين. إذا تحتاج حاجة، قولي.", "Enchanté. Si tu as besoin de quelque chose, dis-le-moi."],
      ["Thomas", "Ya3tik sa7a, nta mli7 bezzaf.", "يعطيك الصحة، نتا مليح بزاف.", "Merci, tu es très gentil."]
    ],
    q: [
      { q: "D'où vient Thomas ?", o: ["De France", "D'Oran", "De Tunisie"], a: 0 },
      { q: "Quel est son niveau de darija ?", o: ["Un peu", "Il parle couramment", "Pas du tout"], a: 0 },
      { q: "Que propose Karim ?", o: ["De l'aider s'il a besoin", "De le loger", "De lui apprendre le français"], a: 0 }
    ]
  },
  {
    id: 'd-rencontre-2', cat: 'rencontre', lvl: 2, t: "La nouvelle voisine", dz: "Nti jarti ljdida?",
    ctx: "Madame Fatiha accueille Yasmine, qui vient d'emménager.",
    lines: [
      ["Fatiha", "Salam 3likoum, nti jarti ljdida?", "السلام عليكم، نتي جارتي الجديدة؟", "Bonjour, c'est toi ma nouvelle voisine ?"],
      ["Yasmine", "3likoum salam khalti. Ih, ana Yasmine, sknt hna men simana.", "عليكم السلام خالتي. إيه، أنا ياسمين، سكنت هنا من سيمانة.", "Bonjour madame. Oui, je suis Yasmine, j'habite ici depuis une semaine."],
      ["Fatiha", "Mar7ba biki benti. Mnin nti?", "مرحبا بيك بنتي. منين نتي؟", "Bienvenue, ma fille. D'où es-tu ?"],
      ["Yasmine", "Ana men Tlemcen, jit l Dzayer 3la jal lkhedma.", "أنا من تلمسان، جيت لدزاير على جال الخدمة.", "Je suis de Tlemcen, je suis venue à Alger pour le travail."],
      ["Fatiha", "Allah y3awnek. Ida t7taji 7aja, dkhli 3andi, ma t7chmich.", "الله يعاونك. إذا تحتاجي حاجة، دخلي عندي، ما تحشميش.", "Bon courage. Si tu as besoin de quoi que ce soit, viens chez moi, ne sois pas gênée."],
      ["Yasmine", "Ya3tik sa7a khalti, nti mli7a bezzaf.", "يعطيك الصحة خالتي، نتي مليحة بزاف.", "Merci beaucoup, madame, vous êtes très gentille."],
      ["Fatiha", "Arwa7i nechorbou 9ahwa ghedwa fel l3achiya.", "أرواحي نشربو قهوة غدوة في العشية.", "Viens boire un café demain après-midi."],
      ["Yasmine", "3la rassi!", "على راسي!", "Avec plaisir !"]
    ],
    q: [
      { q: "Depuis quand Yasmine habite-t-elle ici ?", o: ["Une semaine", "Un mois", "Un an"], a: 0 },
      { q: "D'où vient-elle ?", o: ["De Tlemcen", "D'Alger", "D'Oran"], a: 0 },
      { q: "Pourquoi est-elle venue à Alger ?", o: ["Pour le travail", "Pour ses études", "Pour se marier"], a: 0 }
    ]
  },
  {
    id: 'd-visite-1', cat: 'visite', lvl: 2, t: "Chez la grand-mère", dz: "Kol, kol a wlidi!",
    ctx: "Amina et son frère Rayan rendent visite à leur grand-mère.",
    lines: [
      ["Jedda", "Ya mar7ba, ya mar7ba! Dkhlou, dkhlou!", "يا مرحبا، يا مرحبا! دخلو، دخلو!", "Bienvenue, bienvenue ! Entrez, entrez !"],
      ["Amina", "Salam jedda, tw7achnak bezzaf!", "سلام جدة، توحشناك بزاف!", "Bonjour grand-mère, tu nous as beaucoup manqué !"],
      ["Jedda", "W ana tw7achtkoum! Kifach rahi yemmak?", "وأنا توحشتكم! كيفاش راهي يماك؟", "Et vous, vous m'avez manqué ! Comment va ta mère ?"],
      ["Amina", "Labes, tsallem 3lik bezzaf.", "لاباس، تسلم عليك بزاف.", "Bien, elle te passe le bonjour."],
      ["Jedda", "Allah yselmha. 9a3dou, jibtelkoum tay w makrout.", "الله يسلمها. قعدو، جبتلكم تاي ومقروط.", "Que Dieu la garde. Asseyez-vous, je vous ai apporté du thé et des makrouts."],
      ["Rayan", "Jedda, makrout ta3ek houwa lkhir f Dzayer ga3!", "جدة، المقروط تاعك هو الخير في دزاير قاع!", "Grand-mère, tes makrouts sont les meilleurs de toute l'Algérie !"],
      ["Jedda", "Kol, kol a wlidi, rak r9i9 bezzaf!", "كول، كول أوليدي، راك رقيق بزاف!", "Mange, mange, mon petit, tu es trop maigre !"],
      ["Amina", "Dima t9oul hakda!", "ديما تقول هكذا!", "Elle dit toujours ça !"]
    ],
    q: [
      { q: "Que sert la grand-mère ?", o: ["Du thé et des makrouts", "Du café et des croissants", "De la chorba"], a: 0 },
      { q: "Que dit Rayan des makrouts ?", o: ["Ce sont les meilleurs d'Algérie", "Ils sont trop sucrés", "Il ne les aime pas"], a: 0 },
      { q: "Pourquoi la grand-mère dit-elle « kol, kol » ?", o: ["Elle trouve Rayan trop maigre", "Il a dit qu'il avait faim", "C'est l'heure du dîner"], a: 0 }
    ]
  },
  {
    id: 'd-visite-2', cat: 'visite', lvl: 3, t: "Visite pour une naissance", dz: "Mabrouk 3likoum!",
    ctx: "Samia rend visite à Hanane, qui vient d'avoir un bébé.",
    lines: [
      ["Samia", "Mabrouk 3likoum! Allah ybarek fih.", "مبروك عليكم! الله يبارك فيه.", "Félicitations ! Que Dieu le bénisse."],
      ["Hanane", "Allah ybarek fik, ya3tik sa7a 3la ljiya.", "الله يبارك فيك، يعطيك الصحة على الجية.", "Merci, merci d'être venue."],
      ["Samia", "Wach smitou?", "واش سميتو؟", "Comment il s'appelle ?"],
      ["Hanane", "Smitou Ilyes.", "سميتو إلياس.", "Il s'appelle Ilyes."],
      ["Samia", "Tbarkallah 3lih, chbab bezzaf! Yechbeh l babah.", "تبارك الله عليه، شباب بزاف! يشبه لباباه.", "Qu'il est beau, que Dieu le protège ! Il ressemble à son père."],
      ["Hanane", "Ih, ga3 nnas y9oulou hakda.", "إيه، قاع الناس يقولو هكذا.", "Oui, tout le monde dit ça."],
      ["Samia", "Jebtlou had lhdiya, 7aja sghira.", "جبتلو هاد الهدية، حاجة صغيرة.", "Je lui ai apporté ce cadeau, c'est une petite chose."],
      ["Hanane", "Ya3tik sa7a, ma kanch lazem!", "يعطيك الصحة، ما كانش لازم!", "Merci, il ne fallait pas !"]
    ],
    q: [
      { q: "Quelle formule accompagne le compliment pour écarter le mauvais œil ?", o: ["Tbarkallah 3lih", "Ma3lich", "Bslama"], a: 0 },
      { q: "Comment s'appelle le bébé ?", o: ["Ilyes", "Samir", "Amine"], a: 0 },
      { q: "Que répond Hanane pour le cadeau ?", o: ["Il ne fallait pas", "C'est trop petit", "Rien"], a: 0 }
    ]
  },
  {
    id: 'd-quotidien-1', cat: 'quotidien', lvl: 1, t: "Demander son chemin", dz: "Win kayna lbosta?",
    ctx: "Un visiteur cherche la poste.",
    lines: [
      ["Visiteur", "Smahli khouya, win kayna lbosta?", "سمحلي خويا، وين كاينة البوسطة؟", "Excuse-moi, où est la poste ?"],
      ["Passant", "Lbosta? Rou7 nichan, w f rond-point dour 3la limin.", "البوسطة؟ روح نيشان، وفي الرومبوان دور على اليمين.", "La poste ? Va tout droit, et au rond-point tourne à droite."],
      ["Visiteur", "B3ida?", "بعيدة؟", "C'est loin ?"],
      ["Passant", "La, 9riba. Khamsa d9aye9 bel rjel.", "لا، قريبة. خمسة دقايق بالرجل.", "Non, c'est près. Cinq minutes à pied."],
      ["Visiteur", "W ba3d?", "وبعد؟", "Et après ?"],
      ["Passant", "Ba3d rond-point, tchouf jame3. Lbosta 9bala ljame3.", "بعد الرومبوان، تشوف جامع. البوسطة قبالة الجامع.", "Après le rond-point, tu verras une mosquée. La poste est en face de la mosquée."],
      ["Visiteur", "Ya3tik sa7a!", "يعطيك الصحة!", "Merci !"],
      ["Passant", "Bla mziya.", "بلا مزية.", "De rien."]
    ],
    q: [
      { q: "Quelle direction faut-il prendre ?", o: ["Tout droit puis à droite au rond-point", "À gauche", "Faire demi-tour"], a: 0 },
      { q: "À quelle distance est la poste ?", o: ["Cinq minutes à pied", "Cinquante minutes", "Cinq kilomètres"], a: 0 },
      { q: "Quel repère donne le passant ?", o: ["Une mosquée", "Une banque", "Une école"], a: 0 }
    ]
  },
  {
    id: 'd-quotidien-2', cat: 'quotidien', lvl: 2, t: "À la pharmacie", dz: "3andkoum dwa l ras?",
    ctx: "Un client demande un médicament contre le mal de tête.",
    lines: [
      ["Client", "Salam, 3andkoum dwa ta3 ras?", "سلام، عندكم دوا تاع الراس؟", "Bonjour, vous avez un médicament pour le mal de tête ?"],
      ["Pharmacien", "Ih. 3andek skhana tani?", "إيه. عندك سخانة تاني؟", "Oui. Tu as aussi de la fièvre ?"],
      ["Client", "La, ghir ras. Ma r9adtch mli7.", "لا، غير الراس. ما رقدتش مليح.", "Non, juste la tête. Je n'ai pas bien dormi."],
      ["Pharmacien", "Hak hada. 9ra lwar9a 9bel ma tachorbou.", "هاك هادا. اقرا الورقة قبل ما تشربو.", "Voici. Lis la notice avant de le prendre."],
      ["Client", "Ch7al?", "شحال؟", "C'est combien ?"],
      ["Pharmacien", "Mitin w tes3in.", "ميتين وتسعين.", "Deux cent quatre-vingt-dix."],
      ["Client", "Hak. Sa7it.", "هاك. صحيت.", "Tiens. Merci."],
      ["Pharmacien", "Allah ychafik.", "الله يشافيك.", "Bon rétablissement."]
    ],
    q: [
      { q: "De quoi souffre le client ?", o: ["Mal à la tête", "Fièvre", "Mal au ventre"], a: 0 },
      { q: "Pourquoi, selon lui ?", o: ["Il a mal dormi", "Il a trop mangé", "Il a eu froid"], a: 0 },
      { q: "Que conseille le pharmacien ?", o: ["Lire la notice", "Aller à l'hôpital", "Dormir"], a: 0 }
    ]
  },
  {
    id: 'd-quotidien-3', cat: 'quotidien', lvl: 2, t: "Raconter sa journée", dz: "Wach derti lyoum?",
    ctx: "Le soir, Sami et Ines se racontent leur journée.",
    lines: [
      ["Sami", "Wach derti lyoum?", "واش درتي اليوم؟", "Qu'est-ce que tu as fait aujourd'hui ?"],
      ["Ines", "Nodt bekri, rou7t l lkhedma, w kan 3andi réunion twila.", "نضت بكري، رحت للخدمة، وكان عندي ريونيون طويلة.", "Je me suis levée tôt, je suis allée au travail, et j'avais une longue réunion."],
      ["Sami", "Ya latif! W mba3d?", "يا لطيف! ومبعد؟", "Oh là là ! Et après ?"],
      ["Ines", "Mba3d klit m3a sa7bti, w welit l ddar b tram. W nta?", "مبعد كليت مع صاحبتي، ووليت للدار بالترام. وانت؟", "Après, j'ai mangé avec mon amie et je suis rentrée en tram. Et toi ?"],
      ["Sami", "Ana kount f ddar, 9rit chwiya w tayebt chorba.", "أنا كنت في الدار، قريت شوية وطيبت شوربة.", "Moi j'étais à la maison, j'ai un peu étudié et j'ai préparé une chorba."],
      ["Ines", "Bsa7?! Ghaya, rani ji3ana!", "بصح؟! غاية، راني جيعانة!", "C'est vrai ?! Génial, j'ai faim !"],
      ["Sami", "Yallah, lmakla wajda.", "يالله، الماكلة واجدة.", "Allez, le repas est prêt."]
    ],
    q: [
      { q: "Comment Ines est-elle rentrée ?", o: ["En tram", "En taxi", "À pied"], a: 0 },
      { q: "Qu'a préparé Sami ?", o: ["Une chorba", "Un couscous", "Rien"], a: 0 },
      { q: "Pourquoi Ines est-elle contente ?", o: ["Elle a faim et le repas est prêt", "Elle a fini tôt", "Elle a eu une promotion"], a: 0 }
    ]
  },
  {
    id: 'd-quotidien-4', cat: 'quotidien', lvl: 3, t: "Chercher un appartement", dz: "Ch7al lkraya?",
    ctx: "Un locataire se renseigne sur un appartement à louer.",
    lines: [
      ["Locataire", "Salam, rani nsa9si 3la l'appartement li f l'annonce.", "سلام، راني نسقسي على لابارطمان اللي في لانونس.", "Bonjour, je me renseigne sur l'appartement de l'annonce."],
      ["Propriétaire", "Ih, F3 f tabe9 tlata.", "إيه، F3 في الطابق التالت.", "Oui, un F3 au troisième étage."],
      ["Locataire", "Ch7al lkraya?", "شحال الكراية؟", "Combien est le loyer ?"],
      ["Propriétaire", "Khamsa w 3achrin alf dinar f chhar, w lazem 3am 9dam.", "خمسة وعشرين ألف دينار في الشهر، ولازم عام قدام.", "Vingt-cinq mille dinars par mois, et il faut un an d'avance."],
      ["Locataire", "3am kamel?! Hadi s3iba chwiya. Ma n9derch nkhalles setta chhour?", "عام كامل؟! هادي صعيبة شوية. ما نقدرش نخلص ستة شهور؟", "Un an entier ?! C'est un peu dur. Je ne peux pas payer six mois ?"],
      ["Propriétaire", "Nchoufou… Kayen lma dima, w l'ascenseur yekhdem.", "نشوفو… كاين الما ديما، ولاسانسور يخدم.", "On verra… Il y a toujours de l'eau, et l'ascenseur fonctionne."],
      ["Locataire", "Mli7. N9der nchoufou ghedwa?", "مليح. نقدر نشوفو غدوة؟", "Bien. Je peux le visiter demain ?"],
      ["Propriétaire", "Ih, ghedwa f l3achra. Nstennak 9dam l3imara.", "إيه، غدوة في العشرة. نستناك قدام العمارة.", "Oui, demain à dix heures. Je t'attends devant l'immeuble."]
    ],
    q: [
      { q: "À quel étage est l'appartement ?", o: ["Au troisième", "Au premier", "Au cinquième"], a: 0 },
      { q: "Quelle avance demande le propriétaire ?", o: ["Un an", "Six mois", "Rien"], a: 0, e: "Payer plusieurs mois d'avance est une pratique répandue, mais les conditions varient (à vérifier sur place)." },
      { q: "Ici, « nchoufou » veut dire :", o: ["on verra (sans promettre)", "je regarde", "on se voit"], a: 0 }
    ]
  },
  {
    id: 'd-quotidien-5', cat: 'quotidien', lvl: 4, t: "Sous-entendus", dz: "3ich tchouf!",
    ctx: "Deux collègues plaisantent sur la ponctualité de l'un d'eux.",
    lines: [
      ["Walid", "Ghedwa nji f l'heure, wallah!", "غدوة نجي في لور، والله!", "Demain j'arrive à l'heure, je te jure !"],
      ["Sarah", "Ih, akid… 3ich tchouf!", "إيه، أكيد… عيش تشوف!", "Mais oui, bien sûr… on aura tout vu !"],
      ["Walid", "Yaw, ma tdhekch 3liya!", "ياو، ما تضحكش عليا!", "Eh, ne te moque pas de moi !"],
      ["Sarah", "Ma ndhekch… ghir nchoufou ghedwa.", "ما نضحكش… غير نشوفو غدوة.", "Je ne me moque pas… on verra demain, c'est tout."],
      ["Walid", "Rani n9oullek, ghedwa f tmenya rani hna.", "راني نقولك، غدوة في ثمنية راني هنا.", "Je te dis que demain à huit heures je suis là."],
      ["Sarah", "Inchallah… w ida ma jitch, nta li tkhalles l9ahwa.", "إن شاء الله… وإذا ما جيتش، نتا اللي تخلص القهوة.", "Si Dieu le veut… et si tu n'es pas là, c'est toi qui paies le café."],
      ["Walid", "Khlas, mouwafe9!", "خلاص، موافق!", "Marché conclu !"]
    ],
    q: [
      { q: "Sarah croit-elle Walid ?", o: ["Non, elle est ironique", "Oui, complètement", "Elle ne l'écoute pas"], a: 0 },
      { q: "Que se passe-t-il si Walid est en retard ?", o: ["Il paie le café", "Il est renvoyé", "Il fait la vaisselle"], a: 0 },
      { q: "Ici, « inchallah » exprime surtout :", o: ["un doute amusé", "une prière sincère", "un refus"], a: 0 }
    ]
  }
]);
