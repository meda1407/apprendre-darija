/* Cours — Étape 2 : conversation quotidienne. */

DZ.addDict('nourriture', [
  ["sa7a l yeddik", "صحة ليديك", "merci pour le repas (« santé à tes mains »)", "Bnina bezzaf, sa7a l yeddik!", "C'était délicieux, merci à toi qui l'as préparé !", { v: "saha l yeddik|sa7a lyeddik", u: 1, n: "Se dit à la personne qui a cuisiné." }],
  ["ftour", "فطور", "petit-déjeuner ; repas de rupture du jeûne (Ramadan)", "Lftour f setta w nos.", "La rupture du jeûne est à six heures et demie.", { v: "lftour|ftor", n: "Selon le contexte : le petit-déjeuner, ou le repas du soir pendant le Ramadan." }],
  ["ghda", "الغدا", "déjeuner (repas de midi)", "Wach kayen fel ghda?", "Qu'est-ce qu'il y a au déjeuner ?", { v: "lghda|ghdaa|lghdé" }],
  ["3cha", "العشا", "dîner", "L3cha f tes3a.", "Le dîner est à neuf heures.", { v: "l3cha|3chaa" }]
]);
DZ.addDict('ville', [
  ["ch7al lkilo", "شحال الكيلو", "combien le kilo ?", "Ch7al lkilo ta3 tmatem?", "Combien le kilo de tomates ?", { v: "chhal lkilo|ch7al el kilo" }],
  ["zid", "زيد", "ajoute ; encore", "Zid chwiya.", "Ajoute un peu.", { n: "Zidni = donne-m'en encore." }]
]);
DZ.addDict('expressions', [
  ["khalli", "خلي", "laisse", "Khalli, ana nkhalles.", "Laisse, c'est moi qui paie.", { v: "5alli|khali", n: "Khallih = laisse-le ; khalliha = laisse-la." }],
  ["l'addition", "لاديسيون", "l'addition", "A3tina l'addition, allah ykhallik.", "L'addition, s'il vous plaît.", { v: "laddition|addition" }],
  ["lmenu", "المنيو", "le menu", "Jib lmenu, allah ykhallik.", "Apporte le menu, s'il te plaît.", { v: "menu|le menu" }],
  ["wach dert lyoum", "واش درت اليوم", "qu'as-tu fait aujourd'hui ?", "Wach dert lyoum f lkhedma?", "Qu'as-tu fait aujourd'hui au travail ?", { v: "wech dert lyoum", n: "À une femme : wach derti lyoum ?" }]
]);
DZ.addDict('bases', [
  ["had", "هاد", "ce, cette, ces", "Had simana rani mchaghel.", "Cette semaine je suis occupé.", { v: "hed|hadh" }],
  ["mba3d", "مبعد", "ensuite, après", "Klit, w mba3d rou7t l lkhedma.", "J'ai mangé, et ensuite je suis allé au travail.", { v: "men ba3d|mbaad" }],
  ["dammou khfif", "دمو خفيف", "il est drôle, sympa (lit. « son sang est léger »)", "Sa7bi dammou khfif.", "Mon ami est drôle.", { v: "damou khfif", n: "Le contraire : dammou t9il (il est pénible)." }]
]);

DZ.addStage({
  id: 's2', n: 2,
  title: "Conversation quotidienne",
  dz: "Lhadra ta3 kol nhar",
  desc: "Manger, acheter, se déplacer, parler de soi et de sa journée.",
  lessons: [
    {
      id: 's2-l1', dz: "Rani ji3an!", t: "Manger et boire", min: 12,
      goal: "Dire qu'on a faim ou soif, nommer les plats et remercier pour un repas.",
      blocks: [
        { k: 'p', x: "`Rani ji3an` (j'ai faim), `rani 3atchan` (j'ai soif). Pour demander : `a3tini…` (donne-moi…) ou `n7eb…` (je veux…)." },
        { k: 'table', h: ["Repas", "Darija"], r: [["petit-déjeuner", "`ftour`"], ["déjeuner", "`ghda`"], ["dîner", "`3cha`"]] },
        { k: 'table', h: ["Plat", "Description"], r: [
          ["`ta3am`", "le couscous, plat familial du vendredi"], ["`chorba`", "soupe, incontournable pendant le Ramadan"],
          ["`rechta`", "pâtes fines, spécialité d'Alger"], ["`bourek`", "feuilleté farci"],
          ["`mhajeb`", "crêpe feuilletée farcie"], ["`karantika`", "flan de pois chiches vendu dans la rue"],
          ["`kesra`", "galette de semoule"], ["`makrout`", "gâteau de semoule aux dattes"]
        ] },
        { k: 'note', x: "Avant de manger, on dit `bismillah`. Après, on remercie : `ya3tik sa7a`, ou `sa7a l yeddik` (« santé à tes mains ») à la personne qui a cuisiné." },
        { k: 'note', x: "Pendant le Ramadan, la rupture du jeûne (`ftour`) commence souvent par des dattes et du lait, puis la `chorba`. On se souhaite `sa7a ftourek`." }
      ],
      words: ["nakoul", "nechrob", "ji3an", "3atchan", "chba3t", "ftour", "ghda", "3cha", "khobz", "ma", "9ahwa", "tay", "7lib", "l7am", "djaj", "7out", "khodra", "fakya", "bnin", "ta3am", "chorba", "kesra", "sa7a l yeddik"],
      phrases: [
        ["Rani ji3an, wach kayen nakoulou?", "J'ai faim, qu'est-ce qu'on mange ?", "Avoir faim"],
        ["A3tini kas ma bared, allah ykhallik.", "Donne-moi un verre d'eau fraîche, s'il te plaît.", "Demander à boire"],
        ["Nechrob 9ahwa bla sokkar.", "Je bois le café sans sucre.", "Ses habitudes"],
        ["Bnina bezzaf, sa7a l yeddik!", "C'est délicieux, merci à la cuisinière !", "Remercier pour un repas"]
      ],
      quiz: [
        { t: 'qcm', q: "`Rani 3atchan` =", o: ["J'ai soif", "J'ai faim", "Je suis fatigué"], a: 0 },
        { t: 'qcm', q: "En Algérie, `ta3am` désigne souvent :", o: ["le couscous", "le thé", "la viande"], a: 0 },
        { t: 'type', q: "Traduis : « Je veux un café au lait »", a: ["n7eb 9ahwa b 7lib", "n7eb wa7ed 9ahwa b 7lib", "n7eb kahwa b 7lib"] },
        { t: 'order', fr: "Donne-moi un verre d'eau.", a: "A3tini kas ma" },
        { t: 'qcm', q: "On dit `sa7a l yeddik` :", o: ["à la personne qui a cuisiné", "avant de manger", "en arrivant chez quelqu'un"], a: 0 }
      ]
    },
    {
      id: 's2-l2', dz: "F souk", t: "Faire les courses", min: 12,
      goal: "Demander un prix, une quantité, négocier et payer.",
      blocks: [
        { k: 'p', x: "Au marché (`souk`) ou à l'épicerie (`7anout`), on demande le prix, la quantité, et on discute parfois le prix." },
        { k: 'table', h: ["Darija", "Français"], r: [
          ["`ch7al hada?`", "combien coûte ceci ?"], ["`ch7al lkilo?`", "combien le kilo ?"],
          ["`a3tini kilo…`", "donne-moi un kilo de…"], ["`nos kilo` / `rob3 kilo`", "un demi-kilo / un quart de kilo"],
          ["`zid chwiya`", "ajoute un peu"], ["`barka`", "ça suffit"],
          ["`ghali bezzaf`", "c'est trop cher"], ["`n9es chwiya`", "baisse un peu (le prix)"],
          ["`3andek sarf?`", "tu as de la monnaie ?"], ["`ch7al nkhalsek?`", "combien je te dois ?"]
        ] },
        { k: 'note', x: "Négocier est courant au marché, beaucoup moins dans les magasins aux prix affichés. Le sourire aide : `n9es chwiya, khouya` passe toujours mieux avec bonne humeur." },
        { k: 'warn', x: "Rappel : certains vendeurs annoncent les prix en centimes (« `mitin alf` » peut vouloir dire 2 000 DA). En cas de doute : `b dinar wela b centime?`" }
      ],
      words: ["souk", "7anout", "mol l7anout", "ch7al hada", "ch7al lkilo", "ghali", "rkhis", "n9es chwiya", "zid", "barka", "sarf", "chkara", "ch7al nkhalsek", "nechri", "nos", "rob3", "dinar", "hak"],
      phrases: [
        ["Ch7al lkilo ta3 batata?", "Combien le kilo de pommes de terre ?", "Demander un prix"],
        ["Ghali bezzaf, n9es chwiya.", "C'est trop cher, baisse un peu.", "Négocier"],
        ["A3tini kilo w nos ta3 tmatem.", "Donne-moi un kilo et demi de tomates.", "Demander une quantité"],
        ["3andek sarf? Ma 3andi ghir alf.", "Tu as de la monnaie ? Je n'ai qu'un billet de mille.", "Payer"]
      ],
      quiz: [
        { t: 'qcm', q: "`N9es chwiya` =", o: ["baisse un peu (le prix)", "ajoute un peu", "attends un peu"], a: 0 },
        { t: 'qcm', q: "Pour dire « ça suffit » :", o: ["barka", "zid", "bezzaf"], a: 0 },
        { t: 'type', q: "Traduis : « Combien coûte ceci ? »", a: ["ch7al hada", "ch7al hadi", "chhal hada"] },
        { t: 'order', fr: "C'est trop cher, baisse un peu.", a: "Ghali bezzaf n9es chwiya" },
        { t: 'type', q: "Traduis : « Combien je te dois ? »", a: ["ch7al nkhalsek", "chhal nkhalsek"] }
      ]
    },
    {
      id: 's2-l3', dz: "Noss-noss, allah ykhallik!", t: "Au café et au restaurant", min: 12,
      goal: "Commander, demander l'addition et gérer le moment de payer.",
      blocks: [
        { k: 'p', x: "Le café du coin est une institution. Le `noss-noss` (moitié café, moitié lait) est un grand classique, tout comme le `tay b na3na3` (thé à la menthe)." },
        { k: 'table', h: ["Darija", "Français"], r: [
          ["`wach t7eb?`", "qu'est-ce que tu veux ?"], ["`a3tini wa7ed 9ahwa`", "donne-moi un café"],
          ["`noss-noss`", "café noisette"], ["`bla sokkar`", "sans sucre"],
          ["`kayen tabla?`", "il y a une table ?"], ["`jib lmenu`", "apporte le menu"],
          ["`a3tina l'addition`", "l'addition, s'il vous plaît"], ["`ch7al nkhalsek?`", "combien je te dois ?"]
        ] },
        { k: 'note', x: "Entre amis, on se « dispute » souvent pour payer : `khalli, ana nkhalles!` (laisse, c'est moi qui paie) ou `lyoum 3liya` (aujourd'hui, c'est pour moi). Le perdant paiera la prochaine fois." },
        { k: 'warn', x: "`3afak` (s'il te plaît) est surtout marocain. En Algérie : `allah ykhallik`, `svp` à la française, ou `brabbi` dans l'Est (à vérifier selon la région)." }
      ],
      words: ["9ahwa", "noss-noss", "tay", "na3na3", "sokkar", "kas", "a3tini", "khalli", "lyoum 3liya", "l'addition", "lmenu", "bnin", "ch7al nkhalsek", "kaskrout", "mchwi"],
      phrases: [
        ["Ana wa7ed noss-noss, w nta?", "Pour moi un noisette, et toi ?", "Commander au café"],
        ["A3tini tay b na3na3 bla sokkar.", "Donne-moi un thé à la menthe sans sucre.", "Préciser sa commande"],
        ["Khalli, lyoum 3liya!", "Laisse, aujourd'hui c'est moi qui invite !", "Inviter"],
        ["Lmakla kanet bnina, ya3tik sa7a.", "Le repas était délicieux, merci.", "Remercier le serveur"]
      ],
      quiz: [
        { t: 'qcm', q: "Un `noss-noss`, c'est :", o: ["un café moitié lait", "un demi-thé", "une demi-portion"], a: 0 },
        { t: 'qcm', q: "`Lyoum 3liya` veut dire :", o: ["aujourd'hui, j'invite", "aujourd'hui, je suis fatigué", "aujourd'hui, c'est fermé"], a: 0 },
        { t: 'type', q: "Traduis : « sans sucre »", a: ["bla sokkar", "bla soukar"] },
        { t: 'order', fr: "Laisse, c'est moi qui paie.", a: "Khalli ana nkhalles" }
      ]
    },
    {
      id: 's2-l4', dz: "Ddini l lagar", t: "Prendre un taxi", min: 10,
      goal: "Annoncer une destination, demander le prix et guider le chauffeur.",
      blocks: [
        { k: 'p', x: "En ville, on prend un taxi officiel ou un `clando` (taxi non officiel, prix à négocier). On annonce la destination, on demande le prix, puis on indique où s'arrêter." },
        { k: 'table', h: ["Darija", "Français"], r: [
          ["`ddini l…`", "emmène-moi à…"], ["`ch7al l…?`", "combien pour aller à… ?"],
          ["`rani m3attel`", "je suis en retard"], ["`b chwiya`", "doucement"], ["`fissa`", "vite"],
          ["`rou7 nichan`", "va tout droit"], ["`dour 3la limin / 3la lissar`", "tourne à droite / à gauche"],
          ["`7bes hna`", "arrête-toi ici"]
        ] },
        { k: 'warn', x: "Le mot `clando` est familier ; les pratiques (prix, compteurs) varient selon les villes. Mettez-vous d'accord sur le prix avant de monter." }
      ],
      words: ["taxi", "clando", "ddini", "7bes", "fissa", "b chwiya", "m3attel", "nichan", "3la limin", "3la lissar", "lagar", "lmatar", "za7ma", "nrkeb", "tri9"],
      phrases: [
        ["Ddini l lagar, allah ykhallik.", "Emmène-moi à la gare, s'il te plaît.", "Annoncer la destination"],
        ["Ch7al l lmatar?", "Combien pour l'aéroport ?", "Demander le prix"],
        ["Rani m3attel, rou7 fissa!", "Je suis en retard, va vite !", "Être pressé"],
        ["7bes hna 9dam lbosta, sa7it.", "Arrête-toi ici devant la poste, merci.", "Descendre"]
      ],
      quiz: [
        { t: 'qcm', q: "`7bes hna` =", o: ["arrête-toi ici", "tourne ici", "attends ici"], a: 0 },
        { t: 'type', q: "Traduis : « Emmène-moi à la gare »", a: ["ddini l lagar", "ddini lagar", "eddini l lagar"] },
        { t: 'qcm', q: "Un `clando` est :", o: ["un taxi non officiel", "un bus", "un billet de train"], a: 0 },
        { t: 'order', fr: "Je suis en retard, va vite !", a: "Rani m3attel rou7 fissa" }
      ]
    },
    {
      id: 's2-l5', dz: "Win kayna lbosta?", t: "Demander son chemin", min: 10,
      goal: "Demander où se trouve un lieu et comprendre la réponse.",
      blocks: [
        { k: 'p', x: "Formule de base : `smahli, win kayen…?` pour un mot masculin, `win kayna…?` pour un mot féminin : `win kayna lbosta?` (où est la poste ?)." },
        { k: 'table', h: ["Darija", "Français"], r: [
          ["`nichan`", "tout droit"], ["`3la limin`", "à droite"], ["`3la lissar`", "à gauche"], ["`7da`", "à côté de"],
          ["`9bala`", "en face de"], ["`9dam`", "devant"], ["`mor`", "derrière"], ["`9rib` / `b3id`", "près / loin"]
        ] },
        { k: 'tip', x: "On vous donnera souvent des repères plutôt que des noms de rues : la mosquée, la pharmacie, le rond-point…" }
      ],
      words: ["win kayen", "9rib", "b3id", "nichan", "3la limin", "3la lissar", "dour", "7da", "9bala", "mor", "9dam", "rond-point", "bel rjel", "chari3", "lbosta", "pharmacie", "jame3", "banka"],
      phrases: [
        ["Smahli, win kayna pharmacie?", "Excusez-moi, où y a-t-il une pharmacie ?", "Demander"],
        ["Rou7 nichan, w dour 3la limin.", "Va tout droit, et tourne à droite.", "Comprendre la direction"],
        ["Rahi 7da lbanka, 9bala ljame3.", "Elle est à côté de la banque, en face de la mosquée.", "Repères"],
        ["B3ida? — La, khamsa d9aye9 bel rjel.", "C'est loin ? — Non, cinq minutes à pied.", "Distance"]
      ],
      quiz: [
        { t: 'qcm', q: "`3la lissar` =", o: ["à gauche", "à droite", "tout droit"], a: 0 },
        { t: 'type', q: "Traduis : « Va tout droit »", a: ["rou7 nichan", "rouh nichan"] },
        { t: 'order', fr: "Excusez-moi, où est la poste ?", a: "Smahli win kayna lbosta" },
        { t: 'qcm', q: "`9dam lbab` =", o: ["devant la porte", "derrière la porte", "à côté de la porte"], a: 0 }
      ]
    },
    {
      id: 's2-l6', dz: "Wach tekhdem?", t: "Parler de son travail", min: 10,
      goal: "Dire son métier, son lieu de travail et parler de sa semaine.",
      blocks: [
        { k: 'p', x: "`Wach tekhdem?` = qu'est-ce que tu fais comme travail ? On répond `nekhdem f…` (je travaille à/dans…) ou `ana` + métier : `ana tbib` (je suis médecin)." },
        { k: 'p', x: "Beaucoup de métiers se disent en français : `ana ingénieur`, `ana infirmière`, `nekhdem comptable`. C'est tout à fait naturel." },
        { k: 'table', h: ["Darija", "Français"], r: [
          ["`rani khaddam`", "j'ai un emploi"], ["`rani bettal`", "je suis au chômage"], ["`rani f conji`", "je suis en congé"],
          ["`3andi réunion`", "j'ai une réunion"], ["`rani mchaghel`", "je suis occupé"], ["`lchahriya`", "le salaire"]
        ] },
        { k: 'note', x: "Un emploi dans la fonction publique (`lkhedma ta3 dawla`) est traditionnellement apprécié pour sa stabilité." }
      ],
      words: ["khedma", "nekhdem", "khaddam", "wach tekhdem", "patron", "chahriya", "burou", "conji", "bettal", "réunion", "charika", "tbib", "tajer", "msta3jel", "mchaghel", "retraite", "had"],
      phrases: [
        ["Nekhdem f sbitar, ana infirmier.", "Je travaille à l'hôpital, je suis infirmier.", "Dire son métier"],
        ["Lyoum 3andi réunion m3a lpatron.", "Aujourd'hui j'ai une réunion avec le patron.", "Sa journée"],
        ["Rani mchaghel bezzaf had simana.", "Je suis très occupé cette semaine.", "Être occupé"],
        ["Rak f conji? — Ih, men lbare7.", "Tu es en congé ? — Oui, depuis hier.", "Congés"]
      ],
      quiz: [
        { t: 'qcm', q: "`Rani bettal` =", o: ["je suis au chômage", "je suis en congé", "je suis pressé"], a: 0 },
        { t: 'type', q: "Traduis : « Je travaille à l'hôpital »", a: ["nekhdem f sbitar", "nkhdem f sbitar", "nekhdem fel sbitar"] },
        { t: 'order', fr: "Je suis très occupé cette semaine.", a: "Rani mchaghel bezzaf had simana" },
        { t: 'qcm', q: "`Lchahriya` =", o: ["le salaire", "le mois", "la retraite"], a: 0 }
      ]
    },
    {
      id: 's2-l7', dz: "Sa7bi w s7abi", t: "Parler de ses amis", min: 10,
      goal: "Présenter un ami et le décrire.",
      blocks: [
        { k: 'p', x: "Pour décrire quelqu'un, l'adjectif s'accorde : `sa7bi fahem` (mon ami est intelligent), `sa7bti fahma` (mon amie est intelligente)." },
        { k: 'p', x: "Une expression très algérienne : `dammou khfif` (« son sang est léger ») = il est drôle, sympathique. Le contraire, `dammou t9il`, veut dire qu'il est lourd, pénible." },
        { k: 'note', x: "L'amitié se dit souvent en termes de fraternité : `khouya`, `ya kho`, `khawa`. Dire de quelqu'un `rana khawa` (on est frères), c'est un grand compliment." }
      ],
      words: ["sa7bi", "sa7bti", "s7abi", "khawa", "n3arfek bih", "tla9ina", "dammou khfif", "khfif", "t9il", "mli7", "chbab", "fahem", "nokhroj", "zhit", "tw7achtek", "ya kho"],
      phrases: [
        ["Hada sa7bi Amine, tla9ina f la fac.", "Voici mon ami Amine, on s'est rencontrés à la fac.", "Présenter un ami"],
        ["Sa7bi dammou khfif, dima ydhekna.", "Mon ami est drôle, il nous fait toujours rire.", "Décrire"],
        ["Nokhroj m3a s7abi nhar ljem3a.", "Je sors avec mes amis le vendredi.", "Habitudes"],
        ["Arwa7, n3arfek b sa7bti Lina.", "Viens, je te présente mon amie Lina.", "Faire les présentations"]
      ],
      quiz: [
        { t: 'qcm', q: "`Dammou khfif` veut dire :", o: ["il est drôle, sympa", "il est malade", "il est maigre"], a: 0 },
        { t: 'qcm', q: "« Mes amis » se dit :", o: ["s7abi", "sa7bi", "sa7bti"], a: 0 },
        { t: 'order', fr: "Je sors avec mes amis.", a: "Nokhroj m3a s7abi" },
        { t: 'type', q: "Traduis : « mon amie »", a: ["sa7bti", "sahbti"] }
      ]
    },
    {
      id: 's2-l8', dz: "Wach dert lyoum?", t: "Parler de sa journée", min: 12,
      goal: "Raconter sa journée au passé, dans l'ordre.",
      blocks: [
        { k: 'p', x: "Pour raconter, on enchaîne les verbes au passé avec `w` (et) et `mba3d` (ensuite)." },
        { k: 'table', h: ["Présent (je)", "Passé (j'ai…)", "Français"], r: [
          ["`nnoud`", "`nodt`", "se lever"], ["`nrou7`", "`rou7t`", "aller"], ["`nekhdem`", "`khdemt`", "travailler"],
          ["`nakoul`", "`klit`", "manger"], ["`nwelli`", "`welit`", "revenir"], ["`nchouf`", "`cheft`", "voir"], ["`ndir`", "`dert`", "faire"]
        ] },
        { k: 'tip', x: "Au passé, « j'ai » et « tu as » (à un homme) ont souvent la même forme : `klit` = j'ai mangé / tu as mangé. Le contexte décide. À une femme : `kliti`." }
      ],
      words: ["wach dert lyoum", "nnoud", "nrou7", "nekhdem", "nakoul", "nwelli", "mba3d", "sba7", "l3achiya", "lil", "ba3d", "bekri", "3ayan", "nr9ed"],
      phrases: [
        ["Nodt f setta, w rou7t l lkhedma b tram.", "Je me suis levé à six heures et je suis allé au travail en tram.", "Le matin"],
        ["Klit m3a s7abi, w mba3d welit l ddar.", "J'ai mangé avec mes amis, puis je suis rentré à la maison.", "L'après-midi"],
        ["Lyoum kan nhar twil, rani 3ayan.", "Aujourd'hui a été une longue journée, je suis fatigué.", "Bilan"],
        ["Fel lil chefna film.", "Le soir, on a regardé un film.", "Le soir"]
      ],
      quiz: [
        { t: 'qcm', q: "`Klit` =", o: ["j'ai mangé", "je mange", "mange !"], a: 0 },
        { t: 'type', q: "Traduis : « Je suis allé au travail »", a: ["rou7t l lkhedma", "rouht l lkhedma", "rou7t lel khedma"] },
        { t: 'order', fr: "Ensuite je suis rentré à la maison.", a: "Mba3d welit l ddar" },
        { t: 'qcm', q: "À une femme, « qu'as-tu fait aujourd'hui ? » se dit :", o: ["wach derti lyoum?", "wach dert lyoum?", "wach dertou lyoum?"], a: 0 }
      ]
    },
    {
      id: 's2-l9', dz: "N7eb, n7taj, lazemli", t: "Exprimer ses goûts et ses besoins", min: 10,
      goal: "Dire ce qu'on aime, ce qu'on veut et ce dont on a besoin.",
      blocks: [
        { k: 'p', x: "`N7eb` + nom = j'aime : `n7eb lb7ar` (j'aime la mer). `N7eb` + verbe = je veux : `n7eb nrou7` (je veux partir). Le contexte fait la différence." },
        { k: 'p', x: "`3jebni` (ça m'a plu) s'accorde avec la chose qui plaît : `3jebni lfilm`, `3ajbetni lmakla` (féminin), `3ajbouni` (pluriel). Négatif : `ma 3jebnich`." },
        { k: 'p', x: "Le besoin : `n7taj` (j'ai besoin) ou `lazemli` (il me faut)." },
        { k: 'tip', x: "Pour dire « j'adore », les Algériens exagèrent volontiers : `nmout 3la…` (« je meurs pour… ») : `nmout 3la ta3am ta3 yemma`." }
      ],
      words: ["n7eb", "3jebni", "ma 3jebnich", "n7taj", "lazemli", "nmout 3lik", "bezzaf", "chwiya", "ktar", "mli7", "khayeb", "ghaya"],
      phrases: [
        ["N7eb lb7ar, bsa7 ma n7ebch skhana.", "J'aime la mer, mais je n'aime pas la chaleur.", "Goûts"],
        ["3ajbetni lmakla bezzaf!", "J'ai beaucoup aimé le repas !", "Ça m'a plu"],
        ["N7taj chwiya drahem.", "J'ai besoin d'un peu d'argent.", "Besoin"],
        ["Lazemli sebbat jdid.", "Il me faut de nouvelles chaussures.", "Il me faut"],
        ["Nmout 3la ta3am ta3 yemma.", "J'adore le couscous de ma mère.", "Adorer"]
      ],
      quiz: [
        { t: 'qcm', q: "`N7eb nrou7` veut dire :", o: ["je veux partir", "j'aime la route", "je suis parti"], a: 0 },
        { t: 'qcm', q: "« Le film ne m'a pas plu » :", o: ["lfilm ma 3jebnich", "lfilm 3jebni", "lfilm ma n7ebch"], a: 0 },
        { t: 'type', q: "Traduis : « J'ai besoin d'argent »", a: ["n7taj drahem", "n7taj chwiya drahem", "lazemli drahem"] },
        { t: 'order', fr: "J'aime la mer, mais je n'aime pas la chaleur.", a: "N7eb lb7ar bsa7 ma n7ebch skhana" }
      ]
    }
  ]
});
