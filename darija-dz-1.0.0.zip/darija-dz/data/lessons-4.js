/* Cours — Étape 4 : niveau avancé. */

DZ.addDict('expressions', [
  ["dammou t9il", "دمو ثقيل", "il est pénible, lourd (lit. « son sang est lourd »)", "Hadak dammou t9il, ma n7ebouch.", "Celui-là est pénible, je ne l'aime pas.", { v: "damou t9il|dammou tqil" }],
  ["3la rassi w 3ini", "على راسي وعيني", "avec grand plaisir (lit. « sur ma tête et mon œil »)", "— T3awenni? — 3la rassi w 3ini!", "— Tu m'aides ? — Avec grand plaisir !", { v: "3la rasi w 3ini" }],
  ["rassi ydour", "راسي يدور", "j'ai la tête qui tourne ; je suis débordé", "Bezzaf khedma, rassi ydour.", "Trop de travail, j'ai la tête qui tourne.", { v: "rasi ydour", u: 1 }],
  ["3inou kbira", "عينو كبيرة", "il est envieux, jamais satisfait (lit. « son œil est grand »)", "3inou kbira, dima y7eb ktar.", "Il n'est jamais satisfait, il en veut toujours plus.", { u: 1 }],
  ["dar rasou", "دار راسو", "il n'en a fait qu'à sa tête", "Ma sma3ch lhadra, dar rasou.", "Il n'a pas écouté, il n'en a fait qu'à sa tête.", { v: "dar rassou", u: 1 }],
  ["ma 3andou ma ydir", "ما عندو ما يدير", "il n'a rien à faire ; il n'y peut rien", "Ma 3andou ma ydir, rah 9a3ed f l7ouma.", "Il n'a rien à faire, il traîne au quartier.", { v: "ma3andou ma ydir" }],
  ["kima yji", "كيما يجي", "comme ça vient, n'importe comment", "Ydir lkhedma kima yji.", "Il fait le travail n'importe comment.", { u: 1 }],
  ["allah yr7mou", "الله يرحمه", "que Dieu ait son âme (en parlant d'un défunt)", "Jeddi, allah yr7mou, kan rajel mli7.", "Mon grand-père, paix à son âme, était un homme bien.", { v: "allah yrahmou|lah yr7mou", n: "Pour une femme : allah yr7amha." }],
  ["lbaraka f rassek", "البركة في راسك", "mes condoléances", "Lbaraka f rassek, allah yr7mou.", "Mes condoléances, que Dieu ait son âme.", { v: "lbaraka f rasek|el baraka fi rassek" }],
  ["ma cha2a allah", "ما شاء الله", "magnifique ! (admiration qui écarte le mauvais œil)", "Ma cha2a allah, darek chbaba!", "Magnifique, ta maison est très belle !", { v: "machallah|ma chaa allah|mashallah|machaallah" }],
  ["l3in", "العين", "le mauvais œil", "Ma t9oulch, l3in!", "Ne le dis pas, attention au mauvais œil !", { v: "el 3in|l3ayn" }]
]);

DZ.addStage({
  id: 's4', n: 4,
  title: "Niveau avancé",
  dz: "Twelli dzayri!",
  desc: "Idiomes, argot, proverbes, humour, variantes régionales et nuances culturelles.",
  lessons: [
    {
      id: 's4-l1', dz: "Dammou khfif", t: "Les expressions idiomatiques", min: 14,
      goal: "Comprendre des expressions imagées dont le sens n'est pas littéral.",
      blocks: [
        { k: 'p', x: "Beaucoup d'expressions algériennes utilisent le corps : le sang (`dem`), la tête (`ras`), l'œil (`3in`), le cœur (`9alb`)." },
        { k: 'table', h: ["Expression", "Mot à mot", "Sens"], r: [
          ["`dammou khfif`", "son sang est léger", "il est drôle, sympa"],
          ["`dammou t9il`", "son sang est lourd", "il est pénible"],
          ["`3la rassi w 3ini`", "sur ma tête et mon œil", "avec grand plaisir"],
          ["`tla3li ddem`", "le sang m'est monté", "ça m'a énervé"],
          ["`rassi ydour`", "ma tête tourne", "je suis débordé"],
          ["`3inou kbira`", "son œil est grand", "il n'est jamais satisfait"],
          ["`dar rasou`", "il a fait sa tête", "il n'en a fait qu'à sa tête"],
          ["`bessif`", "par le sabre", "de force, contre son gré"]
        ] },
        { k: 'warn', x: "Certaines de ces expressions (marquées « à vérifier » dans le dictionnaire) varient selon les régions ou les générations. Écoutez comment elles sont employées autour de vous avant de les utiliser." }
      ],
      words: ["dammou khfif", "dammou t9il", "3la rassi w 3ini", "tla3li ddem", "rassi ydour", "3inou kbira", "dar rasou", "ma 3andou ma ydir", "kima yji", "bessif", "bel3ani"],
      phrases: [
        ["Sa7bek dammou khfif, n7ebou.", "Ton ami est drôle, je l'aime bien.", "Compliment"],
        ["Bezzaf khedma had simana, rassi ydour.", "Trop de travail cette semaine, je suis débordé.", "Être débordé"],
        ["Rou7t bessif, ma kountch n7eb.", "J'y suis allé de force, je ne voulais pas.", "Contre son gré"]
      ],
      quiz: [
        { t: 'qcm', q: "`Dammou t9il` décrit quelqu'un de :", o: ["pénible", "drôle", "malade"], a: 0 },
        { t: 'qcm', q: "`3la rassi w 3ini` s'utilise pour :", o: ["accepter avec plaisir", "refuser", "s'excuser"], a: 0 },
        { t: 'qcm', q: "`Bessif` =", o: ["de force", "doucement", "exprès"], a: 0 },
        { t: 'order', fr: "Ton ami est drôle.", a: "Sa7bek dammou khfif" }
      ]
    },
    {
      id: 's4-l2', dz: "Hogra, hittiste, harraga…", t: "L'argot algérien", min: 14,
      goal: "Comprendre les mots d'argot qui racontent la société algérienne.",
      blocks: [
        { k: 'p', x: "Plusieurs mots d'argot algérien sont si expressifs qu'ils sont passés dans le français d'Algérie et même dans la presse internationale." },
        { k: 'table', h: ["Mot", "Sens", "Origine"], r: [
          ["`7ogra`", "mépris, injustice ressentie", "verbe « mépriser »"],
          ["`7itist`", "jeune sans emploi qui « tient les murs »", "`7it` (mur) + « -iste »"],
          ["`7arraga`", "migrants clandestins", "`7reg` (brûler) : ils « brûlent » les frontières"],
          ["`trabendo`", "commerce informel", "probablement de l'espagnol « contrabando »"],
          ["`zawali`", "pauvre, modeste", "souvent dit avec tendresse"],
          ["`dégoûtage`", "ras-le-bol", "du français « dégoût »"],
          ["`zhou`", "fête, bonne ambiance", "`zhit` = je me suis amusé"],
          ["`9afez`", "malin, débrouillard", ""]
        ] },
        { k: 'note', x: "Ces mots parlent de réalités sociales parfois douloureuses (chômage, émigration). Employez-les avec tact, surtout `7arraga` et `7itist`." },
        { k: 'warn', x: "L'argot évolue vite et varie selon les villes et les générations. Les mots marqués « à vérifier » sont attestés mais leur usage actuel peut avoir changé." }
      ],
      words: ["7ogra", "7itist", "7arraga", "trabendo", "zawali", "dégoûtage", "kho", "zhou", "zhit", "fa9ou", "ya lkhawa", "tchipa", "9afez", "lkhadra", "bezzaf 3lik"],
      phrases: [
        ["Hadi 7ogra, ma n9derch nskot!", "C'est une injustice, je ne peux pas me taire !", "Dénoncer"],
        ["Wach ya lkhawa, kan zhou lbare7!", "Salut les gars, c'était trop bien hier !", "Entre amis"],
        ["Rah 9afez, dima yalga 7all.", "Il est débrouillard, il trouve toujours une solution.", "Décrire"]
      ],
      quiz: [
        { t: 'qcm', q: "Un `7itist` est :", o: ["un jeune sans emploi qui tient les murs", "un maçon", "un chauffeur de taxi"], a: 0 },
        { t: 'qcm', q: "`7ogra` exprime :", o: ["un sentiment d'injustice et de mépris", "la joie d'une fête", "la fatigue"], a: 0 },
        { t: 'qcm', q: "`Zhou` =", o: ["la fête, l'ambiance", "la colère", "le travail"], a: 0 },
        { t: 'type', q: "Comment s'appelle l'équipe nationale de football ?", a: ["lkhadra", "el khadra"] }
      ]
    },
    {
      id: 's4-l3', dz: "Li fat mat", t: "Les proverbes", min: 15,
      goal: "Comprendre et placer quelques proverbes très connus.",
      blocks: [
        { k: 'p', x: "Les proverbes sont très présents dans la conversation, surtout chez les aînés. On les cite pour conclure une discussion ou donner un conseil." },
        { k: 'table', h: ["Proverbe", "Sens"], r: [
          ["`li fat mat`", "le passé est le passé"],
          ["`sber mefta7 lfaraj`", "la patience est la clé du soulagement"],
          ["`yed wa7da ma tsaffe9ch`", "une seule main n'applaudit pas (l'union fait la force)"],
          ["`ljar 9bel ddar`", "choisis tes voisins avant ta maison"],
          ["`kol khanfous f 3in yemmah ghzal`", "aux yeux d'une mère, son enfant est toujours beau"],
          ["`li yeddou fel ma machi kima li yeddou fel nar`", "on ne juge pas la souffrance d'autrui de l'extérieur"],
          ["`li 7fer 7ofra l khouh ta7 fiha`", "qui creuse un trou pour son frère y tombe"]
        ] },
        { k: 'warn', x: "Les proverbes existent souvent en plusieurs versions, et beaucoup sont partagés avec le Maroc et la Tunisie. Plusieurs formulations de l'application sont marquées « à vérifier » : demandez à un locuteur natif sa version." }
      ],
      words: ["li fat mat", "sber mefta7 lfaraj", "yed wa7da ma tsaffe9ch", "ljar 9bel ddar", "kol khanfous f 3in yemmah ghzal", "li yeddou fel ma machi kima li yeddou fel nar", "li 7fer 7ofra l khouh ta7 fiha", "dir kima dar jarek wela beddel bab darek", "kol nhar w rez9ou", "dir lkhir w nsah", "lfomm lmghelle9 ma tedkhlou dbana", "lkedba 7belha 9sir"],
      phrases: [
        ["Ma tkhammemch, li fat mat.", "Ne t'en fais pas, le passé est le passé.", "Consoler"],
        ["Lazem n3awnou ba3dana, yed wa7da ma tsaffe9ch.", "Il faut s'entraider : une seule main n'applaudit pas.", "Encourager l'entraide"],
        ["Sber khouya, sber mefta7 lfaraj.", "Patience, mon frère : la patience est la clé du soulagement.", "Encourager la patience"]
      ],
      quiz: [
        { t: 'qcm', q: "`Li fat mat` signifie :", o: ["le passé est le passé", "celui qui part meurt", "le temps passe vite"], a: 0 },
        { t: 'qcm', q: "Quel proverbe encourage l'entraide ?", o: ["yed wa7da ma tsaffe9ch", "li fat mat", "ljar 9bel ddar"], a: 0 },
        { t: 'qcm', q: "`Sber mefta7 lfaraj` =", o: ["la patience est la clé du soulagement", "la clé est sous la porte", "il faut se dépêcher"], a: 0 },
        { t: 'type', q: "Complète le proverbe : « kol khanfous f 3in yemmah … »", a: ["ghzal"] }
      ]
    },
    {
      id: 's4-l4', dz: "Nchoufou… inchallah", t: "Humour et sous-entendus", min: 14,
      goal: "Saisir l'ironie, les refus polis et l'exagération.",
      blocks: [
        { k: 'p', x: "Une grande partie du sens passe par le ton. Les mêmes mots peuvent être sincères ou ironiques." },
        { k: 'table', h: ["Ce qu'on dit", "Ce qu'on peut vouloir dire"], r: [
          ["`nchoufou`", "on verra… (souvent : probablement pas)"],
          ["`inchallah`", "si Dieu le veut (vrai espoir, ou « peut-être » poli)"],
          ["`ghir hakda`", "comme ça… (je ne veux pas en parler)"],
          ["`3ich tchouf`", "on aura tout vu ! (étonnement amusé)"],
          ["`ya zawali!`", "le pauvre ! (compassion, ou moquerie gentille)"],
          ["`rak mahboul?`", "t'es fou ? (souvent affectueux)"],
          ["`nmout 3lik`", "je t'adore (exagération affectueuse)"]
        ] },
        { k: 'story', x: [
          ["— Ghedwa nji f l'heure, wallah!", "— Demain j'arrive à l'heure, je te jure !"],
          ["— Ih, akid… 3ich tchouf!", "— Mais oui, bien sûr… on aura tout vu !"],
          ["— Yaw, ma tdhekch 3liya!", "— Eh, ne te moque pas de moi !"],
          ["— Ma ndhekch… ghir nchoufou ghedwa.", "— Je ne me moque pas… on verra demain, c'est tout."]
        ] },
        { k: 'note', x: "Les Algériens aiment taquiner, y compris sur les accents des autres régions. C'est en général bon enfant ; tant que vous n'êtes pas à l'aise, restez du côté de celui qui rit, pas de celui qui moque." }
      ],
      words: ["nchoufou", "inchallah", "ghir hakda", "3ich tchouf", "zawali", "mahboul", "nmout 3lik", "bezzaf 3lik", "yaw", "nedhak"],
      phrases: [
        ["— Tji l3ers? — Inchallah, nchoufou.", "— Tu viens au mariage ? — Si Dieu le veut, on verra.", "Réponse vague"],
        ["Hadi bezzaf 3lik, ya kho!", "Là, tu exagères, mec !", "Taquiner"],
        ["Ya zawali, stenna tobis sa3a kamla w ma ja.", "Le pauvre, il a attendu le bus une heure entière et il n'est pas venu.", "Compatir avec humour"]
      ],
      quiz: [
        { t: 'qcm', q: "Ton ami répond `nchoufou` à une invitation. Le plus probable :", o: ["il n'est pas sûr de venir", "il viendra sûrement", "il est fâché"], a: 0 },
        { t: 'qcm', q: "`3ich tchouf` exprime :", o: ["un étonnement amusé", "une menace", "un remerciement"], a: 0 },
        { t: 'qcm', q: "Dans le petit dialogue, le second personnage :", o: ["ne croit pas que l'autre sera à l'heure", "est en retard", "est fâché"], a: 0 }
      ]
    },
    {
      id: 's4-l5', dz: "Hadra fissa", t: "Les dialogues rapides", min: 12,
      goal: "Suivre des échanges courts et rapides comme dans la rue.",
      blocks: [
        { k: 'p', x: "À l'oral rapide, les voyelles disparaissent et les mots se collent : `wach rak` → « wachrak », `f el ddar` → « fddar », `ma na3refch` → « man3refch ». L'écriture latine reste la même ; c'est l'oreille qu'il faut entraîner." },
        { k: 'story', x: [
          ["— Sa7a! — Sa7a, kirak? — Labes, w nta? — Labes. Yallah, nchoufek.", "— Salut ! — Salut, ça va ? — Ça va, et toi ? — Ça va. Allez, à plus."],
          ["— Ch7al? — Mitin. — Ghali! — Mya w khamsin, khlas. — Hak.", "— Combien ? — Deux cents. — Cher ! — Cent cinquante, c'est bon. — Tiens."],
          ["— Win rak? — Jay jay! — Fissa, rana nstennaw! — Dorka nousel.", "— T'es où ? — J'arrive, j'arrive ! — Vite, on t'attend ! — J'arrive tout de suite."],
          ["— 7bes hna! — Hna? — Ih, hna, sa7it. — Bslama.", "— Arrête-toi ici ! — Ici ? — Oui, ici, merci. — Au revoir."]
        ] },
        { k: 'tip', x: "Entraînez-vous dans la section Dialogues : affichez d'abord seulement la darija, essayez de comprendre, puis révélez la traduction réplique par réplique." }
      ],
      words: ["sa7a", "kirak", "labes", "yallah", "nchoufek", "khlas", "hak", "fissa", "jay", "dorka", "7bes"],
      phrases: [
        ["Jay jay, dorka nousel!", "J'arrive, j'arrive, je suis là dans une minute !", "Au téléphone"],
        ["Khlas, hak, bslama.", "C'est bon, tiens, au revoir.", "Conclure une transaction"]
      ],
      quiz: [
        { t: 'qcm', q: "`Jay jay!` au téléphone veut dire :", o: ["J'arrive !", "Viens !", "Je suis parti"], a: 0 },
        { t: 'qcm', q: "`Mya w khamsin, khlas.` =", o: ["Cent cinquante, c'est bon.", "Cent cinquante, c'est trop.", "Cinquante, pas plus."], a: 0 },
        { t: 'order', fr: "Vite, on t'attend !", a: "Fissa rana nstennaw" }
      ]
    },
    {
      id: 's4-l6', dz: "Men Wahran l Qsentina", t: "Les variantes régionales", min: 15,
      goal: "Reconnaître les grandes différences entre régions.",
      blocks: [
        { k: 'warn', x: "Ce tableau simplifie beaucoup : les usages changent d'une ville à l'autre, entre la ville et la campagne, et selon l'âge. Les points marqués « à vérifier » doivent être confirmés auprès de locuteurs de la région." },
        { k: 'table', h: ["Trait", "Centre (Alger)", "Ouest (Oran…)", "Est (Constantine…)"], r: [
          ["Le son ق", "souvent « q » : `9al`", "souvent « g » : `gal`", "« q » en ville, « g » ailleurs (à vérifier)"],
          ["« tu » (homme)", "`nta`", "`nta`", "souvent `nti` pour les deux genres"],
          ["« oui »", "`ih`", "`wah`, `ih`", "`ih`"],
          ["« de » (appartenance)", "`ta3`", "`nta3`", "`ta3` (à vérifier)"],
          ["futur", "`ra7`", "`ra7`, aussi `ghadi` (à vérifier)", "`ra7`"],
          ["« thé »", "`tay`", "`atay` fréquent", "`tay`"]
        ] },
        { k: 'p', x: "Quelques particularités souvent citées : à Tlemcen, le ق est prononcé comme un petit arrêt de voix (« 2al » pour « il a dit ») ; à Jijel, il devient « k » (« kal »). Ces traits sont connus dans toute l'Algérie et font souvent l'objet de taquineries amicales." },
        { k: 'note', x: "L'Algérie est aussi un pays amazigh : le tamazight (kabyle, chaoui, mozabite, touareg…) est une langue officielle, différente de la darija. Beaucoup d'Algériens parlent les deux, et la darija emprunte de nombreux mots au tamazight." },
        { k: 'tip', x: "L'application utilise comme référence une darija du Centre largement comprise partout. Si vous apprenez avec une famille d'une autre région, ajoutez vos propres mots dans le dictionnaire (« Mes mots »)." }
      ],
      words: ["wah", "ih", "ta3", "tay", "nti", "dorka", "brabbi", "9oli", "n9oul", "9ahwa"],
      phrases: [
        ["9alli: « Arwa7 ghedwa ».", "Il m'a dit : « Viens demain ».", "Prononcé « 9al » à Alger, « gal » dans beaucoup d'autres régions"],
        ["Wah, sa7, 3andek l7a9.", "Oui, c'est vrai, tu as raison.", "« Wah » très courant dans l'Ouest"]
      ],
      quiz: [
        { t: 'qcm', q: "Dans beaucoup de régions, `9al` (il a dit) se prononce :", o: ["gal", "kal", "hal"], a: 0 },
        { t: 'qcm', q: "Dans l'Est, `nti` est souvent utilisé :", o: ["pour un homme comme pour une femme", "seulement pour les enfants", "pour « nous »"], a: 0 },
        { t: 'qcm', q: "Le tamazight (kabyle, chaoui…) est :", o: ["une langue différente de la darija", "un accent de la darija", "de l'arabe standard"], a: 0 }
      ]
    },
    {
      id: 's4-l7', dz: "F ra2yi…", t: "Les conversations complexes", min: 15,
      goal: "Donner son avis, nuancer, être d'accord ou non, argumenter.",
      blocks: [
        { k: 'table', h: ["Fonction", "Darija"], r: [
          ["donner son avis", "`f ra2yi…` (à mon avis), `ana n9oul…` (moi je dis…)"],
          ["être d'accord", "`mouwafe9`, `3andek l7a9`, `sa7`"],
          ["ne pas être d'accord", "`machi mouwafe9`, `machi sa7`, `bel 3aks`"],
          ["nuancer", "`ih, bsa7…`, `3la 7sab`, `3omomen`, `belkhoss`"],
          ["déduire", "`ma3naha…` (ça veut dire que…)"],
          ["hypothèse", "`lokan…` (si seulement…), `ida…` (si…)"]
        ] },
        { k: 'p', x: "`Lokan` sert pour l'irréel : `lokan 3andi drahem, nechri dar` (si j'avais de l'argent, j'achèterais une maison). `Ida` sert pour le possible : `ida jit, nrou7ou m3a ba3d` (si tu viens, on ira ensemble)." },
        { k: 'note', x: "Le débat est un sport national, au café comme en famille. On hausse vite le ton… et on se réconcilie aussi vite autour d'un thé." }
      ],
      words: ["ra2y", "mouwafe9", "3andek l7a9", "bel 3aks", "3la 7sab", "3omomen", "belkhoss", "ma3naha", "lokan", "fikra", "7all", "na9ach", "7a9i9a", "moustaqbal"],
      phrases: [
        ["F ra2yi, 3andek l7a9, bsa7 machi f kolch.", "À mon avis, tu as raison, mais pas sur tout.", "Nuancer"],
        ["Bel 3aks, ana nchouf bli hadi fikra mli7a.", "Au contraire, je trouve que c'est une bonne idée.", "Contredire"],
        ["Lokan kount f blastek, ma n9oulch hakda.", "Si j'étais à ta place, je ne dirais pas ça.", "Hypothèse"],
        ["Ma3naha lazem nlgaw 7all ga3.", "Ça veut dire qu'on doit tous trouver une solution.", "Déduire"]
      ],
      quiz: [
        { t: 'qcm', q: "`Bel 3aks` =", o: ["au contraire", "en général", "surtout"], a: 0 },
        { t: 'qcm', q: "Pour une hypothèse irréelle (« si j'avais… »), on utilise :", o: ["lokan", "ida", "ki"], a: 0 },
        { t: 'type', q: "Traduis : « À mon avis »", a: ["f ra2yi", "fi ra2yi", "f rayi"] },
        { t: 'order', fr: "Au contraire, c'est une bonne idée.", a: "Bel 3aks hadi fikra mli7a" }
      ]
    },
    {
      id: 's4-l8', dz: "Ma cha2a allah, tbarkallah", t: "Les nuances culturelles", min: 15,
      goal: "Comprendre les codes de politesse et les formules liées à la vie sociale.",
      blocks: [
        { k: 'p', x: "La religion est très présente dans la langue de tous les jours, chez les pratiquants comme chez les autres : `inchallah` (si Dieu le veut), `l7amdoullah` (Dieu merci), `bismillah` (au nom de Dieu), `ma cha2a allah` et `tbarkallah` (pour admirer sans attirer le mauvais œil)." },
        { k: 'table', h: ["Situation", "Formule"], r: [
          ["Naissance, mariage, réussite", "`mabrouk` → réponse `allah ybarek fik`"],
          ["Quelqu'un est malade", "`allah ychafik`"],
          ["Retour de voyage, guérison", "`3la slamtek` → `allah yselmek`"],
          ["Décès", "`allah yr7mou` (paix à son âme), `lbaraka f rassek` (condoléances)"],
          ["Achat ou vêtement neuf", "`bsa7tek`"],
          ["Ramadan", "`sa7a ftourek`, `sa7a 3idek` (pour l'Aïd)"],
          ["Compliment", "`tbarkallah 3lik`, `ma cha2a allah`"]
        ] },
        { k: 'p', x: "Respect des aînés : on les appelle `3ammi`, `khalti`, `l7aj`, `l7ajja`, on les sert en premier et on ne fume pas devant eux dans beaucoup de familles. Certaines personnes utilisent le pluriel (`ntouma`, `wach rakoum?`) pour marquer le respect envers une seule personne âgée (usage variable)." },
        { k: 'note', x: "Hospitalité : l'invité est roi. On vous resservira plusieurs fois ; pour arrêter, dites clairement `chba3t, ya3tik sa7a` (je suis rassasié, merci), parfois deux ou trois fois." },
        { k: 'note', x: "Le mélange darija-français (et parfois tamazight) n'est pas « mal parler » : c'est une façon normale de parler, surtout en ville et dans les milieux étudiants et professionnels." }
      ],
      words: ["mabrouk", "allah ybarek fik", "allah ychafik", "3la slamtek", "allah yselmek", "allah yr7mou", "lbaraka f rassek", "bsa7tek", "sa7a ftourek", "sa7a 3idek", "tbarkallah 3lik", "ma cha2a allah", "l3in", "3ib", "7echma", "3ammi", "khalti", "chba3t"],
      phrases: [
        ["Mabrouk 3likoum, allah ybarek fih.", "Félicitations, que Dieu bénisse l'enfant.", "Naissance"],
        ["Lbaraka f rassek, allah yr7mou.", "Mes condoléances, que Dieu ait son âme.", "Condoléances"],
        ["Chba3t, ya3tik sa7a, wallah ma n9der.", "Je suis rassasié, merci, je te jure que je ne peux plus.", "Refuser d'être resservi"],
        ["Ma cha2a allah, weldek kber!", "Magnifique, ton fils a grandi !", "Compliment"]
      ],
      quiz: [
        { t: 'qcm', q: "Que dit-on pour présenter ses condoléances ?", o: ["lbaraka f rassek", "bsa7tek", "mabrouk"], a: 0 },
        { t: 'qcm', q: "On ajoute `tbarkallah` à un compliment pour :", o: ["écarter le mauvais œil", "se moquer", "demander un service"], a: 0 },
        { t: 'qcm', q: "Réponse à `3la slamtek` :", o: ["allah yselmek", "allah ybarek fik", "3likoum salam"], a: 0 },
        { t: 'type', q: "Traduis : « Félicitations »", a: ["mabrouk", "mabrok"] }
      ]
    }
  ]
});
