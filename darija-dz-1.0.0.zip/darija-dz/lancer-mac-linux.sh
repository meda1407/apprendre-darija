#!/bin/sh
# Darija DZ — lance l'application en local (http://localhost:8080) pour pouvoir l'installer.
# Nécessite Python 3. Fermez cette fenêtre (ou Ctrl+C) pour arrêter le serveur local.
cd "$(dirname "$0")" || exit 1
PORT=8080
URL="http://localhost:$PORT/index.html"
echo "Darija DZ : ouverture de $URL"
( sleep 1; (open "$URL" 2>/dev/null || xdg-open "$URL" 2>/dev/null || echo "Ouvrez $URL dans votre navigateur.") ) &
if command -v python3 >/dev/null 2>&1; then python3 -m http.server "$PORT" --bind 127.0.0.1
else python -m http.server "$PORT" --bind 127.0.0.1; fi
