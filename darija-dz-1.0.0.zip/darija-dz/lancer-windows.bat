@echo off
REM Darija DZ - lance l application en local (http://localhost:8080) pour pouvoir l installer.
REM Necessite Python 3. Fermez la fenetre du serveur pour l arreter.
cd /d "%~dp0"
set PY=python
where py >nul 2>nul && set PY=py
start "Darija DZ - serveur local" %PY% -m http.server 8080 --bind 127.0.0.1
timeout /t 2 >nul
start "" http://localhost:8080/index.html
