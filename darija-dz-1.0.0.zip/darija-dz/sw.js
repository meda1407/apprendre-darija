/* Darija DZ — service worker : met toute l'application en cache pour un fonctionnement 100 % hors ligne.
   Stratégie : « cache d'abord ». Aucune requête vers l'extérieur. */
'use strict';
var CACHE = 'darija-dz-v1.0.0';
var ASSETS = [
  './',
  './index.html',
  './manifest.webmanifest',
  './css/app.css',
  './fonts/lora-var.woff',
  './fonts/lora-italic-var.woff',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/icon-maskable-512.png',
  './icons/apple-touch-icon.png',
  './icons/favicon-32.png',
  './js/registry.js',
  './js/text.js',
  './js/store.js',
  './js/core.js',
  './js/audio.js',
  './js/ui.js',
  './js/exercises.js',
  './js/app.js',
  './data/dict-1.js',
  './data/dict-2.js',
  './data/dict-3.js',
  './data/lessons-1.js',
  './data/lessons-2.js',
  './data/lessons-3.js',
  './data/lessons-4.js',
  './data/grammar.js',
  './data/dialogues.js'
];

self.addEventListener('install', function (event) {
  event.waitUntil(
    caches.open(CACHE).then(function (cache) {
      return cache.addAll(ASSETS.map(function (u) { return new Request(u, { cache: 'reload' }); }));
    }).then(function () { return self.skipWaiting(); })
  );
});

self.addEventListener('activate', function (event) {
  event.waitUntil(
    caches.keys().then(function (keys) {
      return Promise.all(keys.filter(function (k) { return k.indexOf('darija-dz-') === 0 && k !== CACHE; }).map(function (k) { return caches.delete(k); }));
    }).then(function () { return self.clients.claim(); })
  );
});

self.addEventListener('fetch', function (event) {
  var req = event.request;
  if (req.method !== 'GET') return;
  var url = new URL(req.url);
  if (url.origin !== self.location.origin) return; // jamais de ressource externe
  event.respondWith(
    caches.match(req, { ignoreSearch: true }).then(function (hit) {
      if (hit) return hit;
      if (req.mode === 'navigate') return caches.match('./index.html');
      return fetch(req).then(function (res) {
        if (res && res.ok && res.type === 'basic') {
          var copy = res.clone();
          caches.open(CACHE).then(function (c) { c.put(req, copy); });
        }
        return res;
      }).catch(function () { return caches.match('./index.html'); });
    })
  );
});
