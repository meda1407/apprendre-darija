/* Darija DZ — modèle : index du contenu, recherche, progression, répétition espacée, activité. */
(function () {
  'use strict';
  var DZ = window.DZ, T = DZ.text;
  var C = (DZ.core = {});
  var DAY = 86400000;

  /* ---------- Index du contenu ---------- */
  C.build = function () {
    var D = DZ.data;
    C.catById = {}; D.cats.forEach(function (c) { C.catById[c.id] = c; });
    C.catById.perso = { id: 'perso', label: 'Mes mots', level: 1 };
    C.entries = []; C.byId = {}; C.byDz = {};
    D.dict.forEach(function (e) { addEntry(e, false); });
    C.lessons = []; C.lessonById = {};
    D.stages.sort(function (a, b) { return a.n - b.n; });
    D.stages.forEach(function (s) {
      s.lessons.forEach(function (l, i) {
        l.stage = s; l.idx = i; C.lessons.push(l); C.lessonById[l.id] = l;
        l.entries = (l.words || []).map(function (w) { return C.byDz[w.toLowerCase()]; }).filter(Boolean);
        l.entries.forEach(function (e) { (e.lessons = e.lessons || []).push(l.id); });
      });
    });
    C.grammarById = {}; D.grammar.sort(function (a, b) { return a.n - b.n; });
    D.grammar.forEach(function (g) { C.grammarById[g.id] = g; });
    C.dialogueById = {}; D.dialogues.forEach(function (d) { C.dialogueById[d.id] = d; });
    C.refreshCustom();
  };

  function addEntry(e, custom) {
    if (!e.id) e.id = e.cat + '/' + T.slug(e.d);
    e.custom = !!custom;
    e.nd = T.normDz(e.d);
    e.sk = T.skelDz(e.d);
    e.nv = (e.v || []).map(T.normDz);
    e.sv = (e.v || []).map(T.skelDz);
    e.nf = T.normFr(e.fr);
    e.nx = T.normDz(e.exd) + ' ' + T.normFr(e.exf);
    C.entries.push(e); C.byId[e.id] = e;
    var k = e.d.toLowerCase(); if (!C.byDz[k]) C.byDz[k] = e;
  }

  // Mots personnels de l'utilisateur
  C.refreshCustom = function () {
    C.entries = C.entries.filter(function (e) { if (e.custom) { delete C.byId[e.id]; return false; } return true; });
    ((DZ.state && DZ.state.custom) || []).forEach(function (c) {
      addEntry({ id: c.id, cat: c.cat || 'perso', d: c.d, ar: c.ar || '', fr: c.fr, exd: c.exd || '', exf: c.exf || '', v: c.v || [], p: c.p || '', n: c.n || '', u: false, r: '', l: 1 }, true);
    });
  };

  /* ---------- Recherche tolérante ---------- */
  C.search = function (q, opts) {
    opts = opts || {};
    var list = opts.list || C.entries;
    q = String(q || '').trim();
    if (!q) return list.slice();
    var nd = T.normDz(q), sk = T.skelDz(q), nf = T.normFr(q);
    var scored = [];
    list.forEach(function (e) {
      var s = 0;
      if (e.nd === nd) s = 100;
      else if (e.nv.indexOf(nd) >= 0) s = 90;
      else if (nd && e.nd.indexOf(nd) === 0) s = 80;
      else if (nd && e.nv.some(function (v) { return v.indexOf(nd) === 0; })) s = 70;
      else if (nf && (e.nf === nf || (' ' + e.nf + ' ').indexOf(' ' + nf + ' ') >= 0)) s = 65;
      else if (nd.length >= 2 && e.nd.indexOf(nd) >= 0) s = 60;
      else if (nd.length >= 3 && e.nv.some(function (v) { return v.indexOf(nd) >= 0; })) s = 55;
      else if (nf.length >= 3 && e.nf.indexOf(nf) >= 0) s = 50;
      else if (sk.length >= 3 && (e.sk === sk || e.sv.indexOf(sk) >= 0)) s = 45;
      else if (sk.length >= 3 && e.sk.indexOf(sk) === 0) s = 35;
      else if (sk.length >= 4 && (e.sk.indexOf(sk) >= 0 || e.sv.some(function (v) { return v.indexOf(sk) >= 0; }))) s = 30;
      else if (nd.length >= 3 && e.nx.indexOf(nd) >= 0) s = 20;
      else if (nf.length >= 4 && e.nx.indexOf(nf) >= 0) s = 15;
      if (s) scored.push({ e: e, s: s - Math.min(e.d.length, 30) / 100 });
    });
    scored.sort(function (a, b) { return b.s - a.s; });
    return scored.map(function (x) { return x.e; });
  };

  /* ---------- Activité, XP, série ---------- */
  C.today = function (d) {
    d = d ? new Date(d) : new Date();
    var m = d.getMonth() + 1, j = d.getDate();
    return d.getFullYear() + '-' + (m < 10 ? '0' : '') + m + '-' + (j < 10 ? '0' : '') + j;
  };
  C.act = function () {
    var st = DZ.state, k = C.today();
    if (!st.activity[k]) st.activity[k] = { xp: 0, ok: 0, ko: 0, rev: 0, newc: 0 };
    return st.activity[k];
  };
  C.addXp = function (n) {
    if (!n) return;
    C.act().xp += n; DZ.state.stats.xp += n; DZ.store.save();
  };
  C.recordAnswer = function (ok) {
    var a = C.act(); if (ok) a.ok++; else a.ko++;
    DZ.state.stats.answers++; if (ok) DZ.state.stats.correct++;
    if (ok) C.addXp(2); else DZ.store.save();
  };
  C.streak = function () {
    var act = DZ.state.activity, n = 0, d = new Date();
    if (!act[C.today(d)]) d = new Date(d.getTime() - DAY); // la série continue si on n'a pas encore joué aujourd'hui
    while (act[C.today(d)] && (act[C.today(d)].xp > 0 || act[C.today(d)].rev > 0)) { n++; d = new Date(d.getTime() - DAY); }
    return n;
  };
  C.daysUsed = function () {
    return Object.keys(DZ.state.activity).filter(function (k) { var a = DZ.state.activity[k]; return a.xp > 0 || a.rev > 0 || a.open; }).length;
  };
  C.markOpen = function () { C.act().open = true; DZ.store.save(); };

  C.xpLevel = function () {
    var xp = DZ.state.stats.xp;
    var lvl = Math.floor(Math.sqrt(xp / 25)) + 1;
    var cur = Math.pow(lvl - 1, 2) * 25, next = Math.pow(lvl, 2) * 25;
    return { lvl: lvl, xp: xp, cur: cur, next: next, pct: Math.round((xp - cur) / (next - cur) * 100) };
  };

  /* ---------- Progression des cours ---------- */
  C.lessonDone = function (id) { var l = DZ.state.lessons[id]; return !!(l && l.done); };
  C.stageProgress = function (s) {
    var done = s.lessons.filter(function (l) { return C.lessonDone(l.id); }).length;
    return { done: done, total: s.lessons.length, pct: Math.round(done / s.lessons.length * 100) };
  };
  C.currentStage = function () {
    var st = DZ.data.stages;
    for (var i = 0; i < st.length; i++) if (C.stageProgress(st[i]).pct < 80) return st[i];
    return st[st.length - 1];
  };
  C.nextLesson = function () {
    for (var i = 0; i < C.lessons.length; i++) if (!C.lessonDone(C.lessons[i].id)) return C.lessons[i];
    return null;
  };
  C.setLessonDone = function (id, done, score) {
    var st = DZ.state, rec = st.lessons[id] || (st.lessons[id] = {});
    var was = !!rec.done;
    if (score != null) rec.best = Math.max(rec.best || 0, score);
    if (done) {
      rec.done = rec.done || Date.now();
      var l = C.lessonById[id];
      if (l) l.entries.forEach(function (e) { C.srsAdd(e.id); });
      if (!was) C.addXp(10);
    } else { delete rec.done; }
    DZ.store.save();
  };

  /* ---------- Répétition espacée (inspirée de SM-2) ---------- */
  C.srsAdd = function (id) {
    var s = DZ.state.srs;
    if (!s[id] && C.byId[id]) s[id] = { e: 2.5, i: 0, d: Date.now(), r: 0, l: 0, s: 0, nw: 1 };
    DZ.store.save();
    return s[id];
  };
  C.srsRemove = function (id) { delete DZ.state.srs[id]; DZ.store.save(); };
  C.srsDue = function (now) {
    now = now || Date.now();
    var s = DZ.state.srs;
    return Object.keys(s).filter(function (id) { return C.byId[id] && s[id].d <= now; })
      .sort(function (a, b) { return s[a].d - s[b].d; });
  };
  C.srsDueSoon = function (days) {
    var s = DZ.state.srs, out = [], now = Date.now();
    for (var k = 0; k < days; k++) out.push(0);
    Object.keys(s).forEach(function (id) {
      if (!C.byId[id]) return;
      var idx = Math.floor((s[id].d - now) / DAY);
      if (idx < 0) idx = 0;
      if (idx < days) out[idx]++;
    });
    return out;
  };
  // Prévisualise le prochain intervalle (en jours) pour une note donnée
  C.srsPreview = function (card, g) {
    var c = JSON.parse(JSON.stringify(card || { e: 2.5, i: 0, r: 0, l: 0 }));
    return grade(c, g).i;
  };
  function grade(c, g) {
    // g : 0 = à revoir, 1 = difficile, 2 = bien, 3 = facile
    if (g === 0) { c.l++; c.r = 0; c.i = 0; c.e = Math.max(1.3, c.e - 0.2); }
    else if (g === 1) { c.i = c.r === 0 ? 1 : Math.max(1, Math.round(c.i * 1.2)); c.e = Math.max(1.3, c.e - 0.15); c.r++; }
    else if (g === 2) { c.i = c.r === 0 ? 1 : c.r === 1 ? 3 : Math.max(c.i + 1, Math.round(c.i * c.e)); c.r++; }
    else { c.i = c.r === 0 ? 3 : Math.max(c.i + 2, Math.round(c.i * c.e * 1.3)); c.e = c.e + 0.15; c.r++; }
    return c;
  }
  C.srsGrade = function (id, g) {
    var c = DZ.state.srs[id] || C.srsAdd(id);
    if (!c) return;
    var wasNew = c.nw;
    grade(c, g);
    var now = Date.now();
    c.d = g === 0 ? now + 10 * 60000 : now + c.i * DAY - 3600000; // « à revoir » revient dans ~10 min
    c.s = now; delete c.nw;
    var a = C.act(); a.rev++; if (wasNew) a.newc++;
    DZ.state.stats.reviews++;
    C.addXp(1);
    if (g === 0) C.addMistakeWord(id); else if (g >= 2) C.clearMistake('w:' + id);
    DZ.store.save();
  };
  // Après une erreur en exercice : la carte revient vite en révision
  C.srsLapse = function (id) {
    var c = DZ.state.srs[id] || C.srsAdd(id);
    if (!c) return;
    c.d = Math.min(c.d, Date.now()); c.e = Math.max(1.3, c.e - 0.1);
    DZ.store.save();
  };
  C.wordStatus = function (id) {
    var c = DZ.state.srs[id];
    if (!c) return 'none';
    if (c.i >= 21) return 'mastered';
    if (c.i >= 4) return 'learned';
    return 'learning';
  };
  C.counts = function () {
    var s = DZ.state.srs, out = { total: 0, learning: 0, learned: 0, mastered: 0 };
    Object.keys(s).forEach(function (id) {
      if (!C.byId[id]) return; out.total++; out[C.wordStatus(id)]++;
    });
    out.known = out.learned + out.mastered;
    return out;
  };
  // Nouvelles cartes proposées : mots des leçons terminées, puis mots des leçons dans l'ordre
  C.newCandidates = function (max) {
    var s = DZ.state.srs, out = [], seen = {};
    function push(e) { if (out.length < max && !s[e.id] && !seen[e.id]) { seen[e.id] = 1; out.push(e.id); } }
    C.lessons.forEach(function (l) { if (C.lessonDone(l.id)) l.entries.forEach(push); });
    C.lessons.forEach(function (l) { l.entries.forEach(push); });
    return out;
  };
  C.isHard = function (id) {
    var c = DZ.state.srs[id];
    return !!DZ.state.hard[id] || !!(c && (c.l >= 2 || c.e < 2));
  };
  C.hardList = function () {
    var out = {};
    Object.keys(DZ.state.hard).forEach(function (id) { if (C.byId[id]) out[id] = 1; });
    Object.keys(DZ.state.srs).forEach(function (id) { if (C.byId[id] && C.isHard(id)) out[id] = 1; });
    return Object.keys(out).map(function (id) { return C.byId[id]; });
  };

  /* ---------- Favoris, historique, erreurs ---------- */
  C.toggleFav = function (id) {
    var f = DZ.state.favs; if (f[id]) delete f[id]; else f[id] = Date.now(); DZ.store.save(); return !!f[id];
  };
  C.toggleHard = function (id) {
    var h = DZ.state.hard; if (h[id]) delete h[id]; else { h[id] = Date.now(); C.srsAdd(id); } DZ.store.save(); return !!h[id];
  };
  C.pushHistory = function (id) {
    var h = DZ.state.history.filter(function (x) { return x !== id; });
    h.unshift(id); DZ.state.history = h.slice(0, 120); DZ.store.save();
  };
  C.addMistakeWord = function (id) {
    var k = 'w:' + id, m = DZ.state.mistakes[k] || (DZ.state.mistakes[k] = { key: k, kind: 'word', ref: id, n: 0 });
    m.n++; m.last = Date.now(); DZ.store.save();
  };
  C.addMistakeItem = function (key, item, given) {
    var m = DZ.state.mistakes[key] || (DZ.state.mistakes[key] = { key: key, kind: 'item', item: item, n: 0 });
    m.item = item; m.given = given; m.n++; m.last = Date.now(); DZ.store.save();
  };
  C.clearMistake = function (key) {
    var m = DZ.state.mistakes[key];
    if (!m) return;
    m.n--; if (m.n <= 0) delete DZ.state.mistakes[key];
    DZ.store.save();
  };
  C.mistakeList = function () {
    var m = DZ.state.mistakes;
    return Object.keys(m).map(function (k) { return m[k]; })
      .filter(function (x) { return x.kind !== 'word' || C.byId[x.ref]; })
      .sort(function (a, b) { return b.last - a.last; });
  };

  /* ---------- Expression du jour ---------- */
  C.expressionOfDay = function () {
    var pool = C.entries.filter(function (e) {
      return !e.custom && ['expressions', 'proverbes', 'argot', 'salutations'].indexOf(e.cat) >= 0 && e.exd;
    });
    var d = new Date(), seed = d.getFullYear() * 400 + d.getMonth() * 32 + d.getDate();
    // Mélange déterministe pour éviter que les jours consécutifs tombent sur la même catégorie
    var idx = (seed * 7919) % pool.length;
    return pool[idx];
  };

  /* ---------- Recherche globale ---------- */
  C.searchAll = function (q) {
    var nq = T.normFr(q), nd = T.normDz(q), res = { dict: [], lessons: [], grammar: [], dialogues: [], notes: [] };
    if (!q.trim()) return res;
    res.dict = C.search(q).slice(0, 12);
    function hay(obj) { return (T.normFr(obj) + ' ' + T.normDz(obj)); }
    function match(text) { var h = hay(text); return (nq.length >= 2 && h.indexOf(nq) >= 0) || (nd.length >= 2 && h.indexOf(nd) >= 0); }
    C.lessons.forEach(function (l) {
      var text = [l.t, l.dz, l.goal].concat((l.blocks || []).map(function (b) { return typeof b.x === 'string' ? b.x : ''; }))
        .concat((l.phrases || []).map(function (p) { return p[0] + ' ' + p[1]; })).join(' ');
      if (match(text)) res.lessons.push(l);
    });
    DZ.data.grammar.forEach(function (g) {
      var text = [g.t, g.dz].concat(g.blocks.map(function (b) { return typeof b.x === 'string' ? b.x : ''; }))
        .concat((g.ex || []).map(function (p) { return p[0] + ' ' + p[1]; })).join(' ');
      if (match(text)) res.grammar.push(g);
    });
    DZ.data.dialogues.forEach(function (d) {
      var text = [d.t, d.dz, d.ctx].concat(d.lines.map(function (l) { return l[1] + ' ' + l[3]; })).join(' ');
      if (match(text)) res.dialogues.push(d);
    });
    DZ.state.notes.forEach(function (n) { if (match(n.title + ' ' + n.text)) res.notes.push(n); });
    return res;
  };
})();
