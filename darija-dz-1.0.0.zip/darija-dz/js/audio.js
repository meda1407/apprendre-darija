/* Darija DZ — audio 100 % local.
   L'application n'embarque aucun enregistrement : vous pouvez enregistrer votre voix (ou celle d'un
   locuteur natif) ou importer vos propres fichiers. Tout est stocké dans IndexedDB, sur l'appareil.
   Une voix de synthèse arabe peut être activée à titre expérimental : elle lit l'écriture arabe avec
   une prononciation d'arabe standard, PAS de la darija algérienne. */
(function () {
  'use strict';
  var DZ = window.DZ, T = DZ.text, S = DZ.store;
  var A = (DZ.audio = {});
  var cache = {};         // clé → true/false (enregistrement présent ?)
  var current = null;     // élément audio en cours de lecture

  A.init = function () {
    return S.audioKeys().then(function (keys) { cache = {}; (keys || []).forEach(function (k) { cache[k] = true; }); });
  };
  A.has = function (dz) { return !!cache[T.audioKey(dz)]; };
  A.count = function () { return Object.keys(cache).filter(function (k) { return cache[k]; }).length; };

  A.stop = function () {
    if (current) { try { current.pause(); } catch (e) { /* ignoré */ } current = null; }
    try { if (window.speechSynthesis) speechSynthesis.cancel(); } catch (e) { /* ignoré */ }
  };

  A.play = function (dz, rate) {
    var key = T.audioKey(dz);
    A.stop();
    return S.audioGet(key).then(function (rec) {
      if (!rec || !rec.blob) return false;
      return new Promise(function (resolve) {
        var url = URL.createObjectURL(rec.blob);
        var el = new Audio(url);
        el.playbackRate = rate || DZ.state.settings.audioRate || 1;
        try { el.preservesPitch = true; el.mozPreservesPitch = true; el.webkitPreservesPitch = true; } catch (e) { /* ignoré */ }
        current = el;
        el.onended = el.onerror = function () { URL.revokeObjectURL(url); if (current === el) current = null; resolve(true); };
        el.play().catch(function () { resolve(false); });
      });
    });
  };

  /* ---------- Enregistrement au micro ---------- */
  A.canRecord = function () {
    return !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia && window.MediaRecorder);
  };
  var rec = null;
  A.isRecording = function () { return !!rec; };
  A.startRecording = function (dz, onStop) {
    if (!A.canRecord()) return Promise.reject(new Error("Ce navigateur ne permet pas d'enregistrer le son."));
    A.stop();
    return navigator.mediaDevices.getUserMedia({ audio: true }).then(function (stream) {
      var chunks = [], mr;
      var types = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4', 'audio/ogg'];
      var type = types.filter(function (t) { return MediaRecorder.isTypeSupported && MediaRecorder.isTypeSupported(t); })[0];
      mr = type ? new MediaRecorder(stream, { mimeType: type }) : new MediaRecorder(stream);
      mr.ondataavailable = function (e) { if (e.data && e.data.size) chunks.push(e.data); };
      mr.onstop = function () {
        stream.getTracks().forEach(function (t) { t.stop(); });
        var blob = new Blob(chunks, { type: mr.mimeType || type || 'audio/webm' });
        var key = T.audioKey(dz);
        rec = null;
        if (!blob.size) { if (onStop) onStop(false); return; }
        S.audioPut(key, blob).then(function () { cache[key] = true; if (onStop) onStop(true); });
      };
      mr.start();
      rec = { mr: mr, timer: setTimeout(function () { A.stopRecording(); }, 20000) };
      return true;
    });
  };
  A.stopRecording = function () {
    if (!rec) return;
    clearTimeout(rec.timer);
    try { rec.mr.stop(); } catch (e) { rec = null; }
  };

  A.importFile = function (dz, file) {
    if (!file || !/^audio\//.test(file.type || 'audio/')) return Promise.reject(new Error('Choisissez un fichier audio (mp3, m4a, ogg, wav…).'));
    var key = T.audioKey(dz);
    return S.audioPut(key, file).then(function () { cache[key] = true; return true; });
  };
  A.remove = function (dz) {
    var key = T.audioKey(dz);
    return S.audioDelete(key).then(function () { delete cache[key]; });
  };
  A.clearCache = function () { cache = {}; };

  /* ---------- Synthèse vocale expérimentale (désactivée par défaut) ---------- */
  A.ttsVoice = function () {
    try {
      if (!window.speechSynthesis) return null;
      var vs = speechSynthesis.getVoices() || [];
      return vs.filter(function (v) { return /^ar(-DZ)?$/i.test(v.lang) || /^ar-DZ/i.test(v.lang); })[0]
        || vs.filter(function (v) { return /^ar/i.test(v.lang) && v.localService; })[0]
        || vs.filter(function (v) { return /^ar/i.test(v.lang); })[0] || null;
    } catch (e) { return null; }
  };
  A.ttsAvailable = function () { return !!(DZ.state.settings.tts && A.ttsVoice()); };
  A.speak = function (ar) {
    var v = A.ttsVoice();
    if (!v || !ar) return false;
    A.stop();
    var u = new SpeechSynthesisUtterance(ar);
    u.voice = v; u.lang = v.lang; u.rate = Math.max(0.5, Math.min(1.5, DZ.state.settings.audioRate || 1)) * 0.9;
    speechSynthesis.speak(u);
    return true;
  };
  try { if (window.speechSynthesis) speechSynthesis.onvoiceschanged = function () { /* charge la liste des voix */ }; } catch (e) { /* ignoré */ }
})();
