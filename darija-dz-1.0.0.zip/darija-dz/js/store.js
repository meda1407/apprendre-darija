/* Darija DZ — stockage local (IndexedDB, avec repli sur localStorage puis mémoire).
   Aucune donnée ne quitte l'appareil. */
(function () {
  'use strict';
  var DZ = window.DZ;
  var S = (DZ.store = {});
  var DB_NAME = 'darija-dz', DB_VER = 1, LS_KEY = 'darija-dz-state';
  var db = null;
  S.mode = 'memory'; // 'idb' | 'local' | 'memory'

  S.defaultState = function () {
    return {
      v: 1,
      created: Date.now(),
      settings: {
        theme: 'system', showArabic: false, hideFr: false, highlight: true,
        dailyGoal: 30, newPerDay: 10, audioRate: 1, tts: false, examSize: 20, sessionMin: 10
      },
      lessons: {}, grammar: {}, dialogues: {},
      srs: {}, favs: {}, hard: {}, history: [],
      mistakes: {}, custom: [], notes: [], lessonNotes: {},
      activity: {}, exams: [],
      stats: { answers: 0, correct: 0, xp: 0, reviews: 0 }
    };
  };

  // Complète un état chargé avec les champs manquants (mises à jour de l'application)
  S.upgrade = function (st) {
    var d = S.defaultState();
    if (!st || typeof st !== 'object') return d;
    Object.keys(d).forEach(function (k) {
      if (st[k] === undefined || st[k] === null) st[k] = d[k];
    });
    Object.keys(d.settings).forEach(function (k) { if (st.settings[k] === undefined) st.settings[k] = d.settings[k]; });
    Object.keys(d.stats).forEach(function (k) { if (st.stats[k] === undefined) st.stats[k] = d.stats[k]; });
    return st;
  };

  function openDb() {
    return new Promise(function (resolve, reject) {
      try {
        if (!window.indexedDB) return reject(new Error('IndexedDB indisponible'));
        var req = indexedDB.open(DB_NAME, DB_VER);
        req.onupgradeneeded = function () {
          var d = req.result;
          if (!d.objectStoreNames.contains('kv')) d.createObjectStore('kv');
          if (!d.objectStoreNames.contains('audio')) d.createObjectStore('audio');
        };
        req.onsuccess = function () { resolve(req.result); };
        req.onerror = function () { reject(req.error); };
        req.onblocked = function () { reject(new Error('IndexedDB bloquée')); };
      } catch (e) { reject(e); }
    });
  }

  function tx(store, mode, fn) {
    return new Promise(function (resolve, reject) {
      try {
        var t = db.transaction(store, mode);
        var os = t.objectStore(store);
        var res = fn(os);
        t.oncomplete = function () { resolve(res && res.result !== undefined ? res.result : res); };
        t.onerror = function () { reject(t.error); };
        t.onabort = function () { reject(t.error); };
      } catch (e) { reject(e); }
    });
  }

  S.load = function () {
    return openDb().then(function (d) {
      db = d; S.mode = 'idb';
      return tx('kv', 'readonly', function (os) { return os.get('state'); });
    }).then(function (st) {
      if (!st) {
        // Migration éventuelle depuis localStorage
        try { var raw = localStorage.getItem(LS_KEY); if (raw) st = JSON.parse(raw); } catch (e) { /* ignoré */ }
      }
      return S.upgrade(st);
    }).catch(function () {
      db = null;
      try {
        var raw = localStorage.getItem(LS_KEY);
        localStorage.setItem(LS_KEY + '-test', '1'); localStorage.removeItem(LS_KEY + '-test');
        S.mode = 'local';
        return S.upgrade(raw ? JSON.parse(raw) : null);
      } catch (e) {
        S.mode = 'memory';
        return S.defaultState();
      }
    });
  };

  var saveTimer = null, saving = Promise.resolve();
  S.saveNow = function () {
    clearTimeout(saveTimer); saveTimer = null;
    var st = DZ.state;
    if (S.mode === 'idb' && db) {
      saving = tx('kv', 'readwrite', function (os) { return os.put(JSON.parse(JSON.stringify(st)), 'state'); })
        .catch(function (e) { console.warn('Sauvegarde IndexedDB impossible', e); fallbackLocal(st); });
      return saving;
    }
    fallbackLocal(st);
    return Promise.resolve();
  };
  function fallbackLocal(st) {
    if (S.mode === 'memory') return;
    try { localStorage.setItem(LS_KEY, JSON.stringify(st)); } catch (e) { console.warn('Sauvegarde locale impossible', e); }
  }
  S.save = function () {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(S.saveNow, 250);
  };

  // Demande au navigateur de ne pas effacer les données (si supporté)
  S.persist = function () {
    try {
      if (navigator.storage && navigator.storage.persist) {
        return navigator.storage.persisted().then(function (p) { return p || navigator.storage.persist(); }).catch(function () { return false; });
      }
    } catch (e) { /* ignoré */ }
    return Promise.resolve(false);
  };
  S.estimate = function () {
    try { if (navigator.storage && navigator.storage.estimate) return navigator.storage.estimate(); } catch (e) { /* ignoré */ }
    return Promise.resolve(null);
  };

  /* ---------- Enregistrements audio (Blob) ---------- */
  var memAudio = {};
  S.audioGet = function (key) {
    if (S.mode === 'idb' && db) return tx('audio', 'readonly', function (os) { return os.get(key); }).catch(function () { return null; });
    return Promise.resolve(memAudio[key] || null);
  };
  S.audioPut = function (key, blob) {
    var rec = { blob: blob, type: blob.type || 'audio/webm', ts: Date.now() };
    if (S.mode === 'idb' && db) return tx('audio', 'readwrite', function (os) { return os.put(rec, key); });
    memAudio[key] = rec; return Promise.resolve();
  };
  S.audioDelete = function (key) {
    if (S.mode === 'idb' && db) return tx('audio', 'readwrite', function (os) { return os.delete(key); });
    delete memAudio[key]; return Promise.resolve();
  };
  S.audioKeys = function () {
    if (S.mode === 'idb' && db) return tx('audio', 'readonly', function (os) { return os.getAllKeys(); }).catch(function () { return []; });
    return Promise.resolve(Object.keys(memAudio));
  };
  S.audioClear = function () {
    if (S.mode === 'idb' && db) return tx('audio', 'readwrite', function (os) { return os.clear(); });
    memAudio = {}; return Promise.resolve();
  };

  function blobToDataUrl(blob) {
    return new Promise(function (resolve, reject) {
      var r = new FileReader();
      r.onload = function () { resolve(r.result); };
      r.onerror = function () { reject(r.error); };
      r.readAsDataURL(blob);
    });
  }
  function dataUrlToBlob(url) {
    var m = /^data:([^,]*?)(;base64)?,([\s\S]*)$/.exec(url);
    if (!m) return null;
    var bin = m[2] ? atob(m[3]) : decodeURIComponent(m[3]);
    var arr = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    return new Blob([arr], { type: m[1] || 'audio/webm' });
  }

  /* ---------- Export / import ---------- */
  S.exportData = function (withAudio) {
    var out = {
      app: 'Darija DZ', format: 1, exported: new Date().toISOString(),
      state: JSON.parse(JSON.stringify(DZ.state)), audio: []
    };
    if (!withAudio) return Promise.resolve(out);
    return S.audioKeys().then(function (keys) {
      return keys.reduce(function (p, k) {
        return p.then(function () {
          return S.audioGet(k).then(function (rec) {
            if (!rec || !rec.blob) return;
            return blobToDataUrl(rec.blob).then(function (url) { out.audio.push({ key: k, type: rec.type, data: url }); });
          });
        });
      }, Promise.resolve());
    }).then(function () { return out; });
  };

  S.validateBackup = function (obj) {
    if (!obj || typeof obj !== 'object') return 'Le fichier ne contient pas de données lisibles.';
    if (obj.app !== 'Darija DZ' || !obj.state) return "Ce fichier n'est pas une sauvegarde Darija DZ.";
    if (typeof obj.state.settings !== 'object') return 'La sauvegarde est incomplète (réglages manquants).';
    return null;
  };

  S.importData = function (obj) {
    var err = S.validateBackup(obj);
    if (err) return Promise.reject(new Error(err));
    DZ.state = S.upgrade(obj.state);
    var p = S.saveNow();
    if (obj.audio && obj.audio.length) {
      p = p.then(function () {
        return obj.audio.reduce(function (q, a) {
          return q.then(function () { var b = dataUrlToBlob(a.data); if (b) return S.audioPut(a.key, b); });
        }, Promise.resolve());
      });
    }
    return p;
  };

  S.resetAll = function (keepAudio) {
    DZ.state = S.defaultState();
    var p = S.saveNow();
    if (!keepAudio) p = p.then(S.audioClear);
    return p;
  };
})();
