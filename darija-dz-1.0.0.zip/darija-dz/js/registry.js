/* Darija DZ — registre des contenus.
   Les fichiers de /data appellent ces fonctions. Pour enrichir ou corriger le contenu,
   il suffit de modifier les fichiers de /data (voir data/LISEZMOI.md). */
(function () {
  'use strict';
  var DZ = (window.DZ = window.DZ || {});
  DZ.data = DZ.data || {
    cats: [],        // catégories du dictionnaire
    dict: [],        // entrées du dictionnaire
    stages: [],      // étapes de cours
    grammar: [],     // fiches de grammaire
    dialogues: [],   // dialogues
    guide: null      // guide d'écriture
  };

  // Déclare une catégorie du dictionnaire
  DZ.addCategory = function (id, label, level) {
    DZ.data.cats.push({ id: id, label: label, level: level || 1 });
  };

  /* Ajoute des entrées au dictionnaire.
     Format d'une ligne : [darija, arabe, français, exempleDarija, exempleFrançais, options]
     options (facultatif) :
       v : variantes acceptées, séparées par « | »
       p : aide à la prononciation (simple, sans symboles phonétiques)
       n : note (usage, genre, pluriel, conjugaison…)
       u : 1 si la forme ou le sens est à vérifier
       r : région où le mot est surtout employé
       l : niveau (1 à 4) */
  DZ.addDict = function (cat, rows) {
    var catInfo = DZ.data.cats.filter(function (c) { return c.id === cat; })[0];
    rows.forEach(function (r) {
      var o = r[5] || {};
      DZ.data.dict.push({
        cat: cat,
        d: r[0], ar: r[1], fr: r[2], exd: r[3] || '', exf: r[4] || '',
        v: o.v ? o.v.split('|') : [],
        p: o.p || '', n: o.n || '', u: !!o.u, r: o.r || '',
        l: o.l || (catInfo ? catInfo.level : 1)
      });
    });
  };

  DZ.addStage = function (stage) { DZ.data.stages.push(stage); };
  DZ.addGrammar = function (list) { DZ.data.grammar = DZ.data.grammar.concat(list); };
  DZ.addDialogues = function (list) { DZ.data.dialogues = DZ.data.dialogues.concat(list); };
  DZ.setGuide = function (g) { DZ.data.guide = g; };
})();
