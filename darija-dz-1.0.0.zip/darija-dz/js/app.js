/* Darija DZ — application : navigation, écrans et actions. */
(function () {
  'use strict';
  var DZ = window.DZ, T = DZ.text, U = DZ.ui;
  var C, X, A;
  var App = (DZ.app = {});
  App.route = '';
  App.dict = { q: '', cat: '', filter: 'all', limit: 60 };
  App.dlgCat = '';
  App.practice = { scope: {}, n: 10 };
  var VERSION = '1.0.0';
  App.version = VERSION;

  /* ---------- Démarrage ---------- */
  App.boot = function () {
    C = DZ.core; X = DZ.ex; A = DZ.audio;
    DZ.store.load().then(function (st) {
      DZ.state = st;
      C.build();
      applyTheme();
      C.markOpen();
      return A.init().catch(function () { /* audio indisponible */ });
    }).then(function () {
      renderShell();
      window.addEventListener('hashchange', App.render);
      App.render();
      registerSW();
      try { if (window.claude && typeof window.claude.use === 'function') window.claude.use('downloads').then(function (d) { App.downloads = d || null; }, function () { /* indisponible */ }); } catch (e) { /* ignoré */ }
      document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'hidden') DZ.store.saveNow(); });
      window.addEventListener('pagehide', function () { DZ.store.saveNow(); });
      try { if (window.matchMedia('(display-mode: standalone)').matches) DZ.store.persist(); } catch (e) { /* ignoré */ }
    }).catch(function (e) {
      console.error(e);
      document.getElementById('app').innerHTML = '<div class="page" style="padding:24px"><h1>Erreur au démarrage</h1><p>' + T.esc(e && e.message) + '</p></div>';
    });
  };

  function applyTheme() {
    var t = DZ.state.settings.theme, root = document.documentElement;
    if (t === 'light' || t === 'dark') root.setAttribute('data-theme', t); else root.removeAttribute('data-theme');
    var dark = t === 'dark' || (t === 'system' && window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches);
    var m = document.querySelector('meta[name="theme-color"]'); if (m) m.setAttribute('content', dark ? '#0d1511' : '#0a6a3c');
  }
  try { matchMedia('(prefers-color-scheme: dark)').addEventListener('change', function () { if (DZ.state) applyTheme(); }); } catch (e) { /* ignoré */ }

  var NAV = [
    { href: '#/', id: 'home', label: 'Accueil', icon: 'home' },
    { href: '#/cours', id: 'cours', label: 'Cours', icon: 'book' },
    { href: '#/pratique', id: 'pratique', label: 'Pratique', icon: 'target' },
    { href: '#/dico', id: 'dico', label: 'Dico', icon: 'dict' },
    { href: '#/plus', id: 'plus', label: 'Plus', icon: 'more' }
  ];
  var SIDE = [
    { href: '#/', id: 'home', label: 'Accueil', icon: 'home' },
    { href: '#/cours', id: 'cours', label: 'Cours', icon: 'book' },
    { href: '#/grammaire', id: 'grammaire', label: 'Grammaire', icon: 'layers' },
    { href: '#/dialogues', id: 'dialogues', label: 'Dialogues', icon: 'chat' },
    { href: '#/dico', id: 'dico', label: 'Dictionnaire', icon: 'dict' },
    { href: '#/pratique', id: 'pratique', label: 'Pratique et révision', icon: 'target' },
    { href: '#/examen', id: 'examen', label: 'Mode examen', icon: 'exam' },
    { sep: 1 },
    { href: '#/progres', id: 'progres', label: 'Progression', icon: 'chart' },
    { href: '#/notes', id: 'notes', label: 'Mes notes', icon: 'note' },
    { href: '#/sauvegarde', id: 'sauvegarde', label: 'Sauvegarde', icon: 'download' },
    { href: '#/reglages', id: 'reglages', label: 'Réglages', icon: 'settings' },
    { href: '#/aide', id: 'aide', label: 'Aide et installation', icon: 'help' }
  ];
  var SIDE_MAP = { lecon: 'cours', dialogue: 'dialogues', mot: 'dico', 'ajouter-mot': 'dico', 'modifier-mot': 'dico', session: 'pratique', reviser: 'pratique', note: 'notes', plus: 'home', recherche: 'home' };
  var GROUP = { lecon: 'cours', grammaire: 'cours', dialogues: 'cours', dialogue: 'cours', mot: 'dico', 'ajouter-mot': 'dico', 'modifier-mot': 'dico', session: 'pratique', reviser: 'pratique', examen: 'pratique', progres: 'plus', notes: 'plus', note: 'plus', reglages: 'plus', aide: 'plus', sauvegarde: 'plus', recherche: 'home' };

  function renderShell() {
    document.getElementById('app').innerHTML =
      '<header class="topbar" id="topbar"></header>' +
      '<div class="layout"><nav class="sidebar" aria-label="Navigation principale">' +
      SIDE.map(function (n) { return n.sep ? '<div class="side-sep"></div>' : '<a href="' + n.href + '" data-nav="' + n.id + '">' + U.icon(n.icon) + '<span>' + n.label + '</span></a>'; }).join('') +
      '<div class="side-foot">Darija DZ ' + VERSION + ' · 100 % hors ligne<br>Vos données restent sur cet appareil.</div></nav>' +
      '<main id="view" tabindex="-1"></main></div>' +
      '<nav class="bottomnav" aria-label="Navigation">' + NAV.map(function (n) {
        return '<a href="' + n.href + '" data-nav="' + n.id + '">' + U.icon(n.icon) + '<span>' + n.label + '</span>' + (n.id === 'pratique' ? '<span class="badge-dot" id="due-dot" hidden></span>' : '') + '</a>';
      }).join('') + '</nav>';
    document.addEventListener('click', onClick);
    document.addEventListener('contextmenu', function (e) {
      var b = e.target.closest('[data-act="audio"]');
      if (b) { e.preventDefault(); audioSheet(b.getAttribute('data-dz'), b.getAttribute('data-ar')); }
    });
    document.addEventListener('change', onChange);
    document.addEventListener('keydown', function (e) {
      if ((e.key === 'Enter' || e.key === ' ') && e.target.matches && e.target.matches('[role="button"][data-act]')) { e.preventDefault(); e.target.click(); }
    });
  }

  function topbar(o) {
    var tb = document.getElementById('topbar');
    var left = o.back
      ? '<a class="icon-btn" href="' + o.back + '" aria-label="Retour">' + U.icon('left') + '</a><div class="top-title">' + T.esc(o.title || '') + '</div>'
      : '<a class="brand" href="#/" aria-label="Darija DZ, accueil"><span class="brand-mark" aria-hidden="true"></span><span class="brand-name">Darija <b>DZ</b></span></a>';
    var dark = document.documentElement.getAttribute('data-theme') === 'dark' ||
      (!document.documentElement.getAttribute('data-theme') && window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches);
    tb.innerHTML = left + '<div class="top-actions">' +
      '<a class="icon-btn" href="#/recherche" aria-label="Rechercher dans tous les cours">' + U.icon('dict') + '</a>' +
      '<button class="icon-btn" data-act="theme" aria-label="' + (dark ? 'Passer en mode clair' : 'Passer en mode sombre') + '">' + U.icon(dark ? 'sun' : 'moon') + '</button></div>';
  }

  /* ---------- Navigation ---------- */
  App.go = function (href, replace) {
    if (replace) { history.replaceState(null, '', href); App.render(); }
    else if (location.hash === href) App.render();
    else location.hash = href;
  };

  var lastPath = null;
  App.render = function () {
    if (!DZ.state) return;
    var hash = location.hash || '#/';
    var path = hash.replace(/^#\/?/, '');
    var parts = path.split('/');
    var name = parts[0] || 'home';
    var arg = parts.slice(1).map(decodeURIComponent).join('/');
    App.route = name;
    U.closeSheet(); A.stop();
    var root = document.getElementById('view');
    root.classList.toggle('hide-fr', !!DZ.state.settings.hideFr);
    var view = VIEWS[name] || VIEWS.home;
    view(root, arg);
    var group = GROUP[name] || name;
    var sideId = SIDE_MAP[name] || name;
    document.querySelectorAll('[data-nav]').forEach(function (a) {
      var id = a.getAttribute('data-nav');
      var on = a.closest('.bottomnav') ? id === group : id === sideId;
      a.classList.toggle('active', !!on);
      if (on) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
    });
    updateDueDot();
    if (lastPath !== path) { window.scrollTo(0, 0); lastPath = path; }
  };
  function updateDueDot() {
    var dot = document.getElementById('due-dot'); if (!dot) return;
    var n = C.srsDue().length;
    dot.hidden = !n; dot.textContent = n > 99 ? '99+' : n;
  }

  function toggles() {
    var s = DZ.state.settings;
    return '<div class="toolbar">' +
      '<button class="chip ' + (s.hideFr ? 'active' : '') + '" data-act="toggle-fr" aria-pressed="' + !!s.hideFr + '">' + U.icon(s.hideFr ? 'eyeoff' : 'eye') + (s.hideFr ? 'Français masqué' : 'Français visible') + '</button>' +
      '<button class="chip ' + (s.showArabic ? 'active' : '') + '" data-act="toggle-ar" aria-pressed="' + !!s.showArabic + '">' + U.icon('ar') + (s.showArabic ? 'Arabe affiché' : 'Arabe masqué') + '</button></div>';
  }

  /* ---------- Écrans ---------- */
  var VIEWS = {};

  VIEWS.home = function (root) {
    topbar({});
    var st = DZ.state, h = new Date().getHours();
    var greet = h >= 5 && h < 12 ? ['Sba7 el khir!', 'Bonjour ! Prêt pour ta séance du jour ?'] : ['Msa el khir!', 'Bonsoir ! Un petit moment de darija ?'];
    var act = C.act(), goal = st.settings.dailyGoal, pct = Math.min(100, Math.round(act.xp / goal * 100));
    var due = C.srsDue().length, streak = C.streak(), next = C.nextLesson(), ex = C.expressionOfDay();
    var mist = C.mistakeList().length, first = !Object.keys(st.lessons).length && !st.stats.answers;
    var newN = Math.max(0, Math.min(C.newCandidates(st.settings.newPerDay).length, st.settings.newPerDay - (act.newc || 0)));
    var html = '<div class="page view-enter">';
    if (DZ.store.mode !== 'idb') html += '<div class="banner" role="alert">' + U.icon('alert') + '<span>' + (DZ.store.mode === 'local' ? 'Stockage limité : vos progrès sont enregistrés dans le stockage local du navigateur. Pensez à exporter une sauvegarde.' : 'Stockage indisponible ici : vos progrès ne seront pas conservés après fermeture. Exportez une sauvegarde avant de quitter.') + '</span></div>';
    html += '<section class="hero"><div class="hero-greet">' + T.dzHtml(greet[0]) + '</div><div class="hero-sub">' + greet[1] + '</div>' +
      '<div class="hero-stats"><span class="hstat">' + U.icon('fire') + '<b class="num">' + streak + '</b> jour' + (streak > 1 ? 's' : '') + ' de suite</span>' +
      '<span class="hstat">' + U.icon('bolt') + '<b class="num">' + act.xp + '</b> / ' + goal + ' XP</span>' +
      '<span class="hstat">' + U.icon('cards') + '<b class="num">' + due + '</b> à réviser</span></div></section>';
    if (first) {
      html += '<section class="card section"><span class="eyebrow">Bienvenue</span><h2 class="section-title">Mar7ba bik ! Par où commencer ?</h2>' +
        '<p>' + T.richHtml('Commencez par le guide d\'écriture : il explique comment lire `3`, `7` et `9` dans les mots, comme dans `ma3lich` ou `n7eb`. Ensuite, suivez les leçons dans l\'ordre.') + '</p>' +
        '<div class="btn-row"><a class="btn btn-primary" href="#/lecon/s1-l0">' + U.icon('book') + 'Lire le guide d\'écriture</a><a class="btn btn-secondary" href="#/aide">' + U.icon('phone') + 'Installer l\'application</a></div></section>';
    }
    html += '<section class="card goal"><div class="ring ' + (pct >= 100 ? 'done' : '') + '" style="--p:' + pct + '" role="img" aria-label="Objectif du jour : ' + pct + ' %"><span class="num">' + pct + '%</span></div>' +
      '<div style="flex:1;min-width:0;display:flex;flex-direction:column;gap:8px"><b>' + (pct >= 100 ? 'Objectif du jour atteint. Ghaya !' : 'Objectif du jour : ' + goal + ' XP') + '</b>' +
      '<span class="small muted">' + (due ? due + ' carte(s) attendent votre révision.' : newN ? newN + ' nouveau(x) mot(s) à découvrir en révision aujourd\'hui.' : 'Aucune révision en attente. Avancez dans les cours ou entraînez-vous.') + '</span>' +
      '<div class="hstack"><span class="small muted">Réviser :</span>' + [5, 10, 15].map(function (m) { return '<button class="btn btn-soft btn-sm" data-act="review-start" data-min="' + m + '">' + m + ' min</button>'; }).join('') + '</div></div></section>';
    if (next) {
      html += '<section class="section"><div class="section-head"><h2 class="section-title">Continuer</h2><a class="small" href="#/cours">Tous les cours</a></div>' +
        lessonCard(next, true) + '</section>';
    }
    if (ex) {
      html += '<section class="card expr"><div class="hstack"><span class="chip-red">' + U.icon('star') + 'Expression du jour</span><span class="spacer"></span>' + U.audioBtn(ex.d, ex.ar, true) +
        '<button class="icon-btn sm star ' + (st.favs[ex.id] ? 'on' : '') + '" data-act="fav" data-id="' + T.esc(ex.id) + '" aria-label="Favori">' + U.icon('star') + '</button></div>' +
        '<div class="expr-dz" data-act="word" data-id="' + T.esc(ex.id) + '" role="button" tabindex="0" style="cursor:pointer;margin-top:6px">' + T.dzHtml(ex.d) + '</div>' +
        (st.settings.showArabic && ex.ar ? T.arHtml(ex.ar) : '') +
        '<div class="fr" style="font-weight:600;margin-top:4px">' + U.frSpan(ex.fr) + '</div>' +
        (ex.exd ? '<div class="expr-ex small"><span class="dz">' + T.dzHtml(ex.exd) + '</span><br>' + U.frSpan(ex.exf, 'muted') + '</div>' : '') +
        (ex.u ? '<div style="margin-top:8px"><span class="badge verify">formulation à vérifier</span></div>' : '') + '</section>';
    }
    html += '<section class="section"><h2 class="section-title">Explorer</h2><div class="grid">' +
      tile('#/dialogues', 'chat', 'Dialogues', DZ.data.dialogues.length + ' conversations') +
      tile('#/grammaire', 'layers', 'Grammaire', DZ.data.grammar.length + ' fiches') +
      tile('#/pratique', 'target', 'Exercices', 'QCM, traduction, ordre…') +
      tile('#/examen', 'exam', 'Mode examen', 'Testez votre niveau') +
      tile('#/dico', 'dict', 'Dictionnaire', C.entries.length + ' mots et expressions') +
      (mist ? '<button class="tile" data-act="start-mistakes"><span class="tile-ico" style="background:var(--red-soft);color:var(--red)">' + U.icon('refresh') + '</span><span class="tile-title">Mes erreurs</span><span class="tile-sub">' + mist + ' à revoir</span></button>' : tile('#/notes', 'note', 'Mes notes', st.notes.length + ' note(s)')) +
      '</div></section></div>';
    root.innerHTML = html;
  };
  function tile(href, icon, title, sub) {
    return '<a class="tile" href="' + href + '"><span class="tile-ico">' + U.icon(icon) + '</span><span class="tile-title">' + T.esc(title) + '</span><span class="tile-sub">' + T.esc(sub) + '</span></a>';
  }
  function lessonCard(l, showStage) {
    var done = C.lessonDone(l.id);
    return '<a class="lesson-card ' + (done ? 'done' : '') + '" href="#/lecon/' + encodeURIComponent(l.id) + '">' +
      '<span class="lc-idx">' + (done ? U.icon('check') : l.idx === 0 ? U.icon('pen') : l.idx) + '</span><span class="lc-body">' +
      '<span class="lc-dz">' + T.dzHtml(l.dz) + '</span><span class="lc-fr">' + T.esc(l.t) + '</span>' +
      '<span class="lc-meta">' + (showStage ? 'Étape ' + l.stage.n + ' · ' : '') + (l.min || 10) + ' min · ' + l.entries.length + ' mots' + (done ? ' · terminée' : '') + '</span></span></a>';
  }

  VIEWS.cours = function (root) {
    topbar({});
    var html = '<div class="page wide view-enter"><div><span class="eyebrow">Programme</span><h1 style="font-size:1.8rem">Les cours</h1>' +
      '<p class="muted">Quatre étapes, du tout premier « salam » aux proverbes. Chaque leçon contient des explications, du vocabulaire, des phrases modèles et un entraînement.</p></div>' +
      '<a class="card hstack" href="#/grammaire" style="text-decoration:none;color:inherit"><span class="tile-ico" style="width:42px;height:42px;border-radius:12px;display:grid;place-items:center;background:var(--green-soft);color:var(--green-strong)">' + U.icon('layers') + '</span><span style="flex:1;min-width:0"><b>Module de grammaire</b><br><span class="small muted">' + DZ.data.grammar.length + ' fiches progressives : pronoms, négation, passé, futur…</span></span>' + U.icon('right') + '</a>';
    DZ.data.stages.forEach(function (s) {
      var p = C.stageProgress(s);
      html += '<section class="stage"><div class="stage-head"><span class="stage-num">' + s.n + '</span><div style="flex:1;min-width:0"><span class="eyebrow">Étape ' + s.n + ' · <span class="dz">' + T.dzHtml(s.dz) + '</span></span><h2>' + T.esc(s.title) + '</h2>' +
        '<div class="hstack small muted"><span>' + T.esc(s.desc) + '</span></div></div></div>' +
        '<div class="hstack"><div class="bar" style="flex:1"><i style="width:' + p.pct + '%"></i></div><span class="small num muted">' + p.done + ' / ' + p.total + '</span></div>' +
        '<div class="lessons">' + s.lessons.map(function (l) { return lessonCard(l); }).join('') + '</div></section>';
    });
    html += '</div>';
    root.innerHTML = html;
  };

  VIEWS.lecon = function (root, id) {
    var l = C.lessonById[id];
    if (!l) return notFound(root);
    topbar({ back: '#/cours', title: 'Étape ' + l.stage.n + ' · ' + l.t });
    var st = DZ.state, done = C.lessonDone(l.id), rec = st.lessons[l.id] || {};
    var prev = C.lessons[C.lessons.indexOf(l) - 1], next = C.lessons[C.lessons.indexOf(l) + 1];
    var html = '<div class="page view-enter"><div class="lesson-head"><span class="eyebrow">Étape ' + l.stage.n + ' · ' + T.esc(l.stage.title) + (l.idx ? ' · Leçon ' + l.idx : ' · Guide') + '</span>' +
      '<h1>' + T.dzHtml(l.dz) + '</h1><div class="lh-fr">' + T.esc(l.t) + '</div>' +
      '<div class="hstack small muted">' + U.icon('clock') + '<span>' + (l.min || 10) + ' min</span>' + (done ? '<span class="badge green">' + U.icon('check') + ' terminée</span>' : '') + (rec.best != null ? '<span class="badge grey">meilleur score : ' + rec.best + ' %</span>' : '') + '</div></div>' +
      '<div class="goalbox">' + U.icon('target') + '<span>' + T.esc(l.goal) + '</span></div>' + toggles() +
      U.blocks(l.blocks);
    if (l.entries.length) {
      html += '<section class="section"><div class="section-head"><h2 class="section-title">Vocabulaire</h2><button class="btn btn-ghost btn-sm" data-act="lesson-srs" data-id="' + l.id + '">' + U.icon('cards') + 'Ajouter à mes révisions</button></div>' +
        '<div class="list">' + l.entries.map(function (e) { return U.wordRow(e, { meta: true }); }).join('') + '</div></section>';
    }
    if (l.phrases && l.phrases.length) {
      html += '<section class="section"><h2 class="section-title">Phrases modèles</h2><div class="list">' + l.phrases.map(U.phraseRow).join('') + '</div></section>';
    }
    html += '<section class="section"><h2 class="section-title">Mes notes sur cette leçon</h2>' +
      '<textarea class="input" id="lesson-note" data-id="' + l.id + '" placeholder="Vos remarques, mots entendus, questions à poser…">' + T.esc(st.lessonNotes[l.id] || '') + '</textarea>' +
      '<span class="tiny muted" id="note-saved">Enregistrement automatique sur cet appareil.</span></section>' +
      '<div class="btn-row"><button class="btn btn-primary" data-act="lesson-practice" data-id="' + l.id + '">' + U.icon('target') + 'S\'entraîner sur cette leçon</button>' +
      '<button class="btn btn-secondary" data-act="lesson-done" data-id="' + l.id + '">' + U.icon(done ? 'refresh' : 'check') + (done ? 'Marquer comme non terminée' : 'Marquer comme terminée') + '</button></div>' +
      '<div class="grid-2 stack-sm">' + (prev ? '<a class="btn btn-ghost" href="#/lecon/' + prev.id + '">' + U.icon('left') + '<span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + T.esc(prev.t) + '</span></a>' : '<span></span>') +
      (next ? '<a class="btn btn-ghost" href="#/lecon/' + next.id + '"><span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + T.esc(next.t) + '</span>' + U.icon('right') + '</a>' : '') + '</div></div>';
    root.innerHTML = html;
    var ta = root.querySelector('#lesson-note'), t;
    ta.addEventListener('input', function () {
      clearTimeout(t); t = setTimeout(function () {
        if (ta.value.trim()) DZ.state.lessonNotes[l.id] = ta.value; else delete DZ.state.lessonNotes[l.id];
        DZ.store.save(); var s = document.getElementById('note-saved'); if (s) s.textContent = 'Note enregistrée.';
      }, 400);
    });
  };

  VIEWS.grammaire = function (root, id) {
    if (id) return grammarDetail(root, id);
    topbar({ back: '#/cours', title: 'Grammaire' });
    var html = '<div class="page view-enter"><div><span class="eyebrow">Module</span><h1 style="font-size:1.8rem">Grammaire</h1><p class="muted">Des explications courtes, en français, avec des exemples algériens. À lire dans l\'ordre.</p></div><div class="lessons">';
    DZ.data.grammar.forEach(function (g) {
      var done = DZ.state.grammar[g.id] && DZ.state.grammar[g.id].done;
      html += '<a class="lesson-card ' + (done ? 'done' : '') + '" href="#/grammaire/' + g.id + '"><span class="lc-idx">' + (done ? U.icon('check') : g.n) + '</span><span class="lc-body"><span class="lc-dz">' + T.dzHtml(g.dz) + '</span><span class="lc-fr">' + T.esc(g.t) + '</span></span></a>';
    });
    root.innerHTML = html + '</div></div>';
  };
  function grammarDetail(root, id) {
    var g = C.grammarById[id]; if (!g) return notFound(root);
    topbar({ back: '#/grammaire', title: g.t });
    var done = DZ.state.grammar[g.id] && DZ.state.grammar[g.id].done;
    var i = DZ.data.grammar.indexOf(g), prev = DZ.data.grammar[i - 1], next = DZ.data.grammar[i + 1];
    root.innerHTML = '<div class="page view-enter"><div class="lesson-head"><span class="eyebrow">Grammaire · fiche ' + g.n + '</span><h1>' + T.dzHtml(g.dz) + '</h1><div class="lh-fr">' + T.esc(g.t) + '</div></div>' + toggles() +
      U.blocks(g.blocks) +
      (g.ex && g.ex.length ? '<section class="section"><h2 class="section-title">Exemples</h2><div class="list">' + g.ex.map(function (p) { return U.phraseRow(p); }).join('') + '</div></section>' : '') +
      '<div class="btn-row"><button class="btn btn-primary" data-act="grammar-practice" data-id="' + g.id + '">' + U.icon('target') + 'S\'entraîner</button>' +
      '<button class="btn btn-secondary" data-act="grammar-done" data-id="' + g.id + '">' + U.icon(done ? 'refresh' : 'check') + (done ? 'Marquer comme non lue' : 'Marquer comme lue') + '</button></div>' +
      '<div class="grid-2 stack-sm">' + (prev ? '<a class="btn btn-ghost" href="#/grammaire/' + prev.id + '">' + U.icon('left') + T.esc(prev.t) + '</a>' : '<span></span>') + (next ? '<a class="btn btn-ghost" href="#/grammaire/' + next.id + '">' + T.esc(next.t) + U.icon('right') + '</a>' : '') + '</div></div>';
  }

  /* ----- Dictionnaire ----- */
  VIEWS.dico = function (root) {
    topbar({});
    var st = DZ.state, d = App.dict;
    var counts = { favs: Object.keys(st.favs).filter(function (k) { return C.byId[k]; }).length, hist: st.history.filter(function (k) { return C.byId[k]; }).length, hard: C.hardList().length, mine: st.custom.length, verify: C.entries.filter(function (e) { return e.u; }).length };
    var F = [['all', 'Tout', ''], ['favs', 'Favoris', counts.favs], ['hist', 'Historique', counts.hist], ['hard', 'Difficiles', counts.hard], ['mine', 'Mes mots', counts.mine], ['verify', 'À vérifier', counts.verify]];
    root.innerHTML = '<div class="page view-enter"><div class="section-head"><div><span class="eyebrow">Hors ligne</span><h1 style="font-size:1.8rem">Dictionnaire</h1></div>' +
      '<a class="btn btn-secondary btn-sm" href="#/ajouter-mot">' + U.icon('plus') + 'Ajouter un mot</a></div>' +
      '<div class="search-box">' + U.icon('dict') + '<input id="dict-q" class="input" type="search" placeholder="Chercher en darija ou en français : 3lach, saha, merci…" value="' + T.esc(d.q) + '" autocomplete="off" autocapitalize="off" spellcheck="false" aria-label="Rechercher dans le dictionnaire"></div>' +
      '<div class="chips" role="tablist" aria-label="Filtres">' + F.map(function (f) { return '<button class="chip ' + (d.filter === f[0] ? 'active' : '') + '" data-act="dict-filter" data-f="' + f[0] + '">' + f[1] + (f[2] !== '' ? ' <span class="count num">' + f[2] + '</span>' : '') + '</button>'; }).join('') + '</div>' +
      '<div class="chips" aria-label="Thèmes"><button class="chip ' + (!d.cat ? 'active' : '') + '" data-act="dict-cat" data-c="">Tous les thèmes</button>' +
      DZ.data.cats.map(function (c) { return '<button class="chip ' + (d.cat === c.id ? 'active' : '') + '" data-act="dict-cat" data-c="' + c.id + '">' + T.esc(c.label) + '</button>'; }).join('') + '</div>' +
      toggles() + '<div id="dict-res"></div></div>';
    var inp = root.querySelector('#dict-q'), t;
    inp.addEventListener('input', function () { clearTimeout(t); t = setTimeout(function () { d.q = inp.value; d.limit = 60; renderDictResults(); }, 90); });
    renderDictResults();
  };
  function renderDictResults() {
    var st = DZ.state, d = App.dict, el = document.getElementById('dict-res'); if (!el) return;
    var list;
    if (d.filter === 'favs') list = Object.keys(st.favs).sort(function (a, b) { return st.favs[b] - st.favs[a]; }).map(function (k) { return C.byId[k]; }).filter(Boolean);
    else if (d.filter === 'hist') list = st.history.map(function (k) { return C.byId[k]; }).filter(Boolean);
    else if (d.filter === 'hard') list = C.hardList();
    else if (d.filter === 'mine') list = C.entries.filter(function (e) { return e.custom; });
    else if (d.filter === 'verify') list = C.entries.filter(function (e) { return e.u; });
    else list = C.entries;
    if (d.cat) list = list.filter(function (e) { return e.cat === d.cat; });
    if (d.q.trim()) list = C.search(d.q, { list: list });
    var total = list.length, shown = list.slice(0, d.limit);
    var emptyMsg = d.filter === 'favs' ? ['star', 'Aucun favori', 'Touchez l\'étoile à côté d\'un mot pour le retrouver ici.']
      : d.filter === 'hist' ? ['history', 'Historique vide', 'Les mots que vous consultez apparaîtront ici.']
        : d.filter === 'hard' ? ['flag', 'Aucun mot difficile', 'Les mots que vous ratez souvent, ou que vous marquez comme difficiles, apparaîtront ici.']
          : d.filter === 'mine' ? ['plus', 'Aucun mot personnel', 'Ajoutez vos propres mots et expressions.']
            : ['dict', 'Aucun résultat', 'Essayez une autre orthographe (ex. « 3lach », « alach », « 3lech ») ou cherchez en français.'];
    el.innerHTML = '<div class="hstack small muted" style="margin-bottom:8px"><span class="num">' + total + ' résultat' + (total > 1 ? 's' : '') + '</span></div>' +
      (total ? '<div class="list">' + shown.map(function (e) { return U.wordRow(e, { cat: !d.cat }); }).join('') + '</div>' +
        (total > shown.length ? '<button class="btn btn-secondary btn-block" style="margin-top:12px" data-act="dict-more">Afficher plus (' + (total - shown.length) + ' restants)</button>' : '')
        : U.empty(emptyMsg[0], emptyMsg[1], emptyMsg[2], d.filter === 'mine' ? '<a class="btn btn-primary" href="#/ajouter-mot">' + U.icon('plus') + 'Ajouter un mot</a>' : ''));
  }

  VIEWS.mot = function (root, id) {
    var e = C.byId[id]; if (!e) return notFound(root);
    C.pushHistory(e.id);
    topbar({ back: '#/dico', title: 'Dictionnaire' });
    var st = DZ.state, fav = !!st.favs[e.id], hard = !!st.hard[e.id], card = st.srs[e.id], status = C.wordStatus(e.id);
    var statusTxt = { none: 'Pas encore en révision', learning: 'En cours d\'apprentissage', learned: 'Appris', mastered: 'Maîtrisé' }[status];
    var nextRev = card ? new Date(card.d) : null;
    var cat = C.catById[e.cat];
    var html = '<div class="page view-enter"><section class="card word-hero"><div class="hstack"><span class="badge grey">' + T.esc(cat ? cat.label : e.cat) + '</span>' + U.badges(e) + '</div>' +
      '<div class="w-dz">' + T.dzHtml(e.d) + '</div>' +
      (e.ar ? (st.settings.showArabic ? '<div>' + T.arHtml(e.ar) + '</div>' : '<button class="reveal-btn" data-act="show-ar" data-ar="' + T.esc(e.ar) + '">' + 'Afficher l\'écriture arabe' + '</button><div id="ar-slot"></div>') : '') +
      '<div class="w-fr">' + T.esc(e.fr) + '</div>' +
      '<div class="hstack">' + U.audioBtn(e.d, e.ar) +
      '<button class="btn btn-secondary btn-sm" data-act="audio-sheet" data-dz="' + T.esc(e.d) + '" data-ar="' + T.esc(e.ar) + '">' + U.icon('mic') + 'Prononciation</button>' +
      '<span class="spacer"></span><button class="icon-btn star ' + (fav ? 'on' : '') + '" data-act="fav" data-id="' + T.esc(e.id) + '" aria-pressed="' + fav + '" aria-label="Favori">' + U.icon('star') + '</button>' +
      '<button class="icon-btn flag ' + (hard ? 'on' : '') + '" data-act="hard" data-id="' + T.esc(e.id) + '" aria-pressed="' + hard + '" aria-label="Marquer comme difficile">' + U.icon('flag') + '</button></div></section>';
    html += '<section class="card"><dl class="kv">' +
      (e.v && e.v.length ? '<dt>Variantes</dt><dd><span class="dz">' + e.v.map(T.dzHtml).join(', ') + '</span><div class="tiny muted">Acceptées dans la recherche et les exercices.</div></dd>' : '') +
      (e.p ? '<dt>Prononciation</dt><dd>' + T.esc(e.p) + '</dd>' : '') +
      (e.exd ? '<dt>Exemple</dt><dd><div class="hstack" style="align-items:flex-start;flex-wrap:nowrap"><div style="flex:1;min-width:0"><span class="dz" style="font-size:1.1rem">' + T.dzHtml(e.exd) + '</span><br><span class="muted">' + T.esc(e.exf) + '</span></div>' + U.audioBtn(e.exd, '', true) + '</div></dd>' : '') +
      (e.n ? '<dt>Note</dt><dd>' + T.richHtml(e.n) + '</dd>' : '') +
      (e.r ? '<dt>Région</dt><dd>' + T.esc(e.r) + '</dd>' : '') +
      '<dt>Révision</dt><dd>' + statusTxt + (card ? '<div class="tiny muted">Prochaine révision : ' + (card.d <= Date.now() ? 'maintenant' : nextRev.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long' })) + '</div>' : '') + '</dd>' +
      '</dl></section>';
    if (e.u) html += '<div class="callout warn">' + U.icon('alert') + '<div><b class="cl">À vérifier</b>Cette forme ou ce sens n\'est pas confirmé avec certitude, ou varie selon les régions. Vérifiez auprès d\'un locuteur natif ; vous pouvez ajouter votre propre version dans « Mes mots ».</div></div>';
    if (e.lessons && e.lessons.length) html += '<section class="section"><h2 class="section-title">Dans les cours</h2><div class="lessons">' + e.lessons.map(function (lid) { return lessonCard(C.lessonById[lid], true); }).join('') + '</div></section>';
    html += '<div class="btn-row">' + (card ? '<button class="btn btn-secondary" data-act="srs-remove" data-id="' + T.esc(e.id) + '">' + U.icon('x') + 'Retirer des révisions</button>' : '<button class="btn btn-secondary" data-act="srs-add" data-id="' + T.esc(e.id) + '">' + U.icon('cards') + 'Ajouter à mes révisions</button>') +
      '<button class="btn btn-primary" data-act="word-practice" data-id="' + T.esc(e.id) + '">' + U.icon('target') + 'S\'entraîner</button></div>';
    if (e.custom) html += '<div class="btn-row"><a class="btn btn-ghost" href="#/modifier-mot/' + encodeURIComponent(e.id) + '">' + U.icon('pen') + 'Modifier</a><button class="btn btn-ghost" data-act="custom-delete" data-id="' + T.esc(e.id) + '" style="color:var(--bad)">' + U.icon('trash') + 'Supprimer</button></div>';
    root.innerHTML = html + '</div>';
  };

  function wordForm(root, existing) {
    topbar({ back: existing ? '#/mot/' + encodeURIComponent(existing.id) : '#/dico', title: existing ? 'Modifier un mot' : 'Ajouter un mot' });
    var e = existing || { d: '', fr: '', ar: '', exd: '', exf: '', v: [], n: '', cat: 'perso' };
    root.innerHTML = '<div class="page view-enter"><div><span class="eyebrow">Mes mots</span><h1 style="font-size:1.6rem">' + (existing ? 'Modifier le mot' : 'Ajouter un mot ou une expression') + '</h1>' +
      '<p class="muted small">Écrivez la darija en lettres latines avec les chiffres (3, 7, 9…). Vos mots apparaissent dans le dictionnaire, la recherche et les exercices.</p></div>' +
      '<form id="word-form" class="card" style="display:flex;flex-direction:column;gap:14px" novalidate>' +
      field('wf-d', 'Darija (lettres latines et chiffres) *', '<input id="wf-d" class="input dz-input" required value="' + T.esc(e.d) + '" placeholder="ex. N7eb net3allem" autocapitalize="off" spellcheck="false">') +
      field('wf-fr', 'Traduction française *', '<input id="wf-fr" class="input" required value="' + T.esc(e.fr) + '" placeholder="ex. Je veux apprendre">') +
      field('wf-v', 'Variantes d\'écriture (séparées par des virgules)', '<input id="wf-v" class="input" value="' + T.esc((e.v || []).join(', ')) + '" placeholder="ex. n7ab net3alem, nheb">') +
      field('wf-exd', 'Exemple en darija', '<input id="wf-exd" class="input dz-input" value="' + T.esc(e.exd) + '">') +
      field('wf-exf', 'Traduction de l\'exemple', '<input id="wf-exf" class="input" value="' + T.esc(e.exf) + '">') +
      field('wf-ar', 'Écriture arabe (facultatif)', '<input id="wf-ar" class="input" dir="rtl" lang="ar" value="' + T.esc(e.ar) + '" style="font-family:var(--f-ar)">') +
      field('wf-n', 'Note (contexte, région, qui me l\'a appris…)', '<textarea id="wf-n" class="input">' + T.esc(e.n) + '</textarea>') +
      field('wf-cat', 'Thème', '<select id="wf-cat" class="input"><option value="perso">Mes mots</option>' + DZ.data.cats.map(function (c) { return '<option value="' + c.id + '"' + (e.cat === c.id ? ' selected' : '') + '>' + T.esc(c.label) + '</option>'; }).join('') + '</select>') +
      '<p class="small" id="wf-err" style="color:var(--bad)" hidden></p>' +
      '<button class="btn btn-primary" type="submit">' + U.icon('check') + 'Enregistrer</button></form></div>';
    root.querySelector('#word-form').addEventListener('submit', function (ev) {
      ev.preventDefault();
      var g = function (id) { return root.querySelector('#' + id).value.trim(); };
      if (!g('wf-d') || !g('wf-fr')) { var er = root.querySelector('#wf-err'); er.hidden = false; er.textContent = 'La darija et la traduction française sont obligatoires.'; return; }
      var rec = { d: g('wf-d'), fr: g('wf-fr'), ar: g('wf-ar'), exd: g('wf-exd'), exf: g('wf-exf'), n: g('wf-n'), cat: g('wf-cat'), v: g('wf-v').split(',').map(function (s) { return s.trim(); }).filter(Boolean) };
      var list = DZ.state.custom;
      if (existing) { var x = list.filter(function (c) { return c.id === existing.id; })[0]; Object.keys(rec).forEach(function (k) { x[k] = rec[k]; }); rec.id = existing.id; }
      else { rec.id = 'perso/' + Date.now().toString(36); rec.ts = Date.now(); list.push(rec); }
      DZ.store.save(); C.refreshCustom();
      U.toast(existing ? 'Mot modifié.' : 'Mot ajouté à votre dictionnaire.');
      App.go('#/mot/' + encodeURIComponent(rec.id), true);
    });
  }
  function field(id, label, input) { return '<div class="field"><label for="' + id + '">' + T.esc(label) + '</label>' + input + '</div>'; }
  VIEWS['ajouter-mot'] = function (root) { wordForm(root, null); };
  VIEWS['modifier-mot'] = function (root, id) {
    var x = DZ.state.custom.filter(function (c) { return c.id === id; })[0];
    if (!x) return notFound(root);
    wordForm(root, x);
  };

  /* ----- Dialogues ----- */
  VIEWS.dialogues = function (root) {
    topbar({});
    var cats = DZ.dialogueCats, cur = App.dlgCat;
    var list = DZ.data.dialogues.filter(function (d) { return !cur || d.cat === cur; });
    var doneN = DZ.data.dialogues.filter(function (d) { return DZ.state.dialogues[d.id] && DZ.state.dialogues[d.id].done; }).length;
    root.innerHTML = '<div class="page wide view-enter"><div><span class="eyebrow">' + doneN + ' / ' + DZ.data.dialogues.length + ' terminés</span><h1 style="font-size:1.8rem">Dialogues</h1><p class="muted">Des conversations de tous les jours. Affichez la traduction réplique par réplique pour vous entraîner sans aide.</p></div>' +
      '<div class="chips"><button class="chip ' + (!cur ? 'active' : '') + '" data-act="dlg-cat" data-c="">Tous</button>' +
      Object.keys(cats).map(function (k) { return '<button class="chip ' + (cur === k ? 'active' : '') + '" data-act="dlg-cat" data-c="' + k + '">' + T.esc(cats[k]) + '</button>'; }).join('') + '</div>' +
      '<div class="lessons">' + list.map(function (d) {
        var done = DZ.state.dialogues[d.id] && DZ.state.dialogues[d.id].done;
        return '<a class="lesson-card ' + (done ? 'done' : '') + '" href="#/dialogue/' + d.id + '"><span class="lc-idx">' + (done ? U.icon('check') : U.icon('chat')) + '</span><span class="lc-body">' +
          '<span class="lc-dz">' + T.dzHtml(d.dz) + '</span><span class="lc-fr">' + T.esc(d.t) + '</span>' +
          '<span class="lc-meta">' + T.esc(cats[d.cat]) + ' · niveau ' + d.lvl + ' · ' + d.lines.length + ' répliques</span></span></a>';
      }).join('') + '</div></div>';
  };

  VIEWS.dialogue = function (root, id) {
    var d = C.dialogueById[id]; if (!d) return notFound(root);
    topbar({ back: '#/dialogues', title: d.t });
    var st = DZ.state, mode = App.dlgMode || (st.settings.hideFr ? 'tap' : 'show');
    var speakers = []; d.lines.forEach(function (l) { if (speakers.indexOf(l[0]) < 0) speakers.push(l[0]); });
    var anyAudio = d.lines.some(function (l) { return A.has(l[1]); });
    var html = '<div class="page view-enter"><div class="lesson-head"><span class="eyebrow">' + T.esc(DZ.dialogueCats[d.cat]) + ' · niveau ' + d.lvl + '</span><h1>' + T.dzHtml(d.dz) + '</h1><div class="lh-fr">' + T.esc(d.t) + '</div></div>' +
      '<div class="goalbox">' + U.icon('info') + '<span>' + T.esc(d.ctx) + '</span></div>' +
      '<div class="toolbar"><div class="seg" role="group" aria-label="Traduction">' +
      [['show', 'Traduction visible'], ['tap', 'Au toucher'], ['hide', 'Masquée']].map(function (m) { return '<button data-act="dlg-mode" data-m="' + m[0] + '" class="' + (mode === m[0] ? 'active' : '') + '" aria-pressed="' + (mode === m[0]) + '">' + m[1] + '</button>'; }).join('') +
      '</div><button class="chip ' + (st.settings.showArabic ? 'active' : '') + '" data-act="toggle-ar">' + U.icon('ar') + 'Arabe</button>' +
      (anyAudio ? '<button class="chip" data-act="dlg-playall" data-id="' + d.id + '">' + U.icon('play') + 'Tout écouter</button>' : '') + '</div>' +
      '<div class="dlg" id="dlg">' + d.lines.map(function (l, i) {
        var right = speakers.indexOf(l[0]) % 2 === 1;
        var fr = mode === 'show' ? '<div class="fr">' + T.esc(l[3]) + '</div>' : mode === 'tap' ? '<button class="reveal-btn" data-act="dlg-reveal" data-i="' + i + '">Voir la traduction</button><div class="fr" id="dl-fr-' + i + '" hidden>' + T.esc(l[3]) + '</div>' : '';
        var has = A.has(l[1]);
        return '<div class="bubble-row ' + (right ? 'right' : '') + '"><span class="bubble-who">' + T.esc(l[0]) + '</span><div class="bubble" id="bub-' + i + '">' +
          '<div class="dz">' + T.dzHtml(l[1]) + '</div>' + (st.settings.showArabic ? T.arHtml(l[2]) : '') + fr +
          '<div class="b-acts">' + (has ? '<button class="icon-btn sm has-audio" data-act="audio" data-dz="' + T.esc(l[1]) + '" aria-label="Écouter la réplique">' + U.icon('volume') + '</button>' +
            '<button class="icon-btn sm" data-act="line-repeat" data-dz="' + T.esc(l[1]) + '" aria-label="Répéter la réplique trois fois">' + U.icon('repeat') + '</button>' : '') +
          '<button class="icon-btn sm no-audio" data-act="audio-sheet" data-dz="' + T.esc(l[1]) + '" data-ar="' + T.esc(l[2]) + '" aria-label="Enregistrer ou importer la prononciation">' + U.icon('mic') + '</button></div></div></div>';
      }).join('') + '</div>' +
      (anyAudio ? '' : '<p class="small muted">Aucun enregistrement pour ce dialogue. Touchez ' + U.icon('mic').replace('class="i ', 'style="width:16px;height:16px;vertical-align:-3px" class="i ') + ' pour enregistrer une réplique (par exemple avec un ami algérien) : elle sera disponible hors ligne.</p>') +
      '<section class="section"><h2 class="section-title">Questions de compréhension</h2><div id="dlg-q">' + d.q.map(function (q, qi) {
        return '<div class="q-card" style="margin-bottom:12px" data-q="' + qi + '"><div class="q-prompt">' + T.esc(q.q) + '</div><div class="opts">' +
          T.shuffle(q.o.map(function (o, j) { return [o, j]; })).map(function (x) { return '<button class="opt" data-act="dlg-answer" data-q="' + qi + '" data-o="' + x[1] + '">' + T.esc(x[0]) + '</button>'; }).join('') +
          '</div><div class="dlg-fb"></div></div>';
      }).join('') + '</div></section></div>';
    root.innerHTML = html;
    App.dlgAnswers = {};
  };

  /* ----- Pratique ----- */
  VIEWS.pratique = function (root) {
    topbar({});
    var st = DZ.state, due = C.srsDue().length, total = C.counts().total, mist = C.mistakeList().length;
    var newAvail = C.newCandidates(st.settings.newPerDay).length;
    var p = App.practice, sc = p.scope;
    var scopes = [['all', 'Tout'], ['s1', 'Étape 1'], ['s2', 'Étape 2'], ['s3', 'Étape 3'], ['s4', 'Étape 4'], ['favs', 'Favoris'], ['hard', 'Difficiles'], ['custom', 'Mes mots']];
    var curScope = sc.stage ? 's' + sc.stage : sc.favs ? 'favs' : sc.hard ? 'hard' : sc.custom ? 'custom' : sc.cat ? 'cat' : 'all';
    root.innerHTML = '<div class="page view-enter"><div><span class="eyebrow">S\'entraîner</span><h1 style="font-size:1.8rem">Pratique</h1></div>' +
      '<section class="card section"><div class="section-head"><h2 class="section-title">Révision du jour</h2><span class="badge ' + (due ? 'red' : 'green') + ' num">' + due + ' à réviser</span></div>' +
      '<p class="small muted">Répétition espacée : les mots difficiles reviennent souvent, les mots maîtrisés de plus en plus rarement. ' + total + ' mot(s) suivis · ' + newAvail + ' nouveau(x) disponible(s) aujourd\'hui.</p>' +
      '<div class="btn-row">' + [5, 10, 15].map(function (m) { return '<button class="btn ' + (m === 10 ? 'btn-primary' : 'btn-secondary') + '" data-act="review-start" data-min="' + m + '">' + U.icon('clock') + m + ' min</button>'; }).join('') + '</div>' +
      (!due && total ? '<button class="btn btn-ghost btn-sm" data-act="review-cram">Réviser quand même (cartes les plus proches)</button>' : '') + '</section>' +
      (mist ? '<button class="tile" data-act="start-mistakes" style="flex-direction:row;align-items:center"><span class="tile-ico" style="background:var(--red-soft);color:var(--red)">' + U.icon('refresh') + '</span><span style="flex:1"><span class="tile-title">Révision des erreurs</span><br><span class="tile-sub">' + mist + ' élément(s) à revoir</span></span>' + U.icon('right') + '</button>' : '') +
      '<section class="section"><h2 class="section-title">Exercices</h2>' +
      '<div class="field"><span class="small muted">Sur quoi ?</span><div class="chips wrap">' + scopes.map(function (s) { return '<button class="chip ' + (curScope === s[0] ? 'active' : '') + '" data-act="pr-scope" data-s="' + s[0] + '">' + s[1] + '</button>'; }).join('') +
      '<select class="input" id="pr-cat" style="width:auto;min-height:36px;padding:6px 10px;border-radius:99px" aria-label="Choisir un thème"><option value="">Un thème…</option>' + DZ.data.cats.map(function (c) { return '<option value="' + c.id + '"' + (sc.cat === c.id ? ' selected' : '') + '>' + T.esc(c.label) + '</option>'; }).join('') + '</select></div></div>' +
      '<div class="hstack"><span class="small muted">Nombre de questions :</span><div class="seg">' + [10, 20].map(function (n) { return '<button data-act="pr-n" data-n="' + n + '" class="' + (p.n === n ? 'active' : '') + '">' + n + '</button>'; }).join('') + '</div></div>' +
      '<div class="grid">' + X.TYPES.map(function (t) {
        return '<button class="tile" data-act="pr-start" data-t="' + t.id + '"><span class="tile-ico">' + U.icon(t.icon) + '</span><span class="tile-title">' + T.esc(t.label) + '</span><span class="tile-sub">' + T.esc(t.desc) + '</span></button>';
      }).join('') + '</div></section>' +
      '<a class="card hstack" href="#/examen" style="text-decoration:none;color:inherit"><span class="tile-ico" style="width:42px;height:42px;border-radius:12px;display:grid;place-items:center;background:var(--green-soft);color:var(--green-strong)">' + U.icon('exam') + '</span><span style="flex:1;min-width:0"><b>Mode examen</b><br><span class="small muted">Questions mélangées, corrections à la fin, score enregistré.</span></span>' + U.icon('right') + '</a></div>';
  };

  VIEWS.session = function (root) { topbar({ back: X.session ? X.session.back : '#/pratique', title: X.session ? X.session.title : 'Exercices' }); X.render(root); };
  VIEWS.reviser = function (root) { topbar({ back: '#/pratique', title: 'Révision' }); X.renderReview(root); };

  VIEWS.examen = function (root) {
    topbar({ back: '#/pratique', title: 'Mode examen' });
    var ex = DZ.state.exams;
    var opts = App.exam || (App.exam = { stage: 1, n: DZ.state.settings.examSize || 20 });
    root.innerHTML = '<div class="page view-enter"><div><span class="eyebrow">Évaluation</span><h1 style="font-size:1.8rem">Mode examen</h1><p class="muted">Un test mélangé (QCM, traduction, ordre des mots, phrases à compléter). Aucune correction pendant l\'examen : le score et les corrections s\'affichent à la fin.</p></div>' +
      '<section class="card section"><div class="field"><span class="small muted">Niveau testé</span><div class="chips wrap">' +
      [[1, 'Étape 1'], [2, 'Étape 2'], [3, 'Étape 3'], [4, 'Étape 4'], [0, 'Tout']].map(function (s) { return '<button class="chip ' + (opts.stage === s[0] ? 'active' : '') + '" data-act="exam-stage" data-s="' + s[0] + '">' + s[1] + '</button>'; }).join('') + '</div></div>' +
      '<div class="hstack"><span class="small muted">Questions :</span><div class="seg">' + [10, 20, 30].map(function (n) { return '<button data-act="exam-n" data-n="' + n + '" class="' + (opts.n === n ? 'active' : '') + '">' + n + '</button>'; }).join('') + '</div></div>' +
      '<button class="btn btn-primary" data-act="exam-start">' + U.icon('exam') + 'Commencer l\'examen</button></section>' +
      '<section class="section"><h2 class="section-title">Mes derniers examens</h2>' + (ex.length ? '<div class="list">' + ex.slice(0, 10).map(function (x) {
        return '<div class="row"><div class="row-main" style="cursor:default"><b>' + T.esc(x.label) + '</b><span class="small muted">' + new Date(x.ts).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' }) + ' · ' + x.ok + '/' + x.n + ' · ' + Math.round(x.sec / 60) + ' min</span></div><span class="badge ' + (x.pct >= 70 ? 'green' : x.pct >= 50 ? 'verify' : 'red') + ' num">' + x.pct + ' %</span></div>';
      }).join('') + '</div>' : U.empty('exam', 'Aucun examen passé', 'Vos résultats apparaîtront ici.')) + '</section></div>';
  };

  function buildExam(stage, n) {
    var scope = stage ? { stage: stage } : {};
    var pool = X.pool(scope), sents = X.sentences(scope), items = [];
    var gens = [X.gen.mcqDzFr, X.gen.mcqFrDz, X.gen.inputFrDz, X.gen.fill, X.gen.mcqDzFr, X.gen.mcqFrDz];
    T.shuffle(pool).some(function (e) { var it = gens[Math.floor(Math.random() * gens.length)](e); if (it) items.push(it); return items.length >= Math.round(n * 0.8); });
    T.shuffle(sents).slice(0, n - items.length).forEach(function (s) { var it = X.gen.order(s); if (it) items.push(it); });
    if (stage) {
      var qs = []; DZ.data.stages[stage - 1].lessons.forEach(function (l) { (l.quiz || []).forEach(function (q, i) { qs.push([l, q, i]); }); });
      T.shuffle(qs).slice(0, Math.round(n * 0.25)).forEach(function (x) { var it = X.fromQuiz(x[1], 'q:' + x[0].id + ':' + x[2]); if (it) items.push(it); });
    }
    return T.shuffle(items).slice(0, n);
  }

  /* ----- Progression ----- */
  VIEWS.progres = function (root) {
    topbar({ back: '#/plus', title: 'Progression' });
    var st = DZ.state, c = C.counts(), lv = C.xpLevel(), stage = C.currentStage();
    var lessonsDone = C.lessons.filter(function (l) { return C.lessonDone(l.id); }).length;
    var dlgDone = DZ.data.dialogues.filter(function (d) { return st.dialogues[d.id] && st.dialogues[d.id].done; }).length;
    var acc = st.stats.answers ? Math.round(st.stats.correct / st.stats.answers * 100) : 0;
    var days = [], max = 1, i;
    for (i = 13; i >= 0; i--) { var d = new Date(Date.now() - i * 86400000), k = C.today(d), a = st.activity[k] || { xp: 0 }; days.push({ d: d, xp: a.xp || 0, today: i === 0 }); max = Math.max(max, a.xp || 0); }
    var fc = C.srsDueSoon(7), fmax = Math.max.apply(null, fc.concat([1]));
    var wd = ['D', 'L', 'M', 'M', 'J', 'V', 'S'];
    root.innerHTML = '<div class="page view-enter"><div><span class="eyebrow">Statistiques personnelles</span><h1 style="font-size:1.8rem">Progression</h1></div>' +
      '<section class="card section"><div class="hstack"><span class="stage-num">' + stage.n + '</span><div style="flex:1;min-width:0"><span class="eyebrow">Niveau actuel</span><b style="display:block;font-size:1.15rem">Étape ' + stage.n + ' · ' + T.esc(stage.title) + '</b><span class="small muted">Niveau XP ' + lv.lvl + ' · ' + lv.xp + ' XP au total</span></div></div>' +
      '<div class="bar"><i style="width:' + lv.pct + '%"></i></div><span class="tiny muted num">' + (lv.next - lv.xp) + ' XP avant le niveau ' + (lv.lvl + 1) + '</span></section>' +
      '<div class="stats-grid">' +
      stat(C.streak(), 'jours de suite') + stat(C.daysUsed(), 'jours d\'utilisation') + stat(c.known, 'mots appris') + stat(c.mastered, 'mots maîtrisés') +
      stat(c.total, 'mots en révision') + stat(lessonsDone + '/' + C.lessons.length, 'leçons terminées') + stat(dlgDone + '/' + DZ.data.dialogues.length, 'dialogues terminés') +
      stat(acc + ' %', 'de bonnes réponses') + stat(st.stats.answers, 'réponses données') + stat(st.stats.reviews, 'cartes révisées') + stat(C.mistakeList().length, 'erreurs à revoir') + stat(C.hardList().length, 'mots difficiles') + '</div>' +
      '<section class="card section"><h2 class="section-title">XP des 14 derniers jours</h2><div class="chart" role="img" aria-label="XP par jour sur 14 jours">' + days.map(function (x) {
        return '<div class="col"><i class="' + (x.today ? 'today' : '') + '" style="height:' + Math.round(x.xp / max * 100) + '%">' + (x.xp ? '<em>' + x.xp + '</em>' : '') + '</i><span>' + wd[x.d.getDay()] + '</span></div>';
      }).join('') + '</div></section>' +
      '<section class="card section"><h2 class="section-title">Révisions prévues (7 jours)</h2><div class="chart" style="height:110px" role="img" aria-label="Cartes à réviser dans les 7 prochains jours">' + fc.map(function (n, j) {
        var dd = new Date(Date.now() + j * 86400000);
        return '<div class="col"><i style="height:' + Math.round(n / fmax * 100) + '%;background:var(--green-strong)">' + (n ? '<em>' + n + '</em>' : '') + '</i><span>' + (j === 0 ? 'auj.' : wd[dd.getDay()]) + '</span></div>';
      }).join('') + '</div></section>' +
      '<section class="card section"><h2 class="section-title">Étapes</h2>' + DZ.data.stages.map(function (s) {
        var p = C.stageProgress(s);
        return '<div style="display:flex;flex-direction:column;gap:6px"><div class="hstack"><b>Étape ' + s.n + ' · ' + T.esc(s.title) + '</b><span class="spacer"></span><span class="small num muted">' + p.done + '/' + p.total + '</span></div><div class="bar"><i style="width:' + p.pct + '%"></i></div></div>';
      }).join('') + '</section>' +
      '<div class="btn-row"><a class="btn btn-secondary" href="#/sauvegarde">' + U.icon('download') + 'Sauvegarder mes progrès</a><button class="btn btn-ghost" data-act="reset-progress" style="color:var(--bad)">' + U.icon('trash') + 'Réinitialiser les progrès</button></div></div>';
  };
  function stat(v, l) { return '<div class="stat"><b class="num">' + T.esc(String(v)) + '</b><span>' + T.esc(l) + '</span></div>'; }

  /* ----- Notes ----- */
  VIEWS.notes = function (root) {
    topbar({ back: '#/plus', title: 'Mes notes' });
    var st = DZ.state, notes = st.notes.slice().sort(function (a, b) { return b.ts - a.ts; });
    var ln = Object.keys(st.lessonNotes).filter(function (k) { return C.lessonById[k]; });
    root.innerHTML = '<div class="page view-enter"><div class="section-head"><div><span class="eyebrow">Carnet</span><h1 style="font-size:1.8rem">Mes notes</h1></div><a class="btn btn-primary btn-sm" href="#/note/nouvelle">' + U.icon('plus') + 'Nouvelle note</a></div>' +
      (notes.length ? '<div class="list">' + notes.map(function (n) {
        return '<a class="row" href="#/note/' + n.id + '"><div class="row-main note-item"><b>' + T.esc(n.title || 'Sans titre') + '</b><span class="small muted">' + T.esc((n.text || '').slice(0, 120)) + '</span><span class="tiny muted">' + new Date(n.ts).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' }) + '</span></div>' + U.icon('right') + '</a>';
      }).join('') + '</div>' : U.empty('note', 'Aucune note', 'Notez ici ce que vous entendez, vos questions, vos découvertes.')) +
      (ln.length ? '<section class="section"><h2 class="section-title">Notes de leçons</h2><div class="list">' + ln.map(function (k) {
        var l = C.lessonById[k];
        return '<a class="row" href="#/lecon/' + k + '"><div class="row-main"><b>' + T.esc(l.t) + '</b><span class="small muted">' + T.esc(st.lessonNotes[k].slice(0, 120)) + '</span></div>' + U.icon('right') + '</a>';
      }).join('') + '</div></section>' : '') + '</div>';
  };
  VIEWS.note = function (root, id) {
    var st = DZ.state, n;
    if (id === 'nouvelle') { n = { id: 'n' + Date.now().toString(36), title: '', text: '', ts: Date.now() }; st.notes.push(n); DZ.store.save(); history.replaceState(null, '', '#/note/' + n.id); }
    else n = st.notes.filter(function (x) { return x.id === id; })[0];
    if (!n) return notFound(root);
    topbar({ back: '#/notes', title: 'Note' });
    root.innerHTML = '<div class="page view-enter"><input id="note-title" class="input" placeholder="Titre" value="' + T.esc(n.title) + '" style="font-weight:700;font-size:1.15rem">' +
      '<textarea id="note-text" class="input" style="min-height:50vh" placeholder="Écrivez librement. Astuce : la darija s\'écrit avec 3, 7, 9…">' + T.esc(n.text) + '</textarea>' +
      '<div class="hstack"><span class="tiny muted" id="note-status">Enregistrement automatique.</span><span class="spacer"></span><button class="btn btn-ghost btn-sm" data-act="note-delete" data-id="' + n.id + '" style="color:var(--bad)">' + U.icon('trash') + 'Supprimer</button></div></div>';
    var t;
    function save() {
      clearTimeout(t); t = setTimeout(function () {
        n.title = root.querySelector('#note-title').value; n.text = root.querySelector('#note-text').value; n.ts = Date.now();
        DZ.store.save(); var s = document.getElementById('note-status'); if (s) s.textContent = 'Note enregistrée.';
      }, 350);
    }
    root.querySelector('#note-title').addEventListener('input', save);
    root.querySelector('#note-text').addEventListener('input', save);
    if (!n.title && !n.text) setTimeout(function () { root.querySelector('#note-title').focus(); }, 60);
  };

  /* ----- Plus (mobile) ----- */
  VIEWS.plus = function (root) {
    topbar({});
    var items = [
      ['#/grammaire', 'layers', 'Grammaire', '15 fiches progressives'], ['#/dialogues', 'chat', 'Dialogues', 'Conversations réalistes'],
      ['#/examen', 'exam', 'Mode examen', 'Tester son niveau'], ['#/progres', 'chart', 'Progression', 'Statistiques personnelles'],
      ['#/notes', 'note', 'Mes notes', 'Carnet personnel'], ['#/sauvegarde', 'download', 'Sauvegarde', 'Exporter / importer mes données'],
      ['#/reglages', 'settings', 'Réglages', 'Thème, objectifs, audio'], ['#/aide', 'help', 'Aide et installation', 'Installer, utiliser hors ligne'],
      ['#/lecon/s1-l0', 'pen', 'Guide d\'écriture', '3 = ع, 7 = ح, 9 = ق…']
    ];
    root.innerHTML = '<div class="page view-enter"><h1 style="font-size:1.8rem">Plus</h1><div class="list">' + items.map(function (x) {
      return '<a class="row" href="' + x[0] + '"><span class="tile-ico" style="width:38px;height:38px;border-radius:11px;display:grid;place-items:center;background:var(--green-soft);color:var(--green-strong);flex:none">' + U.icon(x[1]) + '</span><div class="row-main"><b>' + T.esc(x[2]) + '</b><span class="small muted">' + T.esc(x[3]) + '</span></div>' + U.icon('right') + '</a>';
    }).join('') + '</div><p class="tiny muted" style="text-align:center">Darija DZ ' + VERSION + ' · application personnelle hors ligne · aucune donnée envoyée</p></div>';
  };

  /* ----- Réglages ----- */
  VIEWS.reglages = function (root) {
    topbar({ back: '#/plus', title: 'Réglages' });
    var s = DZ.state.settings, voice = A.ttsVoice();
    root.innerHTML = '<div class="page view-enter"><h1 style="font-size:1.8rem">Réglages</h1>' +
      '<section class="card section"><h2 class="section-title">Apparence</h2><div class="hstack"><span class="small muted">Thème :</span><div class="seg">' +
      [['system', 'Système'], ['light', 'Clair'], ['dark', 'Sombre']].map(function (t) { return '<button data-act="set-theme" data-t="' + t[0] + '" class="' + (s.theme === t[0] ? 'active' : '') + '">' + t[1] + '</button>'; }).join('') + '</div></div>' +
      U.switchRow('set-highlight', 'Colorer les chiffres-lettres', 'Met en valeur 3, 7, 9… à l\'intérieur des mots.', s.highlight) +
      U.switchRow('set-showArabic', 'Afficher l\'écriture arabe', 'Facultatif : la darija latine reste toujours l\'écriture principale.', s.showArabic) +
      U.switchRow('set-hideFr', 'Masquer le français par défaut', 'Touchez une traduction floutée pour la révéler.', s.hideFr) + '</section>' +
      '<section class="card section"><h2 class="section-title">Objectifs</h2>' +
      '<div class="field"><span class="small muted">Objectif quotidien (XP)</span><div class="seg">' + [20, 30, 50, 100].map(function (n) { return '<button data-act="set-num" data-k="dailyGoal" data-v="' + n + '" class="' + (s.dailyGoal === n ? 'active' : '') + '">' + n + '</button>'; }).join('') + '</div><span class="tiny muted">1 bonne réponse = 2 XP · 1 carte révisée = 1 XP · 1 leçon terminée = 10 XP.</span></div>' +
      '<div class="field"><span class="small muted">Nouveaux mots par jour en révision</span><div class="seg">' + [5, 10, 15, 20].map(function (n) { return '<button data-act="set-num" data-k="newPerDay" data-v="' + n + '" class="' + (s.newPerDay === n ? 'active' : '') + '">' + n + '</button>'; }).join('') + '</div></div></section>' +
      '<section class="card section"><h2 class="section-title">Audio</h2>' +
      '<p class="small muted">Aucun enregistrement n\'est fourni avec l\'application : vous pouvez enregistrer la prononciation (la vôtre ou celle d\'un locuteur natif) ou importer vos fichiers audio. Tout reste sur cet appareil.</p>' +
      '<div class="field"><span class="small muted">Vitesse de lecture</span><div class="seg">' + [0.5, 0.75, 1, 1.25].map(function (n) { return '<button data-act="set-num" data-k="audioRate" data-v="' + n + '" class="' + (s.audioRate === n ? 'active' : '') + '">' + String(n).replace('.', ',') + '×</button>'; }).join('') + '</div></div>' +
      '<div class="hstack"><span class="badge grey num">' + A.count() + ' enregistrement(s)</span>' + (A.count() ? '<button class="btn btn-ghost btn-sm" data-act="audio-clear" style="color:var(--bad)">' + U.icon('trash') + 'Tout supprimer</button>' : '') + '</div>' +
      U.switchRow('set-tts', 'Voix de synthèse arabe (expérimental)', voice ? 'Voix trouvée : ' + voice.name + '. Elle lit l\'écriture arabe avec un accent d\'arabe standard : ce n\'est PAS de la darija algérienne.' : 'Aucune voix arabe détectée sur cet appareil. Même installée, elle ne prononcerait pas la darija correctement.', s.tts) + '</section>' +
      '<section class="card section"><h2 class="section-title">Données</h2><div id="storage-info" class="small muted">Analyse du stockage…</div>' +
      '<div class="btn-row"><a class="btn btn-secondary" href="#/sauvegarde">' + U.icon('download') + 'Sauvegarde et restauration</a><button class="btn btn-secondary" data-act="persist">' + U.icon('lock') + 'Protéger mes données</button></div>' +
      '<div class="sep"></div><div class="btn-row"><button class="btn btn-ghost" data-act="reset-progress" style="color:var(--bad)">' + U.icon('refresh') + 'Réinitialiser les progrès</button><button class="btn btn-ghost" data-act="reset-all" style="color:var(--bad)">' + U.icon('trash') + 'Tout effacer</button></div></section></div>';
    var info = root.querySelector('#storage-info');
    Promise.all([DZ.store.estimate(), (navigator.storage && navigator.storage.persisted ? navigator.storage.persisted().catch(function () { return null; }) : Promise.resolve(null))]).then(function (r) {
      var est = r[0], per = r[1];
      var mode = { idb: 'IndexedDB (sur cet appareil)', local: 'stockage local du navigateur', memory: 'mémoire temporaire (non conservée)' }[DZ.store.mode];
      var sw = navigator.serviceWorker && navigator.serviceWorker.controller ? 'oui' : (location.protocol === 'file:' ? 'non (fichier ouvert directement : déjà hors ligne)' : 'pas encore actif');
      info.innerHTML = 'Stockage : <b>' + mode + '</b>.<br>Mode hors ligne (service worker) : <b>' + sw + '</b>.' +
        (per != null ? '<br>Protection contre l\'effacement automatique : <b>' + (per ? 'activée' : 'non activée') + '</b>.' : '') +
        (est && est.usage != null ? '<br>Espace utilisé : <b>' + (est.usage / 1048576).toFixed(1) + ' Mo</b>.' : '');
    });
  };

  /* ----- Sauvegarde ----- */
  VIEWS.sauvegarde = function (root) {
    topbar({ back: '#/plus', title: 'Sauvegarde' });
    root.innerHTML = '<div class="page view-enter"><div><span class="eyebrow">Vos données</span><h1 style="font-size:1.8rem">Sauvegarde et restauration</h1>' +
      '<p class="muted">Vos progrès sont enregistrés automatiquement sur cet appareil. Pour ne rien perdre (changement de téléphone, nettoyage du navigateur), exportez régulièrement une sauvegarde et gardez le fichier en lieu sûr.</p></div>' +
      '<section class="card section"><h2 class="section-title">Exporter</h2><p class="small muted">Crée un fichier <b>.json</b> contenant leçons terminées, scores, révisions, favoris, erreurs, notes et mots personnels.</p>' +
      U.switchRow('exp-audio', 'Inclure mes enregistrements audio', 'Le fichier sera plus lourd.', false) +
      '<button class="btn btn-primary" data-act="export">' + U.icon('download') + 'Exporter une sauvegarde</button><div id="export-fallback"></div></section>' +
      '<section class="card section"><h2 class="section-title">Importer</h2><p class="small muted">Remplace les données actuelles par celles du fichier. Exportez d\'abord si vous voulez garder l\'état actuel.</p>' +
      '<label class="btn btn-secondary" for="imp-file" style="cursor:pointer">' + U.icon('upload') + 'Choisir un fichier de sauvegarde</label><input type="file" id="imp-file" accept=".json,application/json" hidden>' +
      '<details><summary class="small" style="cursor:pointer;color:var(--green);font-weight:650">Ou coller le contenu d\'une sauvegarde</summary><div style="display:flex;flex-direction:column;gap:8px;margin-top:8px"><textarea id="imp-text" class="input" placeholder="{ &quot;app&quot;: &quot;Darija DZ&quot;, … }"></textarea><button class="btn btn-secondary" data-act="import-text">Importer ce texte</button></div></details>' +
      '<p class="small" id="imp-msg" hidden></p></section>' +
      '<div class="callout tip">' + U.icon('bulb') + '<div><b class="cl">Conseil</b>Une sauvegarde par semaine suffit. Sur téléphone, le fichier arrive dans « Téléchargements » : copiez-le dans un dossier de confiance ou sur un autre appareil.</div></div></div>';
    root.querySelector('#imp-file').addEventListener('change', function (e) {
      var f = e.target.files[0]; if (!f) return;
      var r = new FileReader();
      r.onload = function () { tryImport(r.result); e.target.value = ''; };
      r.onerror = function () { importMsg('Lecture du fichier impossible.', true); };
      r.readAsText(f);
    });
  };
  function importMsg(t, bad) { var m = document.getElementById('imp-msg'); if (!m) return; m.hidden = false; m.textContent = t; m.style.color = bad ? 'var(--bad)' : 'var(--ok)'; }
  function tryImport(text) {
    var obj;
    try { obj = JSON.parse(text); } catch (e) { importMsg('Ce fichier n\'est pas une sauvegarde valide (JSON illisible).', true); return; }
    var err = DZ.store.validateBackup(obj); if (err) { importMsg(err, true); return; }
    var date = obj.exported ? new Date(obj.exported).toLocaleString('fr-FR') : 'date inconnue';
    U.confirm({ title: 'Restaurer cette sauvegarde ?', text: 'Sauvegarde du ' + date + '. Vos données actuelles seront remplacées.', ok: 'Restaurer' }).then(function (yes) {
      if (!yes) return;
      DZ.store.importData(obj).then(function () {
        return A.init();
      }).then(function () {
        C.refreshCustom(); applyTheme();
        U.toast('Sauvegarde restaurée.'); App.go('#/', true);
      }).catch(function (e) { importMsg(e.message || 'Import impossible.', true); });
    });
  }

  /* ----- Aide ----- */
  VIEWS.aide = function (root) {
    topbar({ back: '#/plus', title: 'Aide' });
    var standalone = false; try { standalone = matchMedia('(display-mode: standalone)').matches || navigator.standalone; } catch (e) { /* ignoré */ }
    root.innerHTML = '<div class="page view-enter prose"><div><span class="eyebrow">Mode d\'emploi</span><h1 style="font-size:1.8rem">Aide et installation</h1></div>' +
      (standalone ? '<div class="callout tip">' + U.icon('check') + '<div>L\'application est installée et fonctionne hors ligne.</div></div>' : '') +
      '<section class="card prose"><h2 class="section-title">Installer l\'application</h2>' +
      '<p>Darija DZ est une application web installable (PWA). Une fois ouverte une première fois depuis une adresse <b>https://</b> (ou <b>http://localhost</b> sur ordinateur), tout est enregistré sur l\'appareil et l\'application fonctionne ensuite <b>sans Internet</b>.</p>' +
      '<h3>Android (Chrome)</h3><ol><li>Ouvrez l\'adresse de l\'application dans Chrome.</li><li>Menu ⋮ → « Installer l\'application » (ou « Ajouter à l\'écran d\'accueil »).</li><li>Lancez Darija DZ depuis l\'icône. Testez en mode avion : tout doit fonctionner.</li></ol>' +
      '<h3>iPhone / iPad (Safari)</h3><ol><li>Mettez le dossier « version-iphone » en ligne une fois (GitHub Pages, voir GUIDE.md) et ouvrez l\'adresse dans Safari.</li><li>iOS 26 et suivants : ••• → Partager → « Sur l\'écran d\'accueil », avec « Ouvrir en tant qu\'app web » activé. Versions plus anciennes : bouton Partager → « Sur l\'écran d\'accueil ».</li><li>Ouvrez l\'application une fois avec Internet, puis testez en mode avion.</li></ol>' +
      '<h3>Ordinateur</h3><ol><li>Le plus simple : ouvrez le fichier <b>darija-dz.html</b> (version autonome) dans Chrome, Edge ou Firefox. Il fonctionne hors ligne immédiatement.</li><li>Ou lancez le dossier avec <kbd>lancer-windows.bat</kbd> / <kbd>lancer-mac-linux.sh</kbd>, puis installez-la depuis la barre d\'adresse (icône « Installer »).</li></ol>' +
      '<p class="small muted">Le guide complet (GUIDE.md) est fourni avec les fichiers de l\'application.</p></section>' +
      '<section class="card prose"><h2 class="section-title">Utiliser l\'application</h2><ul>' +
      '<li><b>Cours</b> : 4 étapes, à suivre dans l\'ordre. Terminez une leçon (score ≥ 70 % ou bouton « Marquer comme terminée ») : ses mots entrent dans vos révisions.</li>' +
      '<li><b>Révision</b> : 5, 10 ou 15 minutes par jour. Notez honnêtement chaque carte : « À revoir » la fait revenir vite, « Facile » l\'espace beaucoup.</li>' +
      '<li><b>Dictionnaire</b> : recherche instantanée en darija ou en français, tolérante aux variantes (3lach / 3lech, kh / 5, dj / j…). Étoile = favori, drapeau = mot difficile.</li>' +
      '<li><b>Exercices</b> : QCM, traductions, ordre des mots, phrases à compléter, association, expressions, dialogues, révision des erreurs.</li>' +
      '<li><b>Masquer le français</b> : touchez « Français visible » pour flouter les traductions, puis touchez une traduction pour la révéler.</li>' +
      '<li><b>Écriture arabe</b> : facultative, via le bouton « Arabe ».</li></ul></section>' +
      '<section class="card prose"><h2 class="section-title">Audio : ce qui est possible</h2>' +
      '<p>Aucun enregistrement audio n\'est fourni : nous n\'avons pas d\'enregistrements de locuteurs natifs dont l\'usage est vérifié, et les voix de synthèse disponibles ne parlent pas la darija algérienne.</p>' +
      '<ul><li>Touchez ' + U.icon('mic').replace('class="i ', 'style="width:16px;height:16px;vertical-align:-3px" class="i ') + ' à côté d\'un mot ou d\'une réplique pour <b>enregistrer</b> une prononciation (idéalement un ami algérien) ou <b>importer</b> un fichier audio.</li>' +
      '<li>Ensuite, touchez ' + U.icon('volume').replace('class="i ', 'style="width:16px;height:16px;vertical-align:-3px" class="i ') + ' pour écouter. Un appui long (ou clic droit) sur ce bouton rouvre les options (réenregistrer, supprimer, vitesse).</li>' +
      '<li>La vitesse se règle dans Réglages → Audio. Les enregistrements fonctionnent hors ligne.</li></ul>' +
      '<p class="small muted">L\'apprentissage écrit reste complet sans aucun audio.</p></section>' +
      '<section class="card prose"><h2 class="section-title">Sauvegarder mes données</h2><p>Tout est enregistré automatiquement dans le navigateur de cet appareil (IndexedDB). Pour éviter toute perte : <a href="#/sauvegarde">Sauvegarde</a> → « Exporter une sauvegarde », puis gardez le fichier. Pour restaurer : « Importer ».</p>' +
      '<p class="small muted">Attention : vider les données du navigateur ou désinstaller l\'application efface les progrès non exportés.</p></section>' +
      '<section class="card prose"><h2 class="section-title">Qualité du contenu</h2><p>Le contenu vise une darija algérienne naturelle, avec comme référence un parler du Centre compris partout. Les formes dont l\'usage n\'est pas certain, ou qui varient selon les régions, portent la mention <span class="badge verify">à vérifier</span>. Vérifiez-les auprès de locuteurs natifs et ajoutez vos propres versions dans « Mes mots ».</p>' +
      '<p class="small muted">Pour corriger ou enrichir le contenu de base : modifiez les fichiers du dossier <b>data/</b> (voir data/LISEZMOI.md).</p></section>' +
      '<section class="card prose"><h2 class="section-title">Confidentialité</h2><p>Aucun compte, aucun serveur, aucune publicité, aucune statistique envoyée. L\'application ne fait aucune requête réseau pendant l\'utilisation : vos données ne quittent jamais l\'appareil, sauf si vous exportez vous-même un fichier.</p></section>' +
      '<p class="tiny muted" style="text-align:center">Darija DZ ' + VERSION + ' · Police Lora (SIL Open Font License 1.1)</p></div>';
  };

  /* ----- Recherche globale ----- */
  VIEWS.recherche = function (root) {
    topbar({ back: '#/', title: 'Recherche' });
    root.innerHTML = '<div class="page view-enter"><div class="search-box">' + U.icon('dict') + '<input id="gs-q" class="input" type="search" placeholder="Rechercher dans les cours, le dictionnaire, les dialogues, vos notes…" value="' + T.esc(App.gq || '') + '" autocomplete="off" autocapitalize="off" spellcheck="false" aria-label="Recherche globale"></div><div id="gs-res"></div></div>';
    var inp = root.querySelector('#gs-q'), t;
    function run() {
      App.gq = inp.value; var r = C.searchAll(inp.value), el = document.getElementById('gs-res');
      if (!inp.value.trim()) { el.innerHTML = U.empty('dict', 'Recherche dans tout le contenu', 'Exemples : « 3lach », « taxi », « passé », « proverbe ».'); return; }
      var html = '';
      if (r.dict.length) html += '<section class="section"><h2 class="section-title">Dictionnaire</h2><div class="list">' + r.dict.map(function (e) { return U.wordRow(e, { cat: true }); }).join('') + '</div></section>';
      if (r.lessons.length) html += '<section class="section"><h2 class="section-title">Leçons</h2><div class="lessons">' + r.lessons.map(function (l) { return lessonCard(l, true); }).join('') + '</div></section>';
      if (r.grammar.length) html += '<section class="section"><h2 class="section-title">Grammaire</h2><div class="list">' + r.grammar.map(function (g) { return '<a class="row" href="#/grammaire/' + g.id + '"><div class="row-main"><span class="row-dz">' + T.dzHtml(g.dz) + '</span><span class="row-fr">' + T.esc(g.t) + '</span></div>' + U.icon('right') + '</a>'; }).join('') + '</div></section>';
      if (r.dialogues.length) html += '<section class="section"><h2 class="section-title">Dialogues</h2><div class="list">' + r.dialogues.map(function (d) { return '<a class="row" href="#/dialogue/' + d.id + '"><div class="row-main"><span class="row-dz">' + T.dzHtml(d.dz) + '</span><span class="row-fr">' + T.esc(d.t) + '</span></div>' + U.icon('right') + '</a>'; }).join('') + '</div></section>';
      if (r.notes.length) html += '<section class="section"><h2 class="section-title">Mes notes</h2><div class="list">' + r.notes.map(function (n) { return '<a class="row" href="#/note/' + n.id + '"><div class="row-main"><b>' + T.esc(n.title || 'Sans titre') + '</b><span class="small muted">' + T.esc((n.text || '').slice(0, 100)) + '</span></div>' + U.icon('right') + '</a>'; }).join('') + '</div></section>';
      el.innerHTML = html || U.empty('dict', 'Aucun résultat', 'Essayez une autre orthographe ou un mot français.');
    }
    inp.addEventListener('input', function () { clearTimeout(t); t = setTimeout(run, 120); });
    run(); setTimeout(function () { inp.focus(); }, 60);
  };

  function notFound(root) {
    topbar({ back: '#/', title: 'Introuvable' });
    root.innerHTML = '<div class="page">' + U.empty('alert', 'Page introuvable', 'Ce contenu n\'existe pas ou a été supprimé.', '<a class="btn btn-primary" href="#/">Retour à l\'accueil</a>') + '</div>';
  }

  /* ---------- Fenêtre audio ---------- */
  function audioSheet(dz, ar) {
    var has = A.has(dz), rate = DZ.state.settings.audioRate;
    var sh = U.sheet('<h3>Prononciation</h3><div class="dz" style="font-size:1.5rem">' + T.dzHtml(dz) + '</div>' +
      '<p class="small muted">' + (has ? 'Un enregistrement existe pour ce texte (partagé partout où il apparaît).' : 'Aucun enregistrement pour ce texte. Enregistrez votre voix ou celle d\'un locuteur natif, ou importez un fichier audio.') + '</p>' +
      '<div class="btn-row">' + (has ? '<button class="btn btn-primary" data-sa="play">' + U.icon('play') + 'Écouter</button>' : '') +
      (A.canRecord() ? '<button class="btn ' + (has ? 'btn-secondary' : 'btn-primary') + '" data-sa="rec" id="sa-rec">' + U.icon('mic') + (has ? 'Réenregistrer' : 'Enregistrer') + '</button>' : '') +
      '<label class="btn btn-secondary" for="sa-file" style="cursor:pointer">' + U.icon('upload') + 'Importer un fichier</label><input type="file" id="sa-file" accept="audio/*" hidden></div>' +
      '<div id="sa-status" class="hstack small" hidden><span class="rec-dot"></span><span>Enregistrement en cours… touchez « Arrêter » quand vous avez fini (20 s max).</span></div>' +
      (has ? '<div class="field"><span class="small muted">Vitesse</span><div class="seg">' + [0.5, 0.75, 1, 1.25].map(function (n) { return '<button data-sr="' + n + '" class="' + (rate === n ? 'active' : '') + '">' + String(n).replace('.', ',') + '×</button>'; }).join('') + '</div></div>' +
        '<button class="btn btn-ghost" data-sa="del" style="color:var(--bad)">' + U.icon('trash') + 'Supprimer l\'enregistrement</button>' : '') +
      (DZ.state.settings.tts && ar && A.ttsVoice() ? '<div class="sep"></div><button class="btn btn-secondary" data-sa="tts">' + U.icon('volume') + 'Voix de synthèse arabe</button><p class="tiny muted">Expérimental : cette voix lit l\'écriture arabe avec une prononciation d\'arabe standard. Elle ne reproduit pas la darija algérienne.</p>' : '') +
      (!A.canRecord() ? '<p class="tiny muted">L\'enregistrement au micro n\'est pas disponible dans ce navigateur ou dans ce mode d\'ouverture. L\'import de fichier reste possible.</p>' : '') +
      '<button class="btn btn-ghost" data-sa="close">Fermer</button>', { onClose: function () { if (A.isRecording()) A.stopRecording(); } });
    sh.addEventListener('click', function (e) {
      var b = e.target.closest('[data-sa],[data-sr]'); if (!b) return;
      if (b.hasAttribute('data-sr')) { DZ.state.settings.audioRate = +b.getAttribute('data-sr'); DZ.store.save(); sh.querySelectorAll('[data-sr]').forEach(function (x) { x.classList.toggle('active', x === b); }); A.play(dz); return; }
      var a = b.getAttribute('data-sa');
      if (a === 'play') A.play(dz);
      if (a === 'tts') A.speak(ar);
      if (a === 'close') U.closeSheet();
      if (a === 'del') A.remove(dz).then(function () { U.closeSheet(); U.toast('Enregistrement supprimé.'); App.render(); });
      if (a === 'rec') {
        if (A.isRecording()) { A.stopRecording(); return; }
        A.startRecording(dz, function (ok) {
          U.closeSheet(); U.toast(ok ? 'Prononciation enregistrée.' : 'Enregistrement vide, réessayez.'); App.render();
        }).then(function () {
          b.innerHTML = U.icon('stop') + 'Arrêter'; b.className = 'btn btn-danger';
          sh.querySelector('#sa-status').hidden = false;
        }).catch(function (err) { U.toast(err && err.name === 'NotAllowedError' ? 'Accès au micro refusé.' : (err.message || 'Micro indisponible.')); });
      }
    });
    sh.querySelector('#sa-file').addEventListener('change', function (e) {
      var f = e.target.files[0]; if (!f) return;
      A.importFile(dz, f).then(function () { U.closeSheet(); U.toast('Fichier audio associé.'); App.render(); }).catch(function (err) { U.toast(err.message); });
    });
  }
  App.audioSheet = audioSheet;

  /* ---------- Actions ---------- */
  var ACT = {};
  ACT.go = function (el) { App.go(el.getAttribute('data-href')); };
  ACT.theme = function () {
    var s = DZ.state.settings, root = document.documentElement;
    var dark = root.getAttribute('data-theme') === 'dark' || (!root.getAttribute('data-theme') && matchMedia('(prefers-color-scheme: dark)').matches);
    s.theme = dark ? 'light' : 'dark'; DZ.store.save(); applyTheme(); App.render();
  };
  ACT.reveal = function (el) { if (document.getElementById('view').classList.contains('hide-fr')) el.classList.toggle('revealed'); };
  ACT['reveal-line'] = function (el) { var f = el.querySelector('.fr'); if (f) f.classList.toggle('revealed'); };
  ACT['toggle-fr'] = function () { DZ.state.settings.hideFr = !DZ.state.settings.hideFr; DZ.store.save(); App.render(); };
  ACT['toggle-ar'] = function () { DZ.state.settings.showArabic = !DZ.state.settings.showArabic; DZ.store.save(); App.render(); };
  ACT['show-ar'] = function (el) { var s = document.getElementById('ar-slot'); if (s) s.innerHTML = T.arHtml(el.getAttribute('data-ar')); el.remove(); };
  ACT.word = function (el) { App.go('#/mot/' + encodeURIComponent(el.getAttribute('data-id'))); };
  ACT.fav = function (el) {
    var on = C.toggleFav(el.getAttribute('data-id'));
    el.classList.toggle('on', on); el.setAttribute('aria-pressed', on);
    U.toast(on ? 'Ajouté aux favoris.' : 'Retiré des favoris.');
    if (App.route === 'dico' && App.dict.filter === 'favs') renderDictResults();
  };
  ACT.hard = function (el) {
    var on = C.toggleHard(el.getAttribute('data-id'));
    el.classList.toggle('on', on); el.setAttribute('aria-pressed', on);
    U.toast(on ? 'Marqué comme difficile : il reviendra plus souvent.' : 'Retiré des mots difficiles.');
  };
  ACT.audio = function (el) {
    var dz = el.getAttribute('data-dz'), ar = el.getAttribute('data-ar');
    if (A.has(dz)) { A.play(dz); return; }
    if (A.ttsAvailable() && ar) { A.speak(ar); return; }
    audioSheet(dz, ar);
  };
  ACT['audio-sheet'] = function (el) { audioSheet(el.getAttribute('data-dz'), el.getAttribute('data-ar')); };
  ACT['line-repeat'] = function (el) {
    var dz = el.getAttribute('data-dz'), n = 0;
    (function loop() { if (n++ >= 3) return; A.play(dz).then(function (ok) { if (ok) setTimeout(loop, 900); }); })();
  };
  ACT['dict-filter'] = function (el) { App.dict.filter = el.getAttribute('data-f'); App.dict.limit = 60; App.render(); };
  ACT['dict-cat'] = function (el) { App.dict.cat = el.getAttribute('data-c'); App.dict.limit = 60; App.render(); };
  ACT['dict-more'] = function () { App.dict.limit += 100; renderDictResults(); };
  ACT['dlg-cat'] = function (el) { App.dlgCat = el.getAttribute('data-c'); App.render(); };
  ACT['dlg-mode'] = function (el) { App.dlgMode = el.getAttribute('data-m'); App.render(); };
  ACT['dlg-reveal'] = function (el) { var f = document.getElementById('dl-fr-' + el.getAttribute('data-i')); if (f) f.hidden = false; el.remove(); };
  ACT['dlg-playall'] = function () {
    var d = C.dialogueById[location.hash.split('/')[2]]; if (!d) return;
    var i = 0;
    (function nextLine() {
      document.querySelectorAll('.bubble.playing').forEach(function (b) { b.classList.remove('playing'); });
      if (i >= d.lines.length || App.route !== 'dialogue') return;
      var idx = i++, l = d.lines[idx];
      if (!A.has(l[1])) return nextLine();
      var b = document.getElementById('bub-' + idx); if (b) { b.classList.add('playing'); b.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); }
      A.play(l[1]).then(function () { setTimeout(nextLine, 500); });
    })();
  };
  ACT['dlg-answer'] = function (el) {
    var d = C.dialogueById[location.hash.split('/')[2]]; if (!d) return;
    var qi = +el.getAttribute('data-q'), o = +el.getAttribute('data-o'), q = d.q[qi];
    if (App.dlgAnswers[qi] != null) return;
    var ok = o === q.a; App.dlgAnswers[qi] = ok;
    var card = el.closest('.q-card');
    card.querySelectorAll('.opt').forEach(function (b) { b.disabled = true; if (+b.getAttribute('data-o') === q.a) b.classList.add('correct'); });
    if (!ok) el.classList.add('wrong');
    card.querySelector('.dlg-fb').innerHTML = '<div class="feedback ' + (ok ? 'ok' : 'ko') + '"><div class="fb-title">' + U.icon(ok ? 'check' : 'x') + (ok ? 'Correct !' : 'Bonne réponse : ' + T.esc(q.o[q.a])) + '</div>' + (q.e ? '<div>' + T.richHtml(q.e) + '</div>' : '') + '</div>';
    C.recordAnswer(ok);
    if (!ok) C.addMistakeItem('d:' + d.id + ':' + qi, X.gen.dialogue(d, qi), q.o[o]);
    var keys = Object.keys(App.dlgAnswers);
    if (keys.length === d.q.length) {
      var good = keys.filter(function (k) { return App.dlgAnswers[k]; }).length, pct = Math.round(good / d.q.length * 100);
      var rec = DZ.state.dialogues[d.id] || (DZ.state.dialogues[d.id] = {});
      var first = !rec.done; rec.done = rec.done || Date.now(); rec.best = Math.max(rec.best || 0, pct);
      if (first) C.addXp(5); DZ.store.save();
      U.toast('Dialogue terminé : ' + good + '/' + d.q.length + ' bonnes réponses.');
    }
  };
  ACT['lesson-practice'] = function (el) {
    var l = C.lessonById[el.getAttribute('data-id')];
    var mk = function () {
      return { title: l.t, items: X.lessonItems(l), back: '#/lecon/' + l.id, rebuild: mk,
        onDone: function (pct) { var was = C.lessonDone(l.id); C.setLessonDone(l.id, pct >= 70 || was, pct); if (pct >= 70 && !was) U.toast('Leçon terminée ! Ses mots rejoignent vos révisions.'); } };
    };
    X.start(mk());
  };
  ACT['lesson-done'] = function (el) {
    var id = el.getAttribute('data-id'), done = C.lessonDone(id);
    C.setLessonDone(id, !done); U.toast(done ? 'Leçon marquée comme non terminée.' : 'Leçon terminée ! Ses mots rejoignent vos révisions.'); App.render();
  };
  ACT['lesson-srs'] = function (el) {
    var l = C.lessonById[el.getAttribute('data-id')], n = 0;
    l.entries.forEach(function (e) { if (!DZ.state.srs[e.id]) { C.srsAdd(e.id); n++; } });
    U.toast(n ? n + ' mot(s) ajouté(s) à vos révisions.' : 'Ces mots sont déjà dans vos révisions.'); updateDueDot();
  };
  ACT['grammar-practice'] = function (el) {
    var g = C.grammarById[el.getAttribute('data-id')];
    var mk = function () { return { title: g.t, items: X.grammarItems(g), back: '#/grammaire/' + g.id, rebuild: mk, onDone: function (pct) { if (pct >= 70) { DZ.state.grammar[g.id] = { done: Date.now() }; DZ.store.save(); } } }; };
    X.start(mk());
  };
  ACT['grammar-done'] = function (el) {
    var id = el.getAttribute('data-id'), r = DZ.state.grammar[id];
    if (r && r.done) delete DZ.state.grammar[id]; else { DZ.state.grammar[id] = { done: Date.now() }; C.addXp(3); }
    DZ.store.save(); App.render();
  };
  ACT['srs-add'] = function (el) { C.srsAdd(el.getAttribute('data-id')); U.toast('Ajouté à vos révisions.'); App.render(); };
  ACT['srs-remove'] = function (el) { C.srsRemove(el.getAttribute('data-id')); U.toast('Retiré des révisions.'); App.render(); };
  ACT['word-practice'] = function (el) {
    var e = C.byId[el.getAttribute('data-id')];
    var items = [X.gen.mcqDzFr(e), X.gen.inputFrDz(e), X.gen.mcqFrDz(e), X.gen.fill(e)].filter(Boolean);
    X.start({ title: e.d, items: items, back: '#/mot/' + encodeURIComponent(e.id) });
  };
  ACT['custom-delete'] = function (el) {
    var id = el.getAttribute('data-id');
    U.confirm({ title: 'Supprimer ce mot ?', text: 'Il sera retiré de votre dictionnaire et de vos révisions.', ok: 'Supprimer', danger: true }).then(function (yes) {
      if (!yes) return;
      DZ.state.custom = DZ.state.custom.filter(function (c) { return c.id !== id; });
      delete DZ.state.srs[id]; delete DZ.state.favs[id]; delete DZ.state.hard[id];
      DZ.store.save(); C.refreshCustom(); U.toast('Mot supprimé.'); App.go('#/dico', true);
    });
  };
  ACT['review-start'] = function (el) { X.startReview(+el.getAttribute('data-min')); };
  ACT['review-cram'] = function () { X.startReview(10, true); };
  ACT['review-flip'] = function () { X.flip(); };
  ACT['review-grade'] = function (el) { X.grade(+el.getAttribute('data-g')); };
  ACT['review-quit'] = function () { X.review = null; App.go('#/pratique'); };
  ACT['start-mistakes'] = function () {
    var items = X.mistakeItems(15);
    if (!items.length) { U.toast('Aucune erreur à revoir. Bravo !'); return; }
    X.start({ title: 'Révision des erreurs', items: items, mode: 'practice', back: '#/pratique' });
  };
  ACT['pr-scope'] = function (el) {
    var s = el.getAttribute('data-s'), p = App.practice;
    p.scope = s === 'all' ? {} : /^s\d$/.test(s) ? { stage: +s[1] } : s === 'favs' ? { favs: 1 } : s === 'hard' ? { hard: 1 } : s === 'custom' ? { custom: 1 } : {};
    App.render();
  };
  ACT['pr-n'] = function (el) { App.practice.n = +el.getAttribute('data-n'); App.render(); };
  ACT['pr-start'] = function (el) {
    var t = el.getAttribute('data-t'), p = App.practice, scope = JSON.parse(JSON.stringify(p.scope));
    var type = X.TYPES.filter(function (x) { return x.id === t; })[0];
    var mk = function () { return { title: type.label + ' · ' + X.scopeLabel(scope), items: X.build(t, scope, p.n), back: '#/pratique', rebuild: mk, scope: scope }; };
    X.start(mk());
  };
  ACT['exam-stage'] = function (el) { App.exam.stage = +el.getAttribute('data-s'); App.render(); };
  ACT['exam-n'] = function (el) { App.exam.n = +el.getAttribute('data-n'); DZ.state.settings.examSize = App.exam.n; DZ.store.save(); App.render(); };
  ACT['exam-start'] = function () {
    var o = App.exam, label = 'Examen · ' + (o.stage ? 'Étape ' + o.stage : 'tout le contenu');
    var mk = function () { return { title: label, items: buildExam(o.stage, o.n), mode: 'exam', back: '#/examen', rebuild: mk }; };
    X.start(mk());
  };
  ACT['session-quit'] = function () {
    var s = X.session; if (!s) return App.go('#/pratique');
    if (s.results.length && s.i < s.items.length) {
      U.confirm({ title: 'Quitter la série ?', text: 'Vos réponses déjà données sont comptées.', ok: 'Quitter', cancel: 'Continuer' }).then(function (y) { if (y) { var b = s.back; X.session = null; App.go(b); } });
    } else { var b = s.back; X.session = null; App.go(b); }
  };
  ACT['ex-check'] = function () { X.checkCurrent(); };
  ACT['ex-skip'] = function () { X.skipCurrent(); };
  ACT['ex-next'] = function () { X.next(); };
  ACT['ex-self'] = function (el) { X.selfAssess(el.getAttribute('data-ok') === '1'); };
  ACT['ord-clear'] = function () { X.clearOrder(); };
  ACT['ex-retry-errors'] = function () { X.retryErrors(); };
  ACT['ex-again'] = function () { X.again(); };
  ACT['ex-done'] = function () { var b = X.session ? X.session.back : '#/pratique'; X.session = null; App.go(b); };
  ACT['note-delete'] = function (el) {
    var id = el.getAttribute('data-id');
    U.confirm({ title: 'Supprimer cette note ?', ok: 'Supprimer', danger: true }).then(function (y) {
      if (!y) return; DZ.state.notes = DZ.state.notes.filter(function (n) { return n.id !== id; }); DZ.store.save(); App.go('#/notes', true);
    });
  };
  ACT['set-theme'] = function (el) { DZ.state.settings.theme = el.getAttribute('data-t'); DZ.store.save(); applyTheme(); App.render(); };
  ACT['set-num'] = function (el) { DZ.state.settings[el.getAttribute('data-k')] = +el.getAttribute('data-v'); DZ.store.save(); App.render(); };
  ACT.persist = function () {
    DZ.store.persist().then(function (ok) { U.toast(ok ? 'Protection activée : le navigateur ne doit plus effacer vos données automatiquement.' : 'Le navigateur n\'a pas accordé la protection. Installez l\'application et exportez régulièrement une sauvegarde.'); App.render(); });
  };
  ACT['audio-clear'] = function () {
    U.confirm({ title: 'Supprimer tous les enregistrements ?', text: 'Cette action est définitive.', ok: 'Tout supprimer', danger: true }).then(function (y) {
      if (!y) return; DZ.store.audioClear().then(function () { A.clearCache(); U.toast('Enregistrements supprimés.'); App.render(); });
    });
  };
  ACT['reset-progress'] = function () {
    U.confirm({ title: 'Réinitialiser les progrès ?', text: 'Leçons terminées, scores, révisions, erreurs, statistiques et historique seront effacés. Vos réglages, mots personnels, favoris, notes et enregistrements sont conservés.', ok: 'Réinitialiser', danger: true, typeWord: 'EFFACER' }).then(function (y) {
      if (!y) return;
      var st = DZ.state, d = DZ.store.defaultState();
      ['lessons', 'grammar', 'dialogues', 'srs', 'hard', 'history', 'mistakes', 'activity', 'exams', 'stats'].forEach(function (k) { st[k] = d[k]; });
      DZ.store.saveNow(); C.markOpen(); U.toast('Progrès réinitialisés.'); App.go('#/', true);
    });
  };
  ACT['reset-all'] = function () {
    U.confirm({ title: 'Tout effacer ?', text: 'Progrès, réglages, mots personnels, notes, favoris et enregistrements audio seront supprimés de cet appareil. Exportez d\'abord une sauvegarde si besoin.', ok: 'Tout effacer', danger: true, typeWord: 'EFFACER' }).then(function (y) {
      if (!y) return;
      DZ.store.resetAll(false).then(function () { A.clearCache(); C.refreshCustom(); applyTheme(); C.markOpen(); U.toast('Toutes les données ont été effacées.'); App.go('#/', true); });
    });
  };
  ACT.export = function () {
    var withAudio = document.getElementById('exp-audio') && document.getElementById('exp-audio').checked;
    DZ.store.exportData(withAudio).then(function (data) {
      var json = JSON.stringify(data), name = 'darija-dz-sauvegarde-' + C.today() + '.json';
      // Dans la visionneuse d'aperçu (claude.ai), l'enregistrement passe par la capacité « downloads » ;
      // partout ailleurs (application installée, fichier autonome), par un téléchargement classique.
      var p = App.downloads
        ? App.downloads.save({ filename: name, data: json }).then(function () { return 'saved'; }, function (err) { return err && err.code === 'declined' ? 'declined' : 'failed'; })
        : Promise.resolve(U.download(name, json) ? 'saved' : 'failed');
      return p.then(function (status) {
      if (status === 'saved') { DZ.state.lastExport = Date.now(); DZ.store.save(); }
      var fb = document.getElementById('export-fallback');
      var msg = status === 'saved' ? 'Fichier « ' + T.esc(name) + ' » créé. Vérifiez vos téléchargements.' : status === 'declined' ? 'Enregistrement annulé.' : 'Le fichier n\'a pas pu être enregistré ici : copiez le contenu ci-dessous.';
      if (fb) fb.innerHTML = '<p class="small" style="color:' + (status === 'saved' ? 'var(--ok)' : 'var(--amber)') + '">' + msg + '</p>' +
        '<details' + (status === 'failed' ? ' open' : '') + '><summary class="small" style="cursor:pointer;color:var(--green);font-weight:650">Le téléchargement n\'a pas démarré ? Copier le contenu</summary><div style="display:flex;flex-direction:column;gap:8px;margin-top:8px"><textarea class="input" id="exp-text" readonly style="min-height:120px;font-family:monospace;font-size:.75rem">' + T.esc(json) + '</textarea><button class="btn btn-secondary btn-sm" data-act="copy-export">Copier</button><span class="tiny muted">Collez ce texte dans un fichier « .json » ou une note sécurisée.</span></div></details>';
      });
    }).catch(function (e) { U.toast('Export impossible : ' + (e && e.message)); });
  };
  ACT['copy-export'] = function () {
    var ta = document.getElementById('exp-text'); if (!ta) return;
    var done = function () { U.toast('Sauvegarde copiée.'); };
    try {
      navigator.clipboard.writeText(ta.value).then(done, function () { ta.select(); document.execCommand('copy'); done(); });
    } catch (e) { ta.select(); try { document.execCommand('copy'); done(); } catch (e2) { U.toast('Sélectionnez le texte et copiez-le manuellement.'); } }
  };
  ACT['import-text'] = function () { var t = document.getElementById('imp-text'); if (t && t.value.trim()) tryImport(t.value.trim()); };

  function onClick(e) {
    var el = e.target.closest('[data-act]');
    if (!el) return;
    var a = el.getAttribute('data-act');
    if (ACT[a]) { if (el.tagName === 'A') e.preventDefault(); ACT[a](el, e); }
  }
  function onChange(e) {
    var t = e.target;
    if (t.matches('[data-setting]')) {
      var k = t.getAttribute('data-setting');
      if (k in DZ.state.settings) {
        DZ.state.settings[k] = t.checked; DZ.store.save();
        if (k === 'tts' && t.checked && !A.ttsVoice()) U.toast('Aucune voix arabe trouvée sur cet appareil.');
        App.render();
      }
    }
    if (t.id === 'pr-cat') { App.practice.scope = t.value ? { cat: t.value } : {}; App.render(); }
  }

  /* ---------- Hors ligne (service worker) ---------- */
  function registerSW() {
    if (window.DZ_STANDALONE || !('serviceWorker' in navigator) || !/^https?:$/.test(location.protocol)) return;
    navigator.serviceWorker.register('sw.js').then(function (reg) {
      reg.addEventListener('updatefound', function () {
        var nw = reg.installing; if (!nw) return;
        nw.addEventListener('statechange', function () {
          if (nw.state === 'installed' && navigator.serviceWorker.controller) {
            var b = document.createElement('div'); b.className = 'toast'; b.style.display = 'flex'; b.style.gap = '10px'; b.style.alignItems = 'center';
            b.innerHTML = '<span>Nouvelle version disponible.</span><button class="btn btn-sm btn-primary" id="sw-reload">Recharger</button>';
            document.body.appendChild(b);
            b.querySelector('#sw-reload').onclick = function () { DZ.store.saveNow().then(function () { location.reload(); }); };
          }
        });
      });
    }).catch(function (e) { console.warn('Service worker non enregistré', e); });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', App.boot); else App.boot();
})();
