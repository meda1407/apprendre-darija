/* Darija DZ — composants d'interface : icônes, notifications, fenêtres, lignes de vocabulaire. */
(function () {
  'use strict';
  var DZ = window.DZ, T = DZ.text;
  var U = (DZ.ui = {});

  var P = {
    home: '<path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V20h5v-6h4v6h5V9.5"/>',
    book: '<path d="M4 4.5A2.5 2.5 0 0 1 6.5 2H20v17H6.5A2.5 2.5 0 0 0 4 21.5z"/><path d="M4 21.5A2.5 2.5 0 0 1 6.5 19H20"/><path d="M9 7h7M9 11h5"/>',
    target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.5"/>',
    dict: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="m20 20-4.8-4.8"/>',
    more: '<circle cx="5" cy="12" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="19" cy="12" r="1.6"/>',
    chat: '<path d="M4 5h16v10H9l-5 4z"/><path d="M8 9h8M8 12h5"/>',
    layers: '<path d="m12 3 9 5-9 5-9-5z"/><path d="m3 13 9 5 9-5"/>',
    chart: '<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>',
    note: '<path d="M5 3h10l4 4v14H5z"/><path d="M15 3v4h4M8 12h8M8 16h6"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
    help: '<circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.5 2.5 0 1 1 3.5 2.3c-.6.3-1 .9-1 1.6V14"/><circle cx="12" cy="17.5" r=".6"/>',
    star: '<path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1 6.2L12 17.3 6.5 20.2l1-6.2L3 9.6l6.2-.9z"/>',
    flag: '<path d="M5 21V4M5 4h11l-2 4 2 4H5"/>',
    play: '<path d="M7 4.5v15l12-7.5z"/>',
    pause: '<path d="M7 4h3.5v16H7zM13.5 4H17v16h-3.5z"/>',
    stop: '<rect x="6" y="6" width="12" height="12" rx="2"/>',
    mic: '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3"/>',
    volume: '<path d="M4 9h4l5-4v14l-5-4H4z"/><path d="M16.5 8.5a5 5 0 0 1 0 7M19 6a8.5 8.5 0 0 1 0 12"/>',
    repeat: '<path d="M17 2l3 3-3 3"/><path d="M4 11V9a4 4 0 0 1 4-4h12"/><path d="M7 22l-3-3 3-3"/><path d="M20 13v2a4 4 0 0 1-4 4H4"/>',
    eye: '<path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    eyeoff: '<path d="M3 3l18 18M10.6 5.1A10 10 0 0 1 12 5c6.4 0 10 7 10 7a17 17 0 0 1-3.2 4M6.6 6.6A17 17 0 0 0 2 12s3.6 7 10 7a9.6 9.6 0 0 0 5.4-1.6"/><path d="M9.9 9.9a3 3 0 0 0 4.2 4.2"/>',
    check: '<path d="m4 12.5 5 5L20 6.5"/>',
    x: '<path d="M6 6l12 12M18 6 6 18"/>',
    right: '<path d="m9 5 7 7-7 7"/>',
    left: '<path d="m15 5-7 7 7 7"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
    download: '<path d="M12 3v12M7 10l5 5 5-5M4 20h16"/>',
    upload: '<path d="M12 16V4M7 9l5-5 5 5M4 20h16"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
    moon: '<path d="M20 14.5A8.5 8.5 0 1 1 9.5 4a7 7 0 0 0 10.5 10.5z"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    fire: '<path d="M12 22c4 0 7-2.7 7-7 0-3.2-2-5.5-3.5-7-.3 1.8-1.2 3-2.5 3.5.2-3-1.3-6.2-4-8.5 0 3.5-4 6.5-4 12 0 4.3 3 7 7 7z"/>',
    refresh: '<path d="M20 11a8 8 0 1 0-2.3 5.7"/><path d="M20 4v7h-7"/>',
    bolt: '<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>',
    cards: '<rect x="3" y="6" width="14" height="15" rx="2"/><path d="M7 3h12a2 2 0 0 1 2 2v13"/>',
    exam: '<path d="M9 3h6l1 2h3v16H5V5h3z"/><path d="m9 13 2 2 4-4"/>',
    shuffle: '<path d="M16 3h5v5M4 20 21 3M21 16v5h-5M15 15l6 6M4 4l5 5"/>',
    link: '<path d="M10 14a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1 1"/><path d="M14 10a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l1-1"/>',
    order: '<path d="M4 6h10M4 12h16M4 18h7"/>',
    blank: '<path d="M3 17h5M10 17h11M3 11h18M3 5h18"/>',
    pen: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="m13.5 6.5 4 4"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5v.5"/>',
    alert: '<path d="M12 3 2 20h20z"/><path d="M12 10v4M12 17v.5"/>',
    bulb: '<path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-3.6 10.8c.6.5 1 1.2 1 2V16h5.2v-.2c0-.8.4-1.5 1-2A6 6 0 0 0 12 3z"/>',
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.5 2.6 3.7 5.6 3.7 9s-1.2 6.4-3.7 9c-2.5-2.6-3.7-5.6-3.7-9S9.5 5.6 12 3z"/>',
    lock: '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
    phone: '<rect x="7" y="2" width="10" height="20" rx="2"/><path d="M11 18h2"/>',
    history: '<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5M12 7v5l3 2"/>',
    ar: '<path d="M4 18c3 0 5-1.5 5-4.5V6M9 13.5c0 2 1.5 3 3 3s3-1 3-3V9M18 6v9.5c0 1.5.5 2.5 2 2.5"/>'
  };

  U.icon = function (name, cls) {
    return '<svg class="i ' + (cls || '') + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (P[name] || '') + '</svg>';
  };

  /* ---------- Notifications ---------- */
  var toastTimer = null;
  U.toast = function (msg) {
    var old = document.querySelector('.toast'); if (old) old.remove();
    var el = document.createElement('div'); el.className = 'toast'; el.setAttribute('role', 'status'); el.textContent = msg;
    document.body.appendChild(el);
    clearTimeout(toastTimer); toastTimer = setTimeout(function () { el.remove(); }, 2600);
  };

  /* ---------- Fenêtres ---------- */
  U.sheet = function (html, opts) {
    opts = opts || {};
    U.closeSheet();
    var ov = document.createElement('div'); ov.className = 'overlay'; ov.id = 'overlay';
    ov.innerHTML = '<div class="sheet" role="dialog" aria-modal="true">' + html + '</div>';
    ov.addEventListener('click', function (e) { if (e.target === ov && !opts.modal) U.closeSheet(); });
    document.body.appendChild(ov);
    var first = ov.querySelector('[autofocus], input, textarea, button'); if (first) setTimeout(function () { try { first.focus(); } catch (e) { /* ignoré */ } }, 50);
    U.onSheetClose = opts.onClose || null;
    return ov.querySelector('.sheet');
  };
  U.closeSheet = function () {
    var ov = document.getElementById('overlay'); if (ov) ov.remove();
    if (U.onSheetClose) { var f = U.onSheetClose; U.onSheetClose = null; f(); }
  };
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') U.closeSheet(); });

  // Confirmation (remplace confirm(), bloqué dans certains contextes)
  U.confirm = function (o) {
    return new Promise(function (resolve) {
      var needs = o.typeWord;
      var sh = U.sheet(
        '<h3>' + T.esc(o.title) + '</h3>' +
        (o.text ? '<p class="muted">' + T.esc(o.text) + '</p>' : '') +
        (needs ? '<div class="field"><label for="cf-word">Tapez « ' + T.esc(needs) + ' » pour confirmer</label><input id="cf-word" class="input" autocomplete="off"></div>' : '') +
        '<div class="btn-row"><button class="btn btn-secondary" data-r="0">' + T.esc(o.cancel || 'Annuler') + '</button>' +
        '<button class="btn ' + (o.danger ? 'btn-danger' : 'btn-primary') + '" data-r="1"' + (needs ? ' disabled' : '') + '>' + T.esc(o.ok || 'Confirmer') + '</button></div>',
        { modal: true });
      var okBtn = sh.querySelector('[data-r="1"]');
      if (needs) {
        sh.querySelector('#cf-word').addEventListener('input', function (e) {
          okBtn.disabled = e.target.value.trim().toUpperCase() !== needs.toUpperCase();
        });
      }
      sh.addEventListener('click', function (e) {
        var b = e.target.closest('[data-r]'); if (!b) return;
        U.closeSheet(); resolve(b.getAttribute('data-r') === '1');
      });
    });
  };

  /* ---------- Composants ---------- */
  U.badges = function (e) {
    var out = '';
    if (e.u) out += '<span class="badge verify" title="Forme ou sens à vérifier auprès d\'un locuteur natif">à vérifier</span>';
    if (e.r) out += '<span class="badge grey">' + T.esc(e.r) + '</span>';
    if (e.custom) out += '<span class="badge green">mon mot</span>';
    return out;
  };

  U.frSpan = function (text, extraCls) {
    return '<span class="fr maskable ' + (extraCls || '') + '" data-act="reveal">' + T.esc(text) + '</span>';
  };

  // Bouton audio : lecture si un enregistrement existe, sinon ouvre les options d'enregistrement
  U.audioBtn = function (dz, ar, small) {
    var has = DZ.audio.has(dz);
    var tts = !has && DZ.audio.ttsAvailable() && ar;
    var cls = 'icon-btn ' + (small ? 'sm ' : '') + (has ? 'has-audio' : tts ? 'has-audio' : 'no-audio');
    var label = has ? 'Écouter' : tts ? 'Écouter (voix de synthèse approximative)' : 'Ajouter une prononciation';
    return '<button class="' + cls + '" data-act="audio" data-dz="' + T.esc(dz) + '" data-ar="' + T.esc(ar || '') + '" aria-label="' + label + '" title="' + label + '">' +
      U.icon(has || tts ? 'volume' : 'mic') + '</button>';
  };

  U.wordRow = function (e, opts) {
    opts = opts || {};
    var st = DZ.state, fav = !!st.favs[e.id];
    var showAr = st.settings.showArabic && e.ar;
    return '<div class="row" data-id="' + T.esc(e.id) + '">' +
      '<div class="row-main" data-act="word" data-id="' + T.esc(e.id) + '" role="button" tabindex="0">' +
      '<span class="row-dz dz">' + T.dzHtml(e.d) + '</span>' +
      (showAr ? T.arHtml(e.ar) : '') +
      '<span class="row-fr">' + U.frSpan(e.fr) + '</span>' +
      ((opts.meta !== false && (e.u || e.r || e.custom || opts.cat)) ? '<span class="row-meta">' + (opts.cat && DZ.core.catById[e.cat] ? '<span class="badge grey">' + T.esc(DZ.core.catById[e.cat].label) + '</span>' : '') + U.badges(e) + '</span>' : '') +
      '</div><div class="row-acts">' + U.audioBtn(e.d, e.ar, true) +
      '<button class="icon-btn sm star ' + (fav ? 'on' : '') + '" data-act="fav" data-id="' + T.esc(e.id) + '" aria-label="' + (fav ? 'Retirer des favoris' : 'Ajouter aux favoris') + '" aria-pressed="' + fav + '">' + U.icon('star') + '</button>' +
      '</div></div>';
  };

  U.phraseRow = function (p) {
    // p = [darija, français, contexte]
    return '<div class="row phrase">' +
      '<div class="row-main"><span class="row-dz dz">' + T.dzHtml(p[0]) + '</span>' +
      '<span class="row-fr">' + U.frSpan(p[1]) + '</span>' +
      (p[2] ? '<span class="row-ctx">' + T.esc(p[2]) + '</span>' : '') + '</div>' +
      '<div class="row-acts">' + U.audioBtn(p[0], '', true) + '</div></div>';
  };

  U.blocks = function (blocks) {
    return '<div class="blocks">' + (blocks || []).map(function (b) {
      if (b.k === 'p') return '<p>' + T.richHtml(b.x) + '</p>';
      if (b.k === 'tip') return '<div class="callout tip">' + U.icon('bulb') + '<div><b class="cl">Astuce</b>' + T.richHtml(b.x) + '</div></div>';
      if (b.k === 'note') return '<div class="callout note">' + U.icon('globe') + '<div><b class="cl">Culture</b>' + T.richHtml(b.x) + '</div></div>';
      if (b.k === 'warn') return '<div class="callout warn">' + U.icon('alert') + '<div><b class="cl">Variantes et prudence</b>' + T.richHtml(b.x) + '</div></div>';
      if (b.k === 'table') {
        return '<div class="table-wrap"><table class="t' + (b.h.length >= 4 ? ' wide' : '') + '"><thead><tr>' + b.h.map(function (h) { return '<th>' + T.esc(h) + '</th>'; }).join('') +
          '</tr></thead><tbody>' + b.r.map(function (r) {
            return '<tr>' + r.map(function (c) { return '<td>' + T.richHtml(c) + '</td>'; }).join('') + '</tr>';
          }).join('') + '</tbody></table></div>';
      }
      if (b.k === 'story') {
        return '<div class="story">' + b.x.map(function (l) {
          return '<div class="story-line" data-act="reveal-line"><div class="dz">' + T.dzHtml(l[0]) + '</div><div class="fr maskable">' + T.esc(l[1]) + '</div></div>';
        }).join('') + '</div>';
      }
      return '';
    }).join('') + '</div>';
  };

  U.empty = function (icon, title, text, actionHtml) {
    return '<div class="empty">' + U.icon(icon) + '<b>' + T.esc(title) + '</b>' + (text ? '<span class="small">' + T.esc(text) + '</span>' : '') + (actionHtml || '') + '</div>';
  };

  U.switchRow = function (id, title, desc, checked) {
    return '<div class="switch-row"><div class="sw-text"><b>' + T.esc(title) + '</b>' + (desc ? '<span>' + T.esc(desc) + '</span>' : '') + '</div>' +
      '<label class="switch"><input type="checkbox" id="' + id + '" data-setting="' + id.replace(/^set-/, '') + '"' + (checked ? ' checked' : '') + ' aria-label="' + T.esc(title) + '"><span></span></label></div>';
  };

  // Téléchargement d'un fichier généré localement (repli : afficher le contenu à copier)
  U.download = function (filename, text, mime) {
    try {
      var blob = new Blob([text], { type: mime || 'application/json' });
      var url = URL.createObjectURL(blob);
      var a = document.createElement('a'); a.href = url; a.download = filename; a.rel = 'noopener';
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(function () { URL.revokeObjectURL(url); }, 4000);
      return true;
    } catch (e) { return false; }
  };
})();
