/* Darija DZ — texte : normalisation, recherche tolérante, correction des réponses, rendu HTML. */
(function () {
  'use strict';
  var DZ = window.DZ;
  var T = (DZ.text = {});

  // Échappement HTML
  T.esc = function (s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  };

  function stripAccents(s) {
    return s.normalize('NFD').replace(/[̀-ͯ]/g, '');
  }

  /* Normalisation de la darija écrite en lettres latines.
     Les chiffres 2, 3, 7, 9 restent intacts (ce sont des lettres).
     Variantes rapprochées : 5→kh, dj→j, q→9, ou/o/u → u, doublons, ponctuation, apostrophes. */
  T.normDz = function (s) {
    s = stripAccents(String(s || '').toLowerCase());
    s = s.replace(/[’'`´ʼ]/g, '').replace(/[«»"“”.,;:!?¿¡()\[\]{}…—–\/]/g, ' ').replace(/-/g, ' ');
    s = s.replace(/5/g, 'kh').replace(/dj/g, 'j').replace(/q/g, '9').replace(/ou/g, 'u').replace(/o/g, 'u');
    s = s.replace(/([a-z])\1+/g, '$1');
    s = s.replace(/\s+/g, ' ').trim();
    return s;
  };

  // Squelette consonantique : sans voyelles ni espaces (tolère labes/labas, chkoun/chkon…)
  T.skelDz = function (s) {
    return T.normDz(s).replace(/[aeiu ]/g, '').replace(/([a-z0-9])\1+/g, '$1');
  };

  // Normalisation du français
  T.normFr = function (s) {
    s = stripAccents(String(s || '').toLowerCase());
    s = s.replace(/[’'`´]/g, ' ').replace(/[«»"“”.,;:!?¿¡()\[\]{}…—–\/-]/g, ' ');
    s = s.replace(/\b(le|la|les|l|un|une|des|du|de|d)\b/g, ' ');
    return s.replace(/\s+/g, ' ').trim();
  };

  // Distance de Levenshtein
  T.lev = function (a, b) {
    if (a === b) return 0;
    var m = a.length, n = b.length;
    if (!m) return n; if (!n) return m;
    var prev = new Array(n + 1), cur = new Array(n + 1), i, j;
    for (j = 0; j <= n; j++) prev[j] = j;
    for (i = 1; i <= m; i++) {
      cur[0] = i;
      for (j = 1; j <= n; j++) {
        var c = a.charCodeAt(i - 1) === b.charCodeAt(j - 1) ? 0 : 1;
        cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + c);
      }
      var t = prev; prev = cur; cur = t;
    }
    return prev[n];
  };

  function digitsOf(s) { return (s.match(/[23579]/g) || []).join(''); }

  /* Vérifie une réponse en darija.
     Retour : { ok: bool, level: 'exact'|'variant'|'typo'|'wrong', expected } */
  T.checkDz = function (given, answers) {
    var g = T.normDz(given);
    if (!g) return { ok: false, level: 'wrong', expected: answers[0] };
    var gs = T.skelDz(given), gNoSp = g.replace(/ /g, '');
    var best = null;
    for (var i = 0; i < answers.length; i++) {
      var a = T.normDz(answers[i]);
      if (g === a) return { ok: true, level: 'exact', expected: answers[i] };
      if (gNoSp === a.replace(/ /g, '')) best = best || { ok: true, level: 'variant', expected: answers[i] };
      if (gs && gs.length >= 3 && gs === T.skelDz(answers[i])) best = best || { ok: true, level: 'variant', expected: answers[i] };
    }
    if (best) return best;
    for (i = 0; i < answers.length; i++) {
      a = T.normDz(answers[i]);
      var d = T.lev(g, a);
      var tol = a.length >= 10 ? 2 : a.length >= 4 ? 1 : 0;
      // Une faute de frappe est tolérée, mais pas un chiffre-lettre (3, 7, 9…) oublié ou changé.
      if (d <= tol && digitsOf(g) === digitsOf(a)) return { ok: true, level: 'typo', expected: answers[i] };
    }
    return { ok: false, level: 'wrong', expected: answers[0] };
  };

  // Alternatives d'une traduction française : « salut ! ; merci ; bravo (lit. santé) »
  T.frAlternatives = function (fr) {
    var base = String(fr || '').replace(/\([^)]*\)/g, ' ');
    var parts = base.split(/[;\/,]| ou /);
    var out = [];
    parts.forEach(function (p) { var n = T.normFr(p); if (n && out.indexOf(n) < 0) out.push(n); });
    var whole = T.normFr(base); if (whole && out.indexOf(whole) < 0) out.push(whole);
    // La traduction complète, parenthèses comprises, est aussi acceptée
    var full = T.normFr(fr); if (full && out.indexOf(full) < 0) out.push(full);
    String(fr || '').split(/[;\/]/).forEach(function (p) { var n = T.normFr(p); if (n && out.indexOf(n) < 0) out.push(n); });
    return out;
  };

  /* Vérifie une réponse en français. level 'maybe' = proche mais incertain : l'utilisateur s'auto-évalue. */
  T.checkFr = function (given, frList) {
    var g = T.normFr(given);
    if (!g) return { ok: false, level: 'wrong' };
    var alts = [];
    frList.forEach(function (f) { alts = alts.concat(T.frAlternatives(f)); });
    for (var i = 0; i < alts.length; i++) {
      if (g === alts[i]) return { ok: true, level: 'exact' };
      var tol = alts[i].length >= 8 ? 2 : 1;
      if (T.lev(g, alts[i]) <= tol) return { ok: true, level: 'typo' };
    }
    var gw = g.split(' ').filter(function (w) { return w.length > 2; });
    for (i = 0; i < alts.length; i++) {
      var aw = alts[i].split(' ').filter(function (w) { return w.length > 2; });
      if (!aw.length || !gw.length) continue;
      var common = aw.filter(function (w) { return gw.indexOf(w) >= 0; }).length;
      if (common / aw.length >= 0.6) return { ok: false, level: 'maybe' };
    }
    return { ok: false, level: 'wrong' };
  };

  /* Rendu de la darija : met en valeur les chiffres-lettres (2 3 5 7 9) à l'intérieur des mots.
     Les nombres isolés (25, 2020…) ne sont pas modifiés. */
  T.dzHtml = function (s) {
    var hl = !DZ.state || !DZ.state.settings || DZ.state.settings.highlight !== false;
    var e = T.esc(s);
    if (!hl) return e;
    if (/^[23579]$/.test(String(s).trim())) return '<b class="snd">' + e + '</b>';
    return e.replace(/[A-Za-zÀ-ÿ0-9]+/g, function (w) {
      if (!/[A-Za-zÀ-ÿ]/.test(w)) return w;
      return w.replace(/[23579]/g, function (d) { return '<b class="snd">' + d + '</b>'; });
    });
  };

  // Texte français contenant de la darija entre `accents graves`
  T.richHtml = function (s) {
    var parts = String(s || '').split('`');
    return parts.map(function (p, i) {
      return i % 2 ? '<span class="dz-inline">' + T.dzHtml(p) + '</span>' : T.esc(p);
    }).join('');
  };

  T.arHtml = function (s) {
    return s ? '<span class="ar" dir="rtl" lang="ar">' + T.esc(s) + '</span>' : '';
  };

  // Mélange (Fisher-Yates)
  T.shuffle = function (arr) {
    var a = arr.slice();
    for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(Math.random() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; }
    return a;
  };

  T.slug = function (s) {
    return T.normDz(s).replace(/ /g, '-');
  };

  // Découpe une phrase darija en mots (pour l'exercice « remettre dans l'ordre »)
  T.words = function (s) {
    return String(s || '').replace(/[«»"“”.,;:!?¿¡…—–()]/g, ' ').split(/\s+/).filter(Boolean);
  };

  // Clé d'enregistrement audio : un même texte darija partage le même enregistrement partout
  T.audioKey = function (dz) { return 'a:' + T.normDz(dz); };
})();
