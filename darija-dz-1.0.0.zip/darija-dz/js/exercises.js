/* Darija DZ — exercices, examens et révision espacée. Tout est généré localement à partir du contenu. */
(function () {
  'use strict';
  var DZ = window.DZ, T = DZ.text, C = DZ.core, U = DZ.ui;
  var X = (DZ.ex = {});

  /* ---------- Détection de la langue d'une option (pour l'affichage) ---------- */
  var dzTok = null, ndSet = null;
  var FR_STOP = ['le', 'la', 'les', 'un', 'une', 'des', 'du', 'je', 'tu', 'il', 'elle', 'nous', 'vous', 'ils', 'elles', 'est', 'et', 'au', 'aux',
    'pour', 'avec', 'pas', 'ne', 'ce', 'que', 'qui', 'en', 'dans', 'sur', 'mon', 'ma', 'mes', 'ton', 'ta', 'son', 'sa', 'très', 'plus', 'quand',
    'comment', 'pourquoi', 'combien', 'tout', 'rien', 'oui', 'merci', 'demain', 'hier', 'jour', 'heure', 'heures', 'moins', 'quart', 'deux', 'trois'];
  function buildDetect() {
    dzTok = {}; ndSet = {};
    C.entries.forEach(function (e) {
      ndSet[e.nd] = 1; e.nv.forEach(function (v) { ndSet[v] = 1; });
      (e.nd + ' ' + e.nv.join(' ') + ' ' + T.normDz(e.exd)).split(' ').forEach(function (w) { if (w) dzTok[w] = 1; });
    });
  }
  X.looksDz = function (s) {
    if (!dzTok) buildDetect();
    s = String(s || '');
    if (/[a-z][23579]|[23579][a-z]/i.test(s)) return true;
    var nd = T.normDz(s);
    if (ndSet[nd]) return true;
    if (/[éèêàçùûôîœ]/i.test(s)) return false;
    var raw = s.toLowerCase().replace(/[^a-z0-9' -]/g, ' ').split(/\s+/).filter(Boolean);
    if (raw.some(function (w) { return FR_STOP.indexOf(w) >= 0; })) return false;
    var ws = nd.split(' ').filter(Boolean);
    if (!ws.length) return false;
    return ws.filter(function (w) { return dzTok[w]; }).length / ws.length >= 0.6;
  };

  function uniq(list) {
    var seen = {}; return list.filter(function (e) { if (!e || seen[e.id]) return false; seen[e.id] = 1; return true; });
  }
  function pick(list, n) { return T.shuffle(list).slice(0, n); }

  /* ---------- Ensembles de mots ---------- */
  X.scopeLabel = function (scope) {
    scope = scope || {};
    if (scope.lesson) return 'Leçon : ' + C.lessonById[scope.lesson].t;
    if (scope.stage) return 'Étape ' + scope.stage;
    if (scope.cat) return 'Thème : ' + (C.catById[scope.cat] ? C.catById[scope.cat].label : scope.cat);
    if (scope.favs) return 'Mes favoris';
    if (scope.hard) return 'Mots difficiles';
    if (scope.custom) return 'Mes mots';
    if (scope.learned) return 'Mots en révision';
    return 'Tout le contenu';
  };
  X.pool = function (scope) {
    scope = scope || {}; var st = DZ.state, list;
    if (scope.lesson) list = (C.lessonById[scope.lesson] || { entries: [] }).entries;
    else if (scope.stage) {
      list = []; DZ.data.stages[scope.stage - 1].lessons.forEach(function (l) { list = list.concat(l.entries); });
    }
    else if (scope.cat) list = C.entries.filter(function (e) { return e.cat === scope.cat; });
    else if (scope.favs) list = Object.keys(st.favs).map(function (id) { return C.byId[id]; });
    else if (scope.hard) list = C.hardList();
    else if (scope.custom) list = C.entries.filter(function (e) { return e.custom; });
    else if (scope.learned) list = Object.keys(st.srs).map(function (id) { return C.byId[id]; });
    else list = C.entries;
    return uniq(list);
  };

  // Phrases d'entraînement (ordre des mots) selon la portée
  X.sentences = function (scope) {
    scope = scope || {}; var out = [];
    function add(d, fr, ref) {
      var n = T.words(d).length;
      if (n >= 3 && n <= 9 && d.indexOf('—') < 0 && d.indexOf('…') < 0) out.push({ d: d, fr: fr, ref: ref || null });
    }
    var lessons = scope.lesson ? [C.lessonById[scope.lesson]] : scope.stage ? DZ.data.stages[scope.stage - 1].lessons : (scope.cat || scope.favs || scope.hard || scope.custom || scope.learned) ? [] : C.lessons;
    lessons.forEach(function (l) { (l.phrases || []).forEach(function (p) { add(p[0], p[1]); }); });
    X.pool(scope).forEach(function (e) { if (e.exd) add(e.exd, e.exf, e.id); });
    if (!scope.lesson && !scope.cat && !scope.favs && !scope.hard && !scope.custom && !scope.learned) {
      if (!scope.stage || scope.stage >= 2) DZ.data.grammar.forEach(function (g) { (g.ex || []).forEach(function (p) { add(p[0], p[1]); }); });
      DZ.data.dialogues.forEach(function (d) {
        if (!scope.stage || d.lvl <= scope.stage + 1) d.lines.forEach(function (l) { add(l[1], l[3]); });
      });
    }
    var seen = {};
    return out.filter(function (s) { var k = T.normDz(s.d); if (seen[k]) return false; seen[k] = 1; return true; });
  };

  function distractors(e, n, field) {
    var nf = T.normFr(e.fr), nd = e.nd;
    var used = {}; used[field === 'fr' ? nf : nd] = 1;
    function okE(x) {
      if (x.id === e.id || x.custom) return false;
      if (field === 'fr') return T.normFr(x.fr) !== nf && x.fr.length < 90;
      return x.nd !== nd && x.nv.indexOf(nd) < 0 && e.nv.indexOf(x.nd) < 0;
    }
    var out = [];
    function take(list) {
      T.shuffle(list).forEach(function (x) {
        if (out.length >= n) return;
        var k = field === 'fr' ? T.normFr(x.fr) : x.nd;
        if (used[k]) return;
        used[k] = 1; out.push(x);
      });
    }
    take(C.entries.filter(function (x) { return x.cat === e.cat && okE(x); }));
    if (out.length < n) take(C.entries.filter(function (x) { return x.cat !== e.cat && x.l === e.l && okE(x); }));
    if (out.length < n) take(C.entries.filter(okE));
    return out;
  }

  function arLine(e) { return DZ.state.settings.showArabic && e.ar ? '<div>' + T.arHtml(e.ar) + '</div>' : ''; }
  function exampleHtml(e) {
    if (!e.exd) return '';
    return '<div class="small"><span class="dz">' + T.dzHtml(e.exd) + '</span><br><span class="muted">' + T.esc(e.exf) + '</span></div>';
  }

  /* ---------- Générateurs ---------- */
  X.gen = {};
  X.gen.mcqDzFr = function (e) {
    var ds = distractors(e, 3, 'fr');
    if (ds.length < 2) return null;
    return {
      kind: 'mcq', key: 'w:' + e.id, ref: e.id, label: 'QCM · darija → français',
      q: '<div class="muted small">Que veut dire :</div><div class="q-big-dz">' + T.dzHtml(e.d) + '</div>' + arLine(e), audio: e.d,
      opts: T.shuffle([{ t: e.fr, c: true }].concat(ds.map(function (x) { return { t: x.fr }; }))),
      explain: exampleHtml(e), answerText: e.fr
    };
  };
  X.gen.mcqFrDz = function (e) {
    var ds = distractors(e, 3, 'dz');
    if (ds.length < 2) return null;
    return {
      kind: 'mcq', key: 'w:' + e.id, ref: e.id, label: 'QCM · français → darija',
      q: 'Comment dit-on « ' + T.esc(e.fr) + ' » ?',
      opts: T.shuffle([{ t: e.d, dz: true, c: true }].concat(ds.map(function (x) { return { t: x.d, dz: true }; }))),
      explain: exampleHtml(e), answerText: e.d, answerDz: true
    };
  };
  X.gen.inputFrDz = function (e) {
    return {
      kind: 'input', lang: 'dz', key: 'w:' + e.id, ref: e.id, label: 'Traduction · français → darija',
      q: 'Écris en darija : « ' + T.esc(e.fr) + ' »', answers: [e.d].concat(e.v || []),
      explain: exampleHtml(e), answerText: e.d, answerDz: true
    };
  };
  X.gen.inputDzFr = function (e) {
    return {
      kind: 'input', lang: 'fr', key: 'w:' + e.id, ref: e.id, label: 'Traduction · darija → français',
      q: '<div class="muted small">Traduis en français :</div><div class="q-big-dz">' + T.dzHtml(e.d) + '</div>' + arLine(e), audio: e.d,
      frList: [e.fr], explain: exampleHtml(e), answerText: e.fr
    };
  };
  X.gen.order = function (s) {
    var toks = T.words(s.d).map(function (w) { return w.toLowerCase(); });
    if (toks.length < 3) return null;
    var shuffled = T.shuffle(toks), guard = 0;
    while (shuffled.join(' ') === toks.join(' ') && guard++ < 5) shuffled = T.shuffle(toks);
    return {
      kind: 'order', key: 's:' + T.normDz(s.d), ref: s.ref, label: 'Remets les mots dans l\'ordre',
      q: 'Traduis en remettant les mots dans l\'ordre : « ' + T.esc(s.fr) + ' »', tokens: shuffled, answer: toks.join(' '),
      answerText: s.d, answerDz: true, audio: s.d
    };
  };
  function escRe(s) { return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); }
  X.gen.fill = function (e) {
    if (!e.exd) return null;
    var re = new RegExp('(^|[^A-Za-z0-9À-ÿ])(' + escRe(e.d) + ')(?=$|[^A-Za-z0-9À-ÿ])', 'i');
    var m = re.exec(e.exd);
    if (!m) return null;
    if (T.normDz(e.exd) === e.nd) return null;
    var ds = distractors(e, 3, 'dz');
    if (ds.length < 2) return null;
    var start = m.index + m[1].length;
    var before = e.exd.slice(0, start), after = e.exd.slice(start + m[2].length);
    return {
      kind: 'mcq', key: 'w:' + e.id, ref: e.id, label: 'Phrase à compléter',
      q: '<div class="q-big-dz" style="font-size:1.35rem">' + T.dzHtml(before) + '<span class="badge green" style="font-size:1rem">_____</span>' + T.dzHtml(after) + '</div><div class="muted small">' + T.esc(e.exf) + '</div>',
      opts: T.shuffle([{ t: e.d, dz: true, c: true }].concat(ds.map(function (x) { return { t: x.d, dz: true }; }))),
      explain: '<div class="small"><span class="dz">' + T.dzHtml(e.exd) + '</span></div>', answerText: e.d, answerDz: true
    };
  };
  X.gen.match = function (list) {
    var es = uniq(list).filter(function (e) { return e.fr.length < 70; });
    var chosen = [], usedFr = {};
    T.shuffle(es).forEach(function (e) { var k = T.normFr(e.fr); if (chosen.length < 5 && !usedFr[k]) { usedFr[k] = 1; chosen.push(e); } });
    if (chosen.length < 3) return null;
    return {
      kind: 'match', key: 'm:' + chosen.map(function (e) { return e.id; }).join(','), label: 'Association',
      q: 'Associe chaque mot à sa traduction.',
      pairs: chosen.map(function (e) { return { id: e.id, d: e.d, fr: e.fr }; })
    };
  };
  X.gen.expr = function (e) {
    if (Math.random() < 0.6 || !e.exf) {
      var it = X.gen.mcqDzFr(e); if (!it) return null;
      it.label = 'Reconnaître une expression';
      it.q = '<div class="muted small">Que signifie cette expression ?</div><div class="q-big-dz">' + T.dzHtml(e.d) + '</div>' + arLine(e);
      return it;
    }
    var ds = distractors(e, 3, 'dz');
    if (ds.length < 2) return null;
    return {
      kind: 'mcq', key: 'w:' + e.id, ref: e.id, label: 'Reconnaître une expression',
      q: 'Quelle expression signifie « ' + T.esc(e.fr) + ' » ?',
      opts: T.shuffle([{ t: e.d, dz: true, c: true }].concat(ds.map(function (x) { return { t: x.d, dz: true }; }))),
      explain: exampleHtml(e), answerText: e.d, answerDz: true
    };
  };
  X.gen.dialogue = function (d, i) {
    var q = d.q[i];
    var lines = d.lines.map(function (l) { return '<div class="small"><b>' + T.esc(l[0]) + ' :</b> <span class="dz">' + T.dzHtml(l[1]) + '</span></div>'; }).join('');
    return {
      kind: 'mcq', key: 'd:' + d.id + ':' + i, label: 'Compréhension · dialogue',
      q: '<div class="muted small">Dialogue « ' + T.esc(d.t) + ' »</div><details class="small" style="margin:6px 0 10px"><summary style="cursor:pointer;color:var(--green);font-weight:650">Relire le dialogue (en darija)</summary><div style="display:flex;flex-direction:column;gap:4px;margin-top:8px">' + lines + '</div></details>' + T.esc(q.q),
      opts: T.shuffle(q.o.map(function (o, j) { return { t: o, c: j === q.a }; })),
      explain: q.e ? T.richHtml(q.e) : '', answerText: q.o[q.a]
    };
  };
  // Questions rédigées dans les leçons et fiches de grammaire
  X.fromQuiz = function (qz, key) {
    if (qz.t === 'qcm') {
      return {
        kind: 'mcq', key: key, label: 'Question de cours', q: T.richHtml(qz.q),
        opts: T.shuffle(qz.o.map(function (o, j) { return { t: o, dz: X.looksDz(o), c: j === qz.a }; })),
        explain: qz.e ? T.richHtml(qz.e) : '', answerText: qz.o[qz.a], answerDz: X.looksDz(qz.o[qz.a])
      };
    }
    if (qz.t === 'type') {
      return { kind: 'input', lang: 'dz', key: key, label: 'Question de cours', q: T.richHtml(qz.q), answers: qz.a, explain: qz.e ? T.richHtml(qz.e) : '', answerText: qz.a[0], answerDz: true };
    }
    if (qz.t === 'order') {
      var it = X.gen.order({ d: qz.a, fr: qz.fr }); if (it) it.key = key; return it;
    }
    return null;
  };

  /* ---------- Constructeurs de séries ---------- */
  X.TYPES = [
    { id: 'mixed', label: 'Entraînement libre', desc: 'Un mélange de tous les types', icon: 'shuffle' },
    { id: 'qcm', label: 'QCM', desc: 'Choisir la bonne traduction', icon: 'check' },
    { id: 'frdz', label: 'Français → darija', desc: 'Écrire la darija', icon: 'pen' },
    { id: 'dzfr', label: 'Darija → français', desc: 'Écrire la traduction', icon: 'globe' },
    { id: 'order', label: 'Mots dans l\'ordre', desc: 'Reconstituer une phrase', icon: 'order' },
    { id: 'fill', label: 'Phrases à compléter', desc: 'Trouver le mot manquant', icon: 'blank' },
    { id: 'match', label: 'Association', desc: 'Relier mots et traductions', icon: 'link' },
    { id: 'expr', label: 'Expressions', desc: 'Expressions, argot, proverbes', icon: 'bulb' },
    { id: 'dialogue', label: 'Dialogues', desc: 'Questions de compréhension', icon: 'chat' }
  ];

  X.build = function (type, scope, n) {
    n = n || 10; scope = scope || {};
    var pool = X.pool(scope), items = [];
    function fromPool(fn, k) {
      pick(pool, Math.min(pool.length, k * 3)).some(function (e) { var it = fn(e); if (it) items.push(it); return items.length >= k; });
    }
    if (type === 'qcm') fromPool(function (e) { return Math.random() < 0.5 ? X.gen.mcqDzFr(e) : X.gen.mcqFrDz(e); }, n);
    else if (type === 'frdz') fromPool(X.gen.inputFrDz, n);
    else if (type === 'dzfr') fromPool(X.gen.inputDzFr, n);
    else if (type === 'fill') fromPool(X.gen.fill, n);
    else if (type === 'order') pick(X.sentences(scope), n).forEach(function (s) { var it = X.gen.order(s); if (it) items.push(it); });
    else if (type === 'match') { for (var i = 0; i < Math.ceil(n / 2) && pool.length >= 3; i++) { var it = X.gen.match(pick(pool, 8)); if (it) items.push(it); } }
    else if (type === 'expr') {
      var ex = scope.cat || scope.lesson || scope.favs || scope.hard || scope.custom ? pool : C.entries.filter(function (e) { return ['expressions', 'argot', 'proverbes'].indexOf(e.cat) >= 0; });
      if (scope.stage) ex = pool.filter(function (e) { return ['expressions', 'argot', 'proverbes', 'salutations'].indexOf(e.cat) >= 0; });
      pick(ex, n * 2).some(function (e) { var it2 = X.gen.expr(e); if (it2) items.push(it2); return items.length >= n; });
    }
    else if (type === 'dialogue') {
      var ds = DZ.data.dialogues.filter(function (d) { return !scope.stage || d.lvl === scope.stage || (scope.stage === 1 && d.lvl === 1); });
      if (!ds.length) ds = DZ.data.dialogues;
      var qs = []; ds.forEach(function (d) { d.q.forEach(function (q, j) { qs.push([d, j]); }); });
      pick(qs, n).forEach(function (x) { items.push(X.gen.dialogue(x[0], x[1])); });
    }
    else if (type === 'mistakes') return X.mistakeItems(n);
    else { // mixte
      var gens = [X.gen.mcqDzFr, X.gen.mcqFrDz, X.gen.inputFrDz, X.gen.fill, X.gen.mcqDzFr];
      fromPool(function (e) { return gens[Math.floor(Math.random() * gens.length)](e); }, Math.max(1, n - 3));
      var ss = pick(X.sentences(scope), 2); ss.forEach(function (s) { var o = X.gen.order(s); if (o) items.push(o); });
      if (pool.length >= 4) { var m = X.gen.match(pick(pool, 8)); if (m) items.push(m); }
      items = T.shuffle(items).slice(0, n);
    }
    return items.filter(Boolean);
  };

  X.mistakeItems = function (n) {
    var items = [];
    C.mistakeList().slice(0, n || 15).forEach(function (m) {
      if (m.kind === 'word') {
        var e = C.byId[m.ref]; if (!e) return;
        var gens = [X.gen.mcqFrDz, X.gen.inputFrDz, X.gen.mcqDzFr];
        var it = null, k = 0;
        while (!it && k < 4) { it = gens[Math.floor(Math.random() * gens.length)](e); k++; }
        if (it) { it.key = m.key; items.push(it); }
      } else if (m.item) {
        var copy = JSON.parse(JSON.stringify(m.item));
        if (copy.opts) copy.opts = T.shuffle(copy.opts);
        if (copy.tokens) copy.tokens = T.shuffle(copy.tokens);
        items.push(copy);
      }
    });
    return items;
  };

  X.lessonItems = function (l) {
    var items = [];
    (l.quiz || []).forEach(function (q, i) { var it = X.fromQuiz(q, 'q:' + l.id + ':' + i); if (it) items.push(it); });
    var es = l.entries;
    if (es.length) {
      pick(es, 2).forEach(function (e) { var it = X.gen.mcqDzFr(e); if (it) items.push(it); });
      pick(es, 1).forEach(function (e) { var it = X.gen.mcqFrDz(e); if (it) items.push(it); });
      pick(es, 1).forEach(function (e) { var it = X.gen.inputFrDz(e); if (it) items.push(it); });
      if (es.length >= 4) { var m = X.gen.match(pick(es, 6)); if (m) items.push(m); }
    }
    var ph = (l.phrases || []).filter(function (p) { var n = T.words(p[0]).length; return n >= 3 && n <= 9 && p[0].indexOf('—') < 0; });
    pick(ph, 1).forEach(function (p) { var it = X.gen.order({ d: p[0], fr: p[1] }); if (it) items.push(it); });
    return T.shuffle(items);
  };
  X.grammarItems = function (g) {
    var items = [];
    (g.quiz || []).forEach(function (q, i) { var it = X.fromQuiz(q, 'q:' + g.id + ':' + i); if (it) items.push(it); });
    pick(g.ex || [], 2).forEach(function (p) { var it = X.gen.order({ d: p[0], fr: p[1] }); if (it) items.push(it); });
    return T.shuffle(items);
  };

  /* ---------- Session d'exercices ---------- */
  X.session = null;
  X.start = function (cfg) {
    if (!cfg.items || !cfg.items.length) { U.toast('Pas assez de contenu pour cet exercice. Essayez une autre portée.'); return; }
    X.session = {
      title: cfg.title, items: cfg.items, i: 0, mode: cfg.mode || 'practice', results: [],
      started: Date.now(), xp0: DZ.state.stats.xp, onDone: cfg.onDone || null, back: cfg.back || '#/pratique', rebuild: cfg.rebuild || null, scope: cfg.scope
    };
    DZ.app.go('#/session');
  };

  function curItem() { var s = X.session; return s && s.items[s.i]; }

  X.render = function (root) {
    var s = X.session;
    if (!s) { DZ.app.go('#/pratique', true); return; }
    if (s.i >= s.items.length) return renderEnd(root);
    var it = s.items[s.i];
    s.answered = false; s.sel = null; s.orderPick = []; s.matchState = null;
    var pct = Math.round(s.i / s.items.length * 100);
    var html = '<div class="page session view-enter">' +
      '<div class="session-top"><button class="icon-btn" data-act="session-quit" aria-label="Quitter la série">' + U.icon('x') + '</button>' +
      '<div class="bar" role="progressbar" aria-valuenow="' + pct + '" aria-valuemin="0" aria-valuemax="100"><i style="width:' + pct + '%"></i></div>' +
      '<span class="small num muted">' + (s.i + 1) + ' / ' + s.items.length + '</span></div>' +
      (s.mode === 'exam' ? '<div class="hstack small muted">' + U.icon('exam') + '<span>Mode examen : les corrections s\'affichent à la fin.</span></div>' : '') +
      '<div class="q-card" id="qcard"><div class="hstack"><span class="q-kind">' + T.esc(it.label || '') + '</span><span class="spacer"></span>' +
      (it.audio && (DZ.audio.has(it.audio)) ? U.audioBtn(it.audio, '', true) : '') + '</div>' +
      '<div class="q-prompt">' + it.q + '</div>' + bodyFor(it) + '</div>' +
      '<div id="fb"></div></div>';
    root.innerHTML = html;
    bindItem(root, it);
  };

  function bodyFor(it) {
    if (it.kind === 'mcq') {
      return '<div class="opts">' + it.opts.map(function (o, i) {
        return '<button class="opt ' + (o.dz ? 'dz' : '') + '" data-opt="' + i + '"><span class="opt-key">' + (i + 1) + '</span><span>' + (o.dz ? T.dzHtml(o.t) : T.esc(o.t)) + '</span></button>';
      }).join('') + '</div>';
    }
    if (it.kind === 'input') {
      var dz = it.lang === 'dz';
      return '<div class="field"><label for="ans">' + (dz ? 'Ta réponse en darija (lettres latines et chiffres)' : 'Ta réponse en français') + '</label>' +
        '<input id="ans" class="input ' + (dz ? 'dz-input' : '') + '" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false" enterkeyhint="done"></div>' +
        (dz ? '<div class="keys" aria-label="Insérer un caractère">' + ['3', '7', '9', '2', 'kh', 'gh', 'ch', 'ou'].map(function (k) { return '<button type="button" data-key="' + k + '">' + (/\d/.test(k) ? '<b>' + k + '</b>' : k) + '</button>'; }).join('') + '</div>' : '') +
        '<div class="btn-row"><button class="btn btn-secondary" data-act="ex-skip">Je ne sais pas</button><button class="btn btn-primary" data-act="ex-check">Vérifier</button></div>';
    }
    if (it.kind === 'order') {
      return '<div class="tokens answer" id="ord-ans" aria-label="Ta phrase"></div>' +
        '<div class="tokens" id="ord-pool">' + it.tokens.map(function (t, i) { return '<button class="token" data-tok="' + i + '">' + T.dzHtml(t) + '</button>'; }).join('') + '</div>' +
        '<div class="btn-row"><button class="btn btn-secondary" data-act="ord-clear">Effacer</button><button class="btn btn-primary" data-act="ex-check">Vérifier</button></div>';
    }
    if (it.kind === 'match') {
      var left = T.shuffle(it.pairs), right = T.shuffle(it.pairs);
      return '<div class="match"><div class="col">' + left.map(function (p) { return '<button class="m-item dz" data-side="l" data-id="' + T.esc(p.id) + '">' + T.dzHtml(p.d) + '</button>'; }).join('') +
        '</div><div class="col">' + right.map(function (p) { return '<button class="m-item" data-side="r" data-id="' + T.esc(p.id) + '">' + T.esc(p.fr) + '</button>'; }).join('') + '</div></div>';
    }
    return '';
  }

  function bindItem(root, it) {
    var s = X.session;
    if (it.kind === 'mcq') {
      root.querySelectorAll('[data-opt]').forEach(function (b) {
        b.addEventListener('click', function () { answerMcq(root, it, +b.getAttribute('data-opt')); });
      });
    }
    if (it.kind === 'input') {
      var inp = root.querySelector('#ans');
      setTimeout(function () { try { inp.focus(); } catch (e) { /* ignoré */ } }, 60);
      inp.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); if (!s.answered) checkInput(root, it); else next(); } });
      root.querySelectorAll('[data-key]').forEach(function (k) {
        k.addEventListener('click', function () {
          var v = k.getAttribute('data-key'), st = inp.selectionStart || inp.value.length, en = inp.selectionEnd || st;
          inp.value = inp.value.slice(0, st) + v + inp.value.slice(en); inp.focus();
          try { inp.setSelectionRange(st + v.length, st + v.length); } catch (e) { /* ignoré */ }
        });
      });
    }
    if (it.kind === 'order') {
      var pool = root.querySelector('#ord-pool'), ans = root.querySelector('#ord-ans');
      pool.addEventListener('click', function (e) {
        var b = e.target.closest('[data-tok]'); if (!b || s.answered || b.classList.contains('used')) return;
        b.classList.add('used'); s.orderPick.push(+b.getAttribute('data-tok')); drawOrder(ans, it);
      });
      ans.addEventListener('click', function (e) {
        var b = e.target.closest('[data-pick]'); if (!b || s.answered) return;
        var idx = +b.getAttribute('data-pick'), tokIdx = s.orderPick[idx];
        s.orderPick.splice(idx, 1);
        pool.querySelector('[data-tok="' + tokIdx + '"]').classList.remove('used'); drawOrder(ans, it);
      });
    }
    if (it.kind === 'match') {
      s.matchState = { sel: null, done: 0, errors: 0, errIds: {} };
      root.querySelectorAll('.m-item').forEach(function (b) { b.addEventListener('click', function () { clickMatch(root, it, b); }); });
    }
  }

  function drawOrder(ans, it) {
    var s = X.session;
    ans.innerHTML = s.orderPick.map(function (ti, i) { return '<button class="token" data-pick="' + i + '">' + T.dzHtml(it.tokens[ti]) + '</button>'; }).join('');
  }

  X.clearOrder = function () {
    var s = X.session, it = curItem(); if (!s || !it || s.answered) return;
    s.orderPick = [];
    document.querySelectorAll('#ord-pool .token').forEach(function (b) { b.classList.remove('used'); });
    drawOrder(document.getElementById('ord-ans'), it);
  };

  function answerMcq(root, it, i) {
    var s = X.session; if (s.answered) return;
    var o = it.opts[i], ok = !!o.c;
    var btns = root.querySelectorAll('[data-opt]');
    if (s.mode === 'exam') {
      btns.forEach(function (b) { b.classList.remove('selected'); });
      btns[i].classList.add('selected');
      s.answered = true; btns.forEach(function (b) { b.disabled = true; });
      record(it, ok, o.t);
      feedback(root, it, ok ? 'ok' : 'ko', o.t);
      return;
    }
    s.answered = true;
    btns.forEach(function (b, j) { b.disabled = true; if (it.opts[j].c) b.classList.add('correct'); });
    if (!ok) btns[i].classList.add('wrong');
    record(it, ok, o.t);
    feedback(root, it, ok ? 'ok' : 'ko', o.t);
  }

  X.checkCurrent = function () {
    var it = curItem(), root = document.getElementById('view');
    if (!it || X.session.answered) return;
    if (it.kind === 'input') checkInput(root, it);
    if (it.kind === 'order') checkOrder(root, it);
  };
  X.skipCurrent = function () {
    var it = curItem(), root = document.getElementById('view'); if (!it || X.session.answered) return;
    X.session.answered = true;
    var inp = root.querySelector('#ans'); if (inp) inp.disabled = true;
    record(it, false, '');
    feedback(root, it, 'ko', '');
  };

  function checkInput(root, it) {
    var s = X.session, inp = root.querySelector('#ans'), v = inp.value;
    if (!v.trim()) { inp.focus(); return; }
    s.answered = true; inp.disabled = true;
    if (it.lang === 'dz') {
      var r = T.checkDz(v, it.answers);
      record(it, r.ok, v);
      feedback(root, it, r.ok ? 'ok' : 'ko', v, r);
    } else {
      var rf = T.checkFr(v, it.frList);
      if (rf.level === 'maybe' && s.mode !== 'exam') { feedbackMaybe(root, it, v); return; }
      record(it, rf.ok, v);
      feedback(root, it, rf.ok ? 'ok' : 'ko', v, rf);
    }
  }
  function checkOrder(root, it) {
    var s = X.session;
    if (!s.orderPick.length) return;
    var given = s.orderPick.map(function (i) { return it.tokens[i]; }).join(' ');
    var ok = T.normDz(given) === T.normDz(it.answer);
    s.answered = true;
    record(it, ok, given);
    feedback(root, it, ok ? 'ok' : 'ko', given);
  }

  function clickMatch(root, it, b) {
    var s = X.session, ms = s.matchState;
    if (b.classList.contains('done') || s.answered) return;
    if (!ms.sel || ms.sel.getAttribute('data-side') === b.getAttribute('data-side')) {
      if (ms.sel) ms.sel.classList.remove('sel');
      ms.sel = b; b.classList.add('sel'); return;
    }
    var a = ms.sel; ms.sel = null; a.classList.remove('sel');
    if (a.getAttribute('data-id') === b.getAttribute('data-id')) {
      a.classList.add('done'); b.classList.add('done'); ms.done++;
      if (ms.done === it.pairs.length) {
        s.answered = true;
        var ok = ms.errors === 0;
        record(it, ok, ok ? '' : ms.errors + ' erreur(s)');
        Object.keys(ms.errIds).forEach(function (id) { C.srsLapse(id); C.addMistakeWord(id); });
        feedback(root, it, ok ? 'ok' : 'ko', '');
      }
    } else {
      ms.errors++;
      var lid = a.getAttribute('data-side') === 'l' ? a.getAttribute('data-id') : b.getAttribute('data-id');
      ms.errIds[lid] = 1;
      [a, b].forEach(function (x) { x.classList.add('err'); setTimeout(function () { x.classList.remove('err'); }, 450); });
    }
  }

  function record(it, ok, given) {
    var s = X.session;
    s.results.push({ item: it, ok: ok, given: given });
    C.recordAnswer(ok);
    if (it.kind === 'match') return;
    if (!ok) {
      if (it.key && it.key.indexOf('w:') === 0 && it.ref) { C.srsLapse(it.ref); C.addMistakeWord(it.ref); }
      else if (it.key) C.addMistakeItem(it.key, it, given);
    } else if (it.key && DZ.state.mistakes[it.key]) {
      C.clearMistake(it.key);
    }
  }

  function answerHtml(it) {
    if (it.kind === 'match') return it.pairs.map(function (p) { return '<span class="dz">' + T.dzHtml(p.d) + '</span> = ' + T.esc(p.fr); }).join('<br>');
    return it.answerDz ? '<span class="dz">' + T.dzHtml(it.answerText) + '</span>' : T.esc(it.answerText || '');
  }

  function feedback(root, it, kind, given, r) {
    var s = X.session, fb = root.querySelector('#fb');
    if (s.mode === 'exam') {
      fb.innerHTML = '<button class="btn btn-primary btn-block" data-act="ex-next">' + (s.i + 1 < s.items.length ? 'Question suivante' : 'Voir mes résultats') + U.icon('right') + '</button>';
      focusNext(fb); return;
    }
    var title = kind === 'ok' ? (r && (r.level === 'typo' || r.level === 'variant') ? 'Correct, avec une orthographe différente' : 'Correct !') : 'Pas tout à fait';
    var html = '<div class="feedback ' + kind + '"><div class="fb-title">' + U.icon(kind === 'ok' ? 'check' : 'x') + T.esc(title) + '</div>';
    if (kind === 'ok' && r && (r.level === 'typo' || r.level === 'variant') && it.lang === 'dz') html += '<div>Forme de référence : <span class="dz">' + T.dzHtml(r.expected) + '</span></div>';
    if (kind === 'ko') html += '<div>Bonne réponse : ' + answerHtml(it) + '</div>' + (given ? '<div class="small muted">Ta réponse : ' + T.esc(given) + '</div>' : '');
    if (it.lang === 'dz' && it.answers && it.answers.length > 1 && kind === 'ko') html += '<div class="small muted">Aussi accepté : ' + it.answers.slice(1, 5).map(function (a) { return T.dzHtml(a); }).join(', ') + '</div>';
    if (it.explain) html += '<div>' + it.explain + '</div>';
    html += '</div><button class="btn btn-primary btn-block" data-act="ex-next" style="margin-top:12px">Continuer ' + U.icon('right') + '</button>';
    fb.innerHTML = html;
    focusNext(fb);
  }
  function feedbackMaybe(root, it, given) {
    var fb = root.querySelector('#fb');
    fb.innerHTML = '<div class="feedback maybe"><div class="fb-title">' + U.icon('help') + 'À toi de juger</div>' +
      '<div>Réponse attendue : <b>' + T.esc(it.answerText) + '</b></div><div class="small muted">Ta réponse : ' + T.esc(given) + '</div>' +
      '<div class="small">Ta réponse est proche. Veut-elle dire la même chose ?</div></div>' +
      '<div class="btn-row" style="margin-top:12px"><button class="btn btn-secondary" data-act="ex-self" data-ok="0">Non, c\'était faux</button><button class="btn btn-primary" data-act="ex-self" data-ok="1">Oui, c\'était juste</button></div>';
  }
  X.selfAssess = function (ok) {
    var it = curItem(), root = document.getElementById('view');
    var given = (root.querySelector('#ans') || {}).value || '';
    record(it, ok, given);
    feedback(root, it, ok ? 'ok' : 'ko', given);
  };
  function focusNext(fb) { var b = fb.querySelector('[data-act="ex-next"]'); if (b) setTimeout(function () { try { b.focus({ preventScroll: false }); } catch (e) { /* ignoré */ } }, 30); }

  function next() {
    var s = X.session; if (!s) return;
    s.i++;
    X.render(document.getElementById('view'));
    window.scrollTo(0, 0);
  }
  X.next = next;

  function renderEnd(root) {
    var s = X.session, ok = s.results.filter(function (r) { return r.ok; }).length, n = s.results.length;
    var pct = n ? Math.round(ok / n * 100) : 0, sec = Math.round((Date.now() - s.started) / 1000);
    if (!s.finished) {
      s.finished = true;
      if (s.mode === 'exam') {
        DZ.state.exams.unshift({ ts: Date.now(), label: s.title, n: n, ok: ok, pct: pct, sec: sec });
        DZ.state.exams = DZ.state.exams.slice(0, 50); DZ.store.save();
      }
      if (s.onDone) s.onDone(pct);
    }
    var xp = DZ.state.stats.xp - s.xp0;
    var errs = s.results.filter(function (r) { return !r.ok; });
    var msg = pct >= 90 ? ['Ghaya !', 'Excellent travail.'] : pct >= 70 ? ['Mli7 !', 'C\'est bien.'] : pct >= 50 ? ['Zid, zid !', 'Pas mal, continue.'] : ['Chwiya b chwiya', 'On progresse pas à pas.'];
    root.innerHTML = '<div class="page view-enter">' +
      '<div class="card" style="text-align:center;display:flex;flex-direction:column;gap:10px;align-items:center">' +
      '<span class="eyebrow">' + T.esc(s.title) + '</span><div class="result-score num">' + pct + '%</div>' +
      '<div class="dz" style="font-size:1.3rem">' + T.dzHtml(msg[0]) + '</div><div class="muted">' + T.esc(msg[1]) + '</div>' +
      '<div class="hstack" style="justify-content:center"><span class="badge green num">' + ok + ' / ' + n + ' bonnes réponses</span><span class="badge grey num">+' + xp + ' XP</span><span class="badge grey num">' + Math.floor(sec / 60) + ' min ' + (sec % 60) + ' s</span></div></div>' +
      (errs.length ? '<section class="section"><h2 class="section-title">À retenir</h2><div class="list">' + errs.map(function (r) {
        return '<div class="row"><div class="row-main" style="cursor:default"><span class="small muted">' + T.esc(r.item.label || '') + '</span><div>' + stripTags(r.item.q).slice(0, 160) + '</div>' +
          '<div>Réponse : ' + answerHtml(r.item) + '</div>' + (r.given ? '<div class="small muted">Ta réponse : ' + T.esc(r.given) + '</div>' : '') + '</div></div>';
      }).join('') + '</div></section>' : '') +
      '<div class="btn-row">' + (errs.length ? '<button class="btn btn-secondary" data-act="ex-retry-errors">' + U.icon('refresh') + 'Refaire mes erreurs</button>' : '') +
      (s.rebuild ? '<button class="btn btn-secondary" data-act="ex-again">' + U.icon('shuffle') + 'Nouvelle série</button>' : '') +
      '<button class="btn btn-primary" data-act="ex-done">Terminer</button></div></div>';
  }
  function stripTags(h) {
    var d = document.createElement('div'); d.innerHTML = h;
    d.querySelectorAll('details').forEach(function (x) { x.remove(); });
    return T.esc(d.textContent.trim());
  }

  X.retryErrors = function () {
    var s = X.session; if (!s) return;
    var items = s.results.filter(function (r) { return !r.ok; }).map(function (r) {
      var c = JSON.parse(JSON.stringify(r.item)); if (c.opts) c.opts = T.shuffle(c.opts); if (c.tokens) c.tokens = T.shuffle(c.tokens); return c;
    });
    X.start({ title: 'Mes erreurs', items: items, mode: 'practice', back: s.back });
  };
  X.again = function () { var s = X.session; if (s && s.rebuild) X.start(s.rebuild()); };

  // Raccourcis clavier pendant une série
  document.addEventListener('keydown', function (e) {
    if (!X.session || DZ.app.route !== 'session' || document.getElementById('overlay')) return;
    var it = curItem(); if (!it) return;
    if (it.kind === 'mcq' && !X.session.answered && /^[1-9]$/.test(e.key)) {
      var b = document.querySelector('[data-opt="' + (+e.key - 1) + '"]'); if (b) b.click();
    }
  });

  /* ---------- Révision espacée (cartes) ---------- */
  X.review = null;
  X.startReview = function (minutes, cram) {
    var st = DZ.state, ids;
    if (cram) {
      ids = Object.keys(st.srs).filter(function (id) { return C.byId[id]; })
        .sort(function (a, b) { return st.srs[a].d - st.srs[b].d; }).slice(0, 40);
    } else {
      var due = C.srsDue();
      var newMax = Math.max(0, (st.settings.newPerDay || 10) - (C.act().newc || 0));
      ids = due.concat(C.newCandidates(newMax));
    }
    X.review = { queue: ids, i: 0, end: Date.now() + minutes * 60000, minutes: minutes, done: 0, grades: [0, 0, 0, 0], flipped: false, xp0: st.stats.xp };
    DZ.app.go('#/reviser');
  };
  var tick = null;
  X.renderReview = function (root) {
    var r = X.review;
    clearInterval(tick);
    if (!r) { DZ.app.go('#/pratique', true); return; }
    if (r.i >= r.queue.length || (Date.now() > r.end && !r.flipped)) return renderReviewEnd(root);
    var id = r.queue[r.i], e = C.byId[id];
    if (!e) { r.i++; return X.renderReview(root); }
    var card = DZ.state.srs[id];
    var dir = (!card || card.nw || (card.r % 2 === 0)) ? 'dz' : 'fr';
    r.dir = dir;
    var front = dir === 'dz'
      ? '<div class="f-front dz">' + T.dzHtml(e.d) + '</div>' + (DZ.state.settings.showArabic && e.ar ? T.arHtml(e.ar) : '')
      : '<div class="muted small">Comment dit-on…</div><div class="f-front" style="font-weight:700;font-size:1.5rem">' + T.esc(e.fr) + '</div>';
    var back = dir === 'dz'
      ? '<div style="font-size:1.25rem;font-weight:650">' + T.esc(e.fr) + '</div>'
      : '<div class="dz" style="font-size:2rem;font-weight:700">' + T.dzHtml(e.d) + '</div>' + (DZ.state.settings.showArabic && e.ar ? T.arHtml(e.ar) : '');
    var isNew = !card || card.nw;
    var left = Math.max(0, r.end - Date.now());
    root.innerHTML = '<div class="page session view-enter">' +
      '<div class="session-top"><button class="icon-btn" data-act="review-quit" aria-label="Arrêter la révision">' + U.icon('x') + '</button>' +
      '<div class="bar"><i id="rv-bar" style="width:' + Math.round((1 - left / (r.minutes * 60000)) * 100) + '%"></i></div>' +
      '<span class="small num muted" id="rv-time">' + fmt(left) + '</span></div>' +
      '<div class="hstack small muted"><span>' + (r.queue.length - r.i) + ' carte(s) restante(s)</span>' + (isNew ? '<span class="badge red">nouveau mot</span>' : '') + U.badges(e) + '</div>' +
      '<div class="q-card flash">' + front +
      '<div id="rv-back" class="f-back" ' + (r.flipped ? '' : 'hidden') + '>' + back +
      (e.exd ? '<div class="small" style="margin-top:6px"><span class="dz">' + T.dzHtml(e.exd) + '</span><br><span class="muted">' + T.esc(e.exf) + '</span></div>' : '') +
      (e.n ? '<div class="small muted">' + T.esc(e.n) + '</div>' : '') + '</div>' +
      '<div class="hstack">' + U.audioBtn(e.d, e.ar) + '</div></div>' +
      '<div id="rv-act">' + (r.flipped ? gradesHtml(card) : '<button class="btn btn-primary btn-block" data-act="review-flip">Afficher la réponse</button>') + '</div></div>';
    tick = setInterval(function () {
      var t = document.getElementById('rv-time'); if (!t || DZ.app.route !== 'reviser') { clearInterval(tick); return; }
      var l = Math.max(0, r.end - Date.now()); t.textContent = fmt(l);
      var b = document.getElementById('rv-bar'); if (b) b.style.width = Math.round((1 - l / (r.minutes * 60000)) * 100) + '%';
    }, 1000);
  };
  function fmt(ms) { var s = Math.ceil(ms / 1000); return Math.floor(s / 60) + ':' + ('0' + s % 60).slice(-2); }
  function ivlLabel(d) { return d <= 0 ? '10 min' : d === 1 ? '1 j' : d < 30 ? d + ' j' : Math.round(d / 30) + ' mois'; }
  function gradesHtml(card) {
    var c = card || { e: 2.5, i: 0, r: 0, l: 0 };
    var g = [['À revoir', 'g-again'], ['Difficile', 'g-hard'], ['Bien', 'g-good'], ['Facile', 'g-easy']];
    return '<div class="grades">' + g.map(function (x, i) {
      return '<button class="btn ' + x[1] + '" data-act="review-grade" data-g="' + i + '">' + x[0] + '<small>' + ivlLabel(C.srsPreview(c, i)) + '</small></button>';
    }).join('') + '</div>';
  }
  X.flip = function () {
    var r = X.review; if (!r || r.flipped) return;
    r.flipped = true;
    document.getElementById('rv-back').hidden = false;
    document.getElementById('rv-act').innerHTML = gradesHtml(DZ.state.srs[r.queue[r.i]]);
  };
  X.grade = function (g) {
    var r = X.review; if (!r || !r.flipped) return;
    var id = r.queue[r.i];
    if (!DZ.state.srs[id]) C.srsAdd(id);
    C.srsGrade(id, g);
    r.grades[g]++; r.done++;
    if (g === 0 && Date.now() < r.end) r.queue.splice(Math.min(r.queue.length, r.i + 4), 0, id);
    r.i++; r.flipped = false;
    X.renderReview(document.getElementById('view'));
  };
  function renderReviewEnd(root) {
    var r = X.review; clearInterval(tick);
    var xp = DZ.state.stats.xp - r.xp0;
    var due = C.srsDue().length;
    root.innerHTML = '<div class="page view-enter"><div class="card" style="text-align:center;display:flex;flex-direction:column;gap:10px;align-items:center">' +
      '<span class="eyebrow">Révision terminée</span><div class="result-score num">' + r.done + '</div><div class="muted">carte(s) révisée(s)</div>' +
      '<div class="hstack" style="justify-content:center"><span class="badge red">À revoir : ' + r.grades[0] + '</span><span class="badge verify">Difficile : ' + r.grades[1] + '</span><span class="badge green">Bien : ' + r.grades[2] + '</span><span class="badge green">Facile : ' + r.grades[3] + '</span></div>' +
      '<span class="badge grey num">+' + xp + ' XP</span>' +
      (r.done === 0 ? '<p class="muted small">Aucune carte n\'était à réviser. Terminez une leçon ou ajoutez des mots depuis le dictionnaire pour alimenter vos révisions.</p>' : '') +
      (due ? '<p class="small">Encore ' + due + ' carte(s) à réviser aujourd\'hui.</p>' : '<p class="small">Tout est à jour pour le moment. <span class="dz">Sa7a !</span></p>') + '</div>' +
      '<div class="btn-row">' + (due ? '<button class="btn btn-secondary" data-act="review-start" data-min="5">Continuer 5 min</button>' : '') +
      '<button class="btn btn-primary" data-act="go" data-href="#/">Retour à l\'accueil</button></div></div>';
    X.review = null;
  }
})();
